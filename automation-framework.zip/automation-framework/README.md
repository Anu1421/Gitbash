# automation-framework
Automation framework for testing the mobile apps
