package dimensionofuielements;

import com.aventstack.extentreports.Status;
import genericutility.BaseClass;
import genericutility.JavaUtility;
import genericutility.iTestListenerImplementation;
import objectrepository.DashboardPage;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.text.DecimalFormat;

@Listeners(iTestListenerImplementation.class)
public class DistanceBetweenHealthCardsUnderMyHealthSection extends BaseClass {
    private static final DecimalFormat decimalFormat = new DecimalFormat("0.00");

    @Test
    public void distanceBetweenHealthCardsUnderMyHealthSection() {
        DashboardPage dashboardPage=new DashboardPage(driver);
        SoftAssert softAssert=new SoftAssert();
        JavaUtility javaUtility=new JavaUtility();

        //Scroll to my health section
//        dashboardPage.swipeToMyHealthSection(driver);

        //Fetch the dimension of the health card group
        String dimensionOfHealthCardGroupIOS = dashboardPage.fetchTheDimensionsOfHealthCardGroupIOS();
        int startXGroup = Integer.parseInt(dimensionOfHealthCardGroupIOS.split(" ")[0]);
        int startYGroup = Integer.parseInt(dimensionOfHealthCardGroupIOS.split(" ")[1]);
        int endXGroup = Integer.parseInt(dimensionOfHealthCardGroupIOS.split(" ")[2]);
        int endYGroup = Integer.parseInt(dimensionOfHealthCardGroupIOS.split(" ")[3]);

        //Fetch the dimension of the first health card
        String dimensionOfFirstHealthCardIOS = dashboardPage.fetchTheDimensionsOfFirstHealthCardIOS();
        int startXFirst = Integer.parseInt(dimensionOfFirstHealthCardIOS.split(" ")[0]);
        int startYFirst = Integer.parseInt(dimensionOfFirstHealthCardIOS.split(" ")[1]);
        int endXFirst = Integer.parseInt(dimensionOfFirstHealthCardIOS.split(" ")[2]);
        int endYFirst = Integer.parseInt(dimensionOfFirstHealthCardIOS.split(" ")[3]);

        //Fetch the dimension of the second health card
        String dimensionOfSecondHealthCardIOS = dashboardPage.fetchTheDimensionsOfSecondHealthCardIOS();
        int startXSecond = Integer.parseInt(dimensionOfSecondHealthCardIOS.split(" ")[0]);
        int startYSecond = Integer.parseInt(dimensionOfSecondHealthCardIOS.split(" ")[1]);
        int endXSecond = Integer.parseInt(dimensionOfSecondHealthCardIOS.split(" ")[2]);
        int endYSecond = Integer.parseInt(dimensionOfSecondHealthCardIOS.split(" ")[3]);

        //Fetch the dimension of the Third health card
        String dimensionOfThirdHealthCardIOS = dashboardPage.fetchTheDimensionsOfThirdHealthCardIOS();
        int startXThird = Integer.parseInt(dimensionOfThirdHealthCardIOS.split(" ")[0]);
        int startYThird = Integer.parseInt(dimensionOfThirdHealthCardIOS.split(" ")[1]);
        int endXThird = Integer.parseInt(dimensionOfThirdHealthCardIOS.split(" ")[2]);
        int endYThird = Integer.parseInt(dimensionOfThirdHealthCardIOS.split(" ")[3]);

        //Fetch the dimension of the Forth health card
        String dimensionOfForthHealthCardIOS = dashboardPage.fetchTheDimensionsOfFourthHealthCardIOS();
        int startXFourth = Integer.parseInt(dimensionOfForthHealthCardIOS.split(" ")[0]);
        int startYFourth = Integer.parseInt(dimensionOfForthHealthCardIOS.split(" ")[1]);
        int endXFourth = Integer.parseInt(dimensionOfForthHealthCardIOS.split(" ")[2]);
        int endYFourth = Integer.parseInt(dimensionOfForthHealthCardIOS.split(" ")[3]);

        //Get total dimension of Health Cards group
        double totalYDimGroup=endYGroup-startYGroup;
        double totalXDimGroup=endXGroup-startXGroup;

        //Get total dimension of first Health Card
        double totalYDimFirst=endYFirst-startYFirst;
        double totalXDimFirst=endXFirst-startXFirst;

        //Get total dimension of second Health Card
        double totalYDimSecond=endYSecond-startYSecond;
        double totalXDimSecond=endXSecond-startXSecond;

        //Get total dimension of third Health Card
        double totalYDimThird=endYThird-startYThird;
        double totalXDimThird=endXThird-startXThird;

        //Get total dimension of forth Health Card
        double totalYDimForth=endYFourth-startYFourth;
        double totalXDimForth=endXFourth-startXFourth;

        //Horizontal distance from left side of group to left side of first health card
        double diffBetStartXGroupStartXFirst = startXFirst - startXGroup;

        //Horizontal width of first health card
        double horizontalWidthFirst = endXFirst - startXFirst;

        //Horizontal distance from right side of first health card to left side of second health card
        double diffBetEndXFirstStartXSecond = startXSecond - endXFirst;

        //Horizontal width of second health card
        double horizontalWidthSecond = endXSecond - startXSecond;

        //Horizontal distance from right side of second health card to right side of health group
        double diffBetEndXSecondEndXGroup= endXGroup - endXSecond;

        //Vertical width of first health card
        double verticalWidthFirst = endYFirst - startYFirst;

        //Vertical distance between first and third health card
        double diffBetStartYThirdEndYFirst = startYThird - endYFirst;

        //Vertical width of third health card
        double verticalWidthThird = endYThird - startYThird;

        //Percentage Horizontal distance from left screen edge to left side of first health card
        double PercentageStartXGroupStartXFirst=(diffBetStartXGroupStartXFirst/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageStartXGroupStartXFirst)), "3.1");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal Distance from Left side of the Health card group to left side of the first health card in Zeplin is 3.1 and the percentage found in UI is "+decimalFormat.format(PercentageStartXGroupStartXFirst));

        //Percentage Horizontal width of first health card
        double PercentageHorizontalWidthFirst=(horizontalWidthFirst/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageHorizontalWidthFirst)), "46.1");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal width of the first health card in Zeplin is 46.1 and the percentage found in UI is "+decimalFormat.format(PercentageHorizontalWidthFirst));

        //Percentage Horizontal distance from right side of first health card to left side of second health card
        double PercentageEndXFirstStartXSecond=(diffBetEndXFirstStartXSecond/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageEndXFirstStartXSecond)), "1.7");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal Distance from right side of the first health card to left side of the second health card in Zeplin is 1.7 and the percentage found in UI is "+decimalFormat.format(PercentageEndXFirstStartXSecond));

        //Percentage Horizontal width of second health card
        double PercentageHorizontalWidthSecond=(horizontalWidthSecond/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageHorizontalWidthSecond)), "46.1");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal width of the second health card in Zeplin is 46.1 and the percentage found in UI is "+decimalFormat.format(PercentageHorizontalWidthSecond));

        //Percentage Horizontal distance from right side of second health card to screen right edge
        double PercentageEndXSecondEndXGroup=(diffBetEndXSecondEndXGroup/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageEndXSecondEndXGroup)), "2.9");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal Distance from right side of second health card to right side of the Health card group in Zeplin is 2.9 and the percentage found in UI is "+decimalFormat.format(PercentageEndXSecondEndXGroup));

        //Percentage Vertical distance from bottom of first health card to top of third health card
        double PercentageStartYThirdEndYFirst=(diffBetStartYThirdEndYFirst/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageStartYThirdEndYFirst)), "1.31");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Vertical Distance from bottom of the first health card to top of the third health card in Zeplin is 1.31 and the percentage found in UI is "+decimalFormat.format(PercentageStartYThirdEndYFirst));

        softAssert.assertAll();
    }
}