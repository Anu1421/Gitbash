package dimensionofuielements;

import com.aventstack.extentreports.Status;
import genericutility.BaseClass;
import genericutility.JavaUtility;
import genericutility.iTestListenerImplementation;
import objectrepository.DashboardPage;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.text.DecimalFormat;

@Listeners(genericutility.iTestListenerImplementation.class)
public class DistanceBetweenHealthCardsUnderMyHealthSectionAndroid extends BaseClass {
    private static final DecimalFormat decimalFormat = new DecimalFormat("0.00");

    @Parameters("os")
    @Test
    public void distanceBetweenHealthCardsUnderMyHealthSection(String OS) {
        DashboardPage dashboardPage=new DashboardPage(driver);
        SoftAssert softAssert=new SoftAssert();
        JavaUtility javaUtility=new JavaUtility();

        //Scroll to my health section
        dashboardPage.swipeToMyHealthSection(driver, OS);

        //Fetch the dimension of the health card group
        String dimensionOfHealthCardGroup = dashboardPage.fetchTheDimensionsOfHealthCardGroup();
        String splitHealthCardGroup = javaUtility.fetchXAndYCoOrdinatesFromBounds(dimensionOfHealthCardGroup);
        int startXGroup = Integer.parseInt(splitHealthCardGroup.split(" ")[1]);
        int startYGroup = Integer.parseInt(splitHealthCardGroup.split(" ")[2]);
        int endXGroup = Integer.parseInt(splitHealthCardGroup.split(" ")[4]);
        int endYGroup = Integer.parseInt(splitHealthCardGroup.split(" ")[5]);

        //Fetch the dimension of the first health card
        String dimensionOfFirstHealthCard = dashboardPage.fetchTheDimensionsOfFirstHealthCard();
        String splitFirstHealthCard = javaUtility.fetchXAndYCoOrdinatesFromBounds(dimensionOfFirstHealthCard);
        int startXFirst = Integer.parseInt(splitFirstHealthCard.split(" ")[1]);
        int startYFirst = Integer.parseInt(splitFirstHealthCard.split(" ")[2]);
        int endXFirst = Integer.parseInt(splitFirstHealthCard.split(" ")[4]);
        int endYFirst = Integer.parseInt(splitFirstHealthCard.split(" ")[5]);

        //Fetch the dimension of the second health card
        String dimensionOfSecondHealthCard = dashboardPage.fetchTheDimensionsOfSecondHealthCard();
        String splitSecondHealthCard = javaUtility.fetchXAndYCoOrdinatesFromBounds(dimensionOfSecondHealthCard);
        int startXSecond = Integer.parseInt(splitSecondHealthCard.split(" ")[1]);
        int startYSecond = Integer.parseInt(splitSecondHealthCard.split(" ")[2]);
        int endXSecond = Integer.parseInt(splitSecondHealthCard.split(" ")[4]);
        int endYSecond = Integer.parseInt(splitSecondHealthCard.split(" ")[5]);

        //Fetch the dimension of the Third health card
        String dimensionOfThirdHealthCard = dashboardPage.fetchTheDimensionsOfThirdHealthCard();
        String splitThirdHealthCard = javaUtility.fetchXAndYCoOrdinatesFromBounds(dimensionOfThirdHealthCard);
        int startXThird = Integer.parseInt(splitThirdHealthCard.split(" ")[1]);
        int startYThird = Integer.parseInt(splitThirdHealthCard.split(" ")[2]);
        int endXThird = Integer.parseInt(splitThirdHealthCard.split(" ")[4]);
        int endYThird = Integer.parseInt(splitThirdHealthCard.split(" ")[5]);

        //Fetch the dimension of the Forth health card
        String dimensionOfForthHealthCard = dashboardPage.fetchTheDimensionsOfFourthHealthCard();
        String splitForthHealthCard = javaUtility.fetchXAndYCoOrdinatesFromBounds(dimensionOfForthHealthCard);
        int startXForth = Integer.parseInt(splitForthHealthCard.split(" ")[1]);
        int startYForth = Integer.parseInt(splitForthHealthCard.split(" ")[2]);
        int endXForth = Integer.parseInt(splitForthHealthCard.split(" ")[4]);
        int endYForth = Integer.parseInt(splitForthHealthCard.split(" ")[5]);

        //Get total dimension of Health Cards group
        double totalYDimGroup=endYGroup-startYGroup;
        double totalXDimGroup=endXGroup-startXGroup;

        //Get total dimension of first Health Card
        double totalYDimFirst=endYFirst-startYFirst;
        double totalXDimFirst=endXFirst-startXFirst;

        //Get total dimension of second Health Card
        double totalYDimSecond=endYSecond-startYSecond;
        double totalXDimSecond=endXSecond-startXSecond;

        //Get total dimension of third Health Card
        double totalYDimThird=endYThird-startYThird;
        double totalXDimThird=endXThird-startXThird;

        //Get total dimension of forth Health Card
        double totalYDimForth=endYForth-startYForth;
        double totalXDimForth=endXForth-startXForth;

        //Horizontal distance from left side of group to left side of first health card
        double diffBetStartXGroupStartXFirst = startXFirst - startXGroup;

        //Horizontal width of first health card
        double horizontalWidthFirst = endXFirst - startXFirst;

        //Horizontal distance from right side of first health card to left side of second health card
        double diffBetEndXFirstStartXSecond = startXSecond - endXFirst;

        //Horizontal width of second health card
        double horizontalWidthSecond = endXSecond - startXSecond;

        //Horizontal distance from right side of second health card to right side of health group
        double diffBetEndXSecondEndXGroup= endXGroup - endXSecond;

        //Vertical width of first health card
        double verticalWidthFirst = endYFirst - startYFirst;

        //Vertical distance between first and third health card
        double diffBetStartYThirdEndYFirst = startYThird - endYFirst;

        //Vertical width of third health card
        double verticalWidthThird = endYThird - startYThird;

        //Percentage Horizontal distance from left screen edge to left side of first health card
        double PercentageStartXGroupStartXFirst=(diffBetStartXGroupStartXFirst/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageStartXGroupStartXFirst)), "3.1");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal Distance from Left side of the Health card group to left side of the first health card in Zeplin is 3.1 and the percentage found in UI is "+decimalFormat.format(PercentageStartXGroupStartXFirst));

        //Percentage Horizontal width of first health card
        double PercentageHorizontalWidthFirst=(horizontalWidthFirst/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageHorizontalWidthFirst)), "46.1");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal width of the first health card in Zeplin is 46.1 and the percentage found in UI is "+decimalFormat.format(PercentageHorizontalWidthFirst));

        //Percentage Horizontal distance from right side of first health card to left side of second health card
        double PercentageEndXFirstStartXSecond=(diffBetEndXFirstStartXSecond/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageEndXFirstStartXSecond)), "1.7");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal Distance from right side of the first health card to left side of the second health card in Zeplin is 1.7 and the percentage found in UI is "+decimalFormat.format(PercentageEndXFirstStartXSecond));

        //Percentage Horizontal width of second health card
        double PercentageHorizontalWidthSecond=(horizontalWidthSecond/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageHorizontalWidthSecond)), "46.1");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal width of the second health card in Zeplin is 46.1 and the percentage found in UI is "+decimalFormat.format(PercentageHorizontalWidthSecond));

        //Percentage Horizontal distance from right side of second health card to screen right edge
        double PercentageEndXSecondEndXGroup=(diffBetEndXSecondEndXGroup/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageEndXSecondEndXGroup)), "2.9");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal Distance from right side of second health card to right side of the Health card group in Zeplin is 2.9 and the percentage found in UI is "+decimalFormat.format(PercentageEndXSecondEndXGroup));

        //Percentage Vertical distance from bottom of first health card to top of third health card
        double PercentageStartYThirdEndYFirst=(diffBetStartYThirdEndYFirst/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageStartYThirdEndYFirst)), "1.31");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Vertical Distance from bottom of the first health card to top of the third health card in Zeplin is 1.31 and the percentage found in UI is "+decimalFormat.format(PercentageStartYThirdEndYFirst));

        softAssert.assertAll();
    }
}