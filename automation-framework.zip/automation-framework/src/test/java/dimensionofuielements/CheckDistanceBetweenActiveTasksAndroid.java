package dimensionofuielements;

import com.aventstack.extentreports.Status;
import genericutility.BaseClass;
import genericutility.JavaUtility;
import genericutility.iTestListenerImplementation;
import objectrepository.DashboardPage;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.text.DecimalFormat;

@Listeners(genericutility.iTestListenerImplementation.class)
public class CheckDistanceBetweenActiveTasksAndroid extends BaseClass {
    private static final DecimalFormat decimalFormat = new DecimalFormat("0.00");

    @Test
    public void checkDistanceBetweenActiveTasks(){
        JavaUtility javaUtility=new JavaUtility();
        DashboardPage dashboardPage=new DashboardPage(driver);
        SoftAssert softAssert=new SoftAssert();

        //fetch x and y axis of Active tasks group
        String dimensionsActiveTasksGroup = dashboardPage.fetchTheDimensionsOfActiveTasksGroup();
        String splitGroup = javaUtility.fetchXAndYCoOrdinatesFromBounds(dimensionsActiveTasksGroup);
        int startXGroup = Integer.parseInt(splitGroup.split(" ")[1]);
        int startYGroup = Integer.parseInt(splitGroup.split(" ")[2]);
        int endXGroup = Integer.parseInt(splitGroup.split(" ")[4]);
        int endYGroup = Integer.parseInt(splitGroup.split(" ")[5]);

        //fetch x and y axis of First Active task
        String dimensionsFirstActiveTask = dashboardPage.fetchTheDimensionsOfFirstActiveTask();
        String splitFirst = javaUtility.fetchXAndYCoOrdinatesFromBounds(dimensionsFirstActiveTask);
        int startXFirst = Integer.parseInt(splitFirst.split(" ")[1]);
        int startYFirst = Integer.parseInt(splitFirst.split(" ")[2]);
        int endXFirst = Integer.parseInt(splitFirst.split(" ")[4]);
        int endYFirst = Integer.parseInt(splitFirst.split(" ")[5]);

        //fetch x and y axis of Second Active task
        String dimensionsSecondActiveTask = dashboardPage.fetchTheDimensionsOfSecondActiveTask();
        String splitSecond = javaUtility.fetchXAndYCoOrdinatesFromBounds(dimensionsSecondActiveTask);
        int startXSecond = Integer.parseInt(splitSecond.split(" ")[1]);
        int startYSecond = Integer.parseInt(splitSecond.split(" ")[2]);
        int endXSecond = Integer.parseInt(splitSecond.split(" ")[4]);
        int endYSecond = Integer.parseInt(splitSecond.split(" ")[5]);

        //Get total dimension of Active tasks group
        double totalYDimGroup=endYGroup-startYGroup;
        double totalXDimGroup=endXGroup-startXGroup;

        //Get total dimension of first Active tasks Card
        double totalYDimFirst=endYFirst-startYFirst;
        double totalXDimFirst=endXFirst-startXFirst;

        //Get total dimension of second Active tasks Card
        double totalYDimSecond=endYSecond-startYSecond;
        double totalXDimSecond=endXSecond-startXSecond;

        //Horizontal distance from left side of group to left side of first active task
        double diffBetStartXGroupStartXFirst = startXFirst - startXGroup;

        //Horizontal width of first active task
        double horizontalWidthFirst = endXFirst - startXFirst;

        //Horizontal distance from right side of first active task to left side of second active task
        double diffBetEndXFirstStartXSecond = startXSecond - endXFirst;

        //Horizontal width of second active task
        double horizontalWidthSecond = endXSecond - startXSecond;

        //Percentage Horizontal distance from left side of active task group to left side of first active task
        double PercentageStartXGroupStartXFirst=(diffBetStartXGroupStartXFirst/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageStartXGroupStartXFirst)), "3.6");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal Distance from Left side of the active task group to left side of the first active task in Zeplin is 3.6 and the percentage found in UI is "+decimalFormat.format(PercentageStartXGroupStartXFirst));

        //Percentage Horizontal width of first active task
        double PercentageHorizontalWidthFirst=(horizontalWidthFirst/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageHorizontalWidthFirst)), "55.3");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal width of the first active task in Zeplin is 55.3 and the percentage found in UI is "+decimalFormat.format(PercentageHorizontalWidthFirst));

        //Percentage Horizontal distance from right side of first active task to left side of second active task
        double PercentageEndXFirstStartXSecond=(diffBetEndXFirstStartXSecond/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageEndXFirstStartXSecond)), "2.8");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal Distance from right side of the first active task to left side of the second active task in Zeplin is 2.8 and the percentage found in UI is "+decimalFormat.format(PercentageEndXFirstStartXSecond));

        //Percentage Horizontal width of second active task
        double PercentageHorizontalWidthSecond=(horizontalWidthSecond/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageHorizontalWidthSecond)), "38.3");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal width of the second active task in Zeplin is 38.3 and the percentage found in UI is "+decimalFormat.format(PercentageHorizontalWidthSecond));

        softAssert.assertAll();
    }
}