package dimensionofuielements;

import com.aventstack.extentreports.Status;
import genericutility.BaseClass;
import genericutility.iTestListenerImplementation;
import objectrepository.DashboardPage;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.text.DecimalFormat;

@Listeners(iTestListenerImplementation.class)
public class CheckDistanceBetweenProgressCircles extends BaseClass {
    private static final DecimalFormat decimalFormat = new DecimalFormat("0.00");
    @Test
    public void checkDistanceBetweenProgressCirclesIOS(){
//        JavaUtility javaUtility=new JavaUtility();
        DashboardPage dashboardPage=new DashboardPage(driver);
        SoftAssert softAssert=new SoftAssert();

        //fetch x and y axis of progress circles group
        String dimensionsCircleGroupIOS = dashboardPage.fetchTheDimensionsOfProgressCircleGroupIOS();
        int startXGroup = Integer.parseInt(dimensionsCircleGroupIOS.split(" ")[0]);
        int startYGroup = Integer.parseInt(dimensionsCircleGroupIOS.split(" ")[1]);
        int endXGroup = Integer.parseInt(dimensionsCircleGroupIOS.split(" ")[2]);
        int endYGroup = Integer.parseInt(dimensionsCircleGroupIOS.split(" ")[3]);


        //fetch x and y axis of step progress circles
        String dimensionsStepCircleIOS = dashboardPage.fetchTheDimensionsOfStepProgressCircleIOS();
//        String splitStep = javaUtility.fetchXAndYCoOrdinatesFromBounds(dimensionsStepCircle);
        int startXStep = Integer.parseInt(dimensionsStepCircleIOS.split(" ")[0]);
        int startYStep = Integer.parseInt(dimensionsStepCircleIOS.split(" ")[1]);
        int endXStep = Integer.parseInt(dimensionsStepCircleIOS.split(" ")[2]);
        int endYStep = Integer.parseInt(dimensionsStepCircleIOS.split(" ")[3]);

        //fetch x and y axis of sleep progress circles
        String dimensionsSleepCircleIOS = dashboardPage.fetchTheDimensionsOfSleepProgressCircleIOS();
//        String splitSleep = javaUtility.fetchXAndYCoOrdinatesFromBounds(dimensionsSleepCircle);
        int startXSleep = Integer.parseInt(dimensionsSleepCircleIOS.split(" ")[0]);
        int startYSleep = Integer.parseInt(dimensionsSleepCircleIOS.split(" ")[1]);
        int endXSleep = Integer.parseInt(dimensionsSleepCircleIOS.split(" ")[2]);
        int endYSleep = Integer.parseInt(dimensionsSleepCircleIOS.split(" ")[3]);

        //fetch x and y axis of MultiSport progress circles
        String dimensionsMultiSportCircleIOS = dashboardPage.fetchTheDimensionsOfMultiSportProgressCircleIOS();
//        String splitMultiSport = javaUtility.fetchXAndYCoOrdinatesFromBounds(dimensionsMultiSportCircle);
        int startXMultiSport = Integer.parseInt(dimensionsMultiSportCircleIOS.split(" ")[0]);
        int startYMultiSport = Integer.parseInt(dimensionsMultiSportCircleIOS.split(" ")[1]);
        int endXMultiSport = Integer.parseInt(dimensionsMultiSportCircleIOS.split(" ")[2]);
        int endYMultiSport = Integer.parseInt(dimensionsMultiSportCircleIOS.split(" ")[3]);

        //Get total dimensions of progress circle group
        double totalYDim=endYGroup-startYGroup;
        double totalXDim=endXGroup-startXGroup;

        //Get total diameter of the step progress circle
        double diameterStep=endXStep-startXStep;

        //Get total diameter of the sleep progress circle
        double diameterSleep=endXSleep-startXSleep;

        //Get total diameter of the MultiSport progress circle
        double diameterMultiSport=endXMultiSport-startXMultiSport;

        //get the distance between Y axis value of progress circle group and step progress circle
        double diffBetStartYStep=startYStep-startYGroup;
        double diffBetEndYStep=endYGroup-endYStep;

        //get the distance between X axis value of progress circle group and step progress circle
        double diffBetStartXStep=startXStep-startXGroup;
        double diffBetEndXStep=endXGroup-endXStep;

        //Percentage of distance between StartY of Progress Circle Group and StartY of Step Progress Circle
        double PercentageStartYStep=(diffBetStartYStep/totalYDim)*100;
//        Reporter.log("Percentage Distance from Top of the Circle group to top of the Step progress circle is "+String.valueOf(decimalFormat.format(PercentageStartYStep))+"%",true);
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageStartYStep)), "12.6");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Distance from Top of the Circle group to top of the Step progress circle in Zeplin is 12.6 and the percentage found in UI is "+decimalFormat.format(PercentageStartYStep));

        //Percentage of distance between EndY of Progress Circle Group and EndY of Step Progress Circle
        double PercentageEndYStep=(diffBetEndYStep/totalYDim)*100;
//        Reporter.log("Percentage Distance from Bottom of the Circle group to bottom of the Step progress circle is "+String.valueOf(decimalFormat.format(PercentageEndYStep))+"%",true);
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageEndYStep)), "29.7");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Distance from Bottom of the Circle group to bottom of the Step progress circle in Zeplin is 29.70 and the percentage found in UI is "+decimalFormat.format(PercentageEndYStep));

        //Percentage of distance between StartX of Progress Circle Group and StartX of Step Progress Circle
        double PercentageStartXStep=(diffBetStartXStep/totalXDim)*100;
//        System.out.printf("Percentage Distance from Left side of the Circle group to left edge of the Step progress circle is %.02f%s", PercentageStartXStep,"%");
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageStartXStep)), "32.4");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Distance from Left side of the Circle group to left edge of the Step progress circle in Zeplin is 32.40 and the percentage found in UI is "+decimalFormat.format(PercentageStartXStep));

        //Percentage of distance between EndX of Progress Circle Group and EndX of Step Progress Circle
        double PercentageEndXStep=(diffBetEndXStep/totalXDim)*100;
//        System.out.printf("Percentage Distance from Right side of the Circle group to right edge of the Step progress circle is %.02f%s", PercentageEndXStep,"%");
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageEndXStep)), "35.2");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Distance from Right side of the Circle group to right edge of the Step progress circle in Zeplin is 35.20 and the percentage found in UI is "+decimalFormat.format(PercentageEndXStep));

        //Percentage of the diameter of the Step Progress circle
        double percentageDiameterStep=(diameterStep/totalXDim)*100;
//        System.out.printf("Percentage Diameter of the Step progress circle is %.02f%s", percentageDiameterStep,"%");
        softAssert.assertEquals(String.valueOf(decimalFormat.format(percentageDiameterStep)), "32.4");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Diameter of the Step progress circle in Zeplin is 32.40 and the percentage found in UI is "+decimalFormat.format(percentageDiameterStep));

//        System.out.println("********************************************************************************");

        //get the distance between Y axis value of progress circle group and sleep progress circle
        double diffBetStartYSleep=startYSleep-startYGroup;
        double diffBetEndYSleep=endYGroup-endYSleep;

        //get the distance between X axis value of progress circle group and sleep progress circle
        double diffBetStartXSleep=startXSleep-startXGroup;
        double diffBetEndXSleep=endXGroup-endXSleep;

        //Percentage of distance between StartY of Progress Circle Group and StartY of Sleep Progress Circle
        double PercentageStartYSleep=(diffBetStartYSleep/totalYDim)*100;
//        System.out.printf("Percentage Distance from Top of the Circle group to top of the Sleep progress circle is %.02f%s", PercentageStartYSleep,"%");
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageStartYSleep)), "32.9");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Distance from Top of the Circle group to top of the Sleep progress circle in Zeplin is 32.90 and the percentage found in UI is "+decimalFormat.format(PercentageStartYSleep));

        //Percentage of distance between EndY of Progress Circle Group and EndY of Sleep Progress Circle
        double PercentageEndYSleep=(diffBetEndYSleep/totalYDim)*100;
//        System.out.printf("Percentage Distance from Bottom of the Circle group to bottom of the Sleep progress circle is %.02f%s", PercentageEndYSleep,"%");
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageEndYSleep)), "15.9");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Distance from Bottom of the Circle group to bottom of the Sleep progress circle in Zeplin is 15.90 and the percentage found in UI is "+decimalFormat.format(PercentageEndYSleep));

        //Percentage of distance between StartX of Progress Circle Group and StartX of Sleep Progress Circle
        double PercentageStartXSleep=(diffBetStartXSleep/totalXDim)*100;
//        System.out.printf("Percentage Distance from Left side of the Circle group to left edge of the Sleep progress circle is %.02f%s", PercentageStartXSleep,"%");
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageStartXSleep)), "2.8");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Distance from Left side of the Circle group to left edge of the Sleep progress circle in Zeplin is 2.80 and the percentage found in UI is "+decimalFormat.format(PercentageStartXSleep));

        //Percentage of distance between EndX of Progress Circle Group and EndX of Sleep Progress Circle
        double PercentageEndXSleep=(diffBetEndXSleep/totalXDim)*100;
//        System.out.printf("Percentage Distance from Right side of the Circle group to right edge of the Sleep progress circle is %.02f%s", PercentageEndXSleep,"%");
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageEndXSleep)), "68.4");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Distance from Right side of the Circle group to right edge of the Sleep progress circle in Zeplin is 68.40 and the percentage found in UI is "+decimalFormat.format(PercentageEndXSleep));

        //Percentage of the diameter of the Sleep Progress circle
        double percentageDiameterSleep=(diameterSleep/totalXDim)*100;
//        System.out.printf("Percentage Diameter of the Sleep progress circle is %.02f%s", percentageDiameterSleep,"%");
        softAssert.assertEquals(String.valueOf(decimalFormat.format(percentageDiameterSleep)), "28.8");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Diameter of the Sleep progress circle in Zeplin is 28.80 and the percentage found in UI is "+decimalFormat.format(percentageDiameterSleep));

        //get the distance between Y axis value of progress circle group and MultiSport progress circle
        double diffBetStartYMultiSport=startYMultiSport-startYGroup;
        double diffBetEndYMultiSport=endYGroup-endYMultiSport;

        //get the distance between X axis value of progress circle group and MultiSport progress circle
        double diffBetStartXMultiSport=startXMultiSport-startXGroup;
        double diffBetEndXMultiSport=endXGroup-endXMultiSport;

        //Percentage of distance between StartY of Progress Circle Group and StartY of MultiSport Progress Circle
        double PercentageStartYMultiSport=(diffBetStartYMultiSport/totalYDim)*100;
//        System.out.printf("Percentage Distance from Top of the Circle group to top of the MultiSport progress circle is %.02f%s", PercentageStartYMultiSport,"%");
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageStartYMultiSport)), "32.9");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Distance from Top of the Circle group to top of the MultiSport progress circle in Zeplin is 32.90 and the percentage found in UI is "+decimalFormat.format(PercentageStartYMultiSport));

        //Percentage of distance between EndY of Progress Circle Group and EndY of MultiSport Progress Circle
        double PercentageEndYMultiSport=(diffBetEndYMultiSport/totalYDim)*100;
//        System.out.printf("Percentage Distance from Bottom of the Circle group to bottom of the MultiSport progress circle is %.02f%s", PercentageEndYMultiSport,"%");
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageEndYMultiSport)), "15.9");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Distance from Bottom of the Circle group to bottom of the MultiSport progress circle in Zeplin is 15.90 and the percentage found in UI is "+decimalFormat.format(PercentageEndYMultiSport));

        //Percentage of distance between StartX of Progress Circle Group and StartX of MultiSport Progress Circle
        double PercentageStartXMultiSport=(diffBetStartXMultiSport/totalXDim)*100;
//        System.out.printf("Percentage Distance from Left side of the Circle group to left edge of the MultiSport progress circle is %.02f%s", PercentageStartXMultiSport,"%");
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageStartXMultiSport)), "65.8");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Distance from Left side of the Circle group to left edge of the MultiSport progress circle in Zeplin is 65.80 and the percentage found in UI is "+decimalFormat.format(PercentageStartXMultiSport));

        //Percentage of distance between EndX of Progress Circle Group and EndX of MultiSport Progress Circle
        double PercentageEndXMultiSport=(diffBetEndXMultiSport/totalXDim)*100;
//        System.out.printf("Percentage Distance from Right side of the Circle group to right edge of the MultiSport progress circle is %.02f%s", PercentageEndXMultiSport,"%");
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageEndXMultiSport)), "5.4");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Distance from Right side of the Circle group to right edge of the MultiSport progress circle in Zeplin is 5.40 and the percentage found in UI is "+decimalFormat.format(PercentageEndXMultiSport));

        //Percentage of the diameter of the MultiSport Progress circle
        double percentageDiameterMultiSport=(diameterMultiSport/totalXDim)*100;
//        System.out.printf("Percentage Diameter of the MultiSport progress circle is %.02f%s", percentageDiameterMultiSport,"%");
        softAssert.assertEquals(String.valueOf(decimalFormat.format(percentageDiameterMultiSport)), "28.8");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Diameter of the MultiSport progress circle in Zeplin is 28.80 and the percentage found in UI is "+decimalFormat.format(percentageDiameterMultiSport));

        //Fetch the dimensions of all progress circle edges
        int distanceBetweenStepAndSleep = startXStep - endXSleep;
        int distanceBetweenStepAndMultiSport = startXMultiSport - endXStep;
        int distanceBetweenSleepAndMultiSport = startXMultiSport - endXSleep;

        //Percentage of distance between Step and Sleep progress circles
        double PercentageDistanceBetweenStepAndSleep = (distanceBetweenStepAndSleep / totalXDim)*100;
//        System.out.printf("Percentage distance between Step And Sleep progress circle is %.02f%s", PercentageDistanceBetweenStepAndSleep,"%");
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageDistanceBetweenStepAndSleep)), "1");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage distance between Step And Sleep progress circle in Zeplin is 1 and the percentage found in UI is "+decimalFormat.format(PercentageDistanceBetweenStepAndSleep));

        //Percentage of distance between Step and MultiSport progress circles
        double PercentageDistanceBetweenStepAndMultiSport = (distanceBetweenStepAndMultiSport / totalXDim)*100;
//        System.out.printf("Percentage distance between Step And MultiSport progress circle is %.02f%s", PercentageDistanceBetweenStepAndMultiSport,"%");
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageDistanceBetweenStepAndMultiSport)), "1");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage distance between Step And MultiSport progress circle in Zeplin is 1 and the percentage found in UI is "+decimalFormat.format(PercentageDistanceBetweenStepAndMultiSport));

        //Percentage of distance between MultiSport and Sleep progress circles
        double PercentageDistanceBetweenSleepAndMultiSport = (distanceBetweenSleepAndMultiSport / totalXDim)*100;
//        System.out.printf("Percentage distance between MultiSport And Sleep progress circle is %.02f%s", PercentageDistanceBetweenSleepAndMultiSport,"%");
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageDistanceBetweenSleepAndMultiSport)), "35.2");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage distance between MultiSport And Sleep progress circle in Zeplin is 35.20 and the percentage found in UI is "+decimalFormat.format(PercentageDistanceBetweenSleepAndMultiSport));

        softAssert.assertAll();
    }
}