package dimensionofuielements;

import com.aventstack.extentreports.Status;
import genericutility.BaseClass;
import genericutility.iTestListenerImplementation;
import objectrepository.DashboardPage;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.text.DecimalFormat;

@Listeners(iTestListenerImplementation.class)
public class CheckDistanceBetweenActiveTasks extends BaseClass {
    private static final DecimalFormat decimalFormat = new DecimalFormat("0.00");
    @Test
    public void checkDistanceBetweenActiveTasksIOS(){
        DashboardPage dashboardPage=new DashboardPage(driver);
        SoftAssert softAssert=new SoftAssert();

        //fetch x and y axis of Active tasks group
        String dimensionsActiveTasksGroupIOS = dashboardPage.fetchTheDimensionsOfActiveTaskGroupIOS();
        int startXGroup = Integer.parseInt(dimensionsActiveTasksGroupIOS.split(" ")[0]);
        int startYGroup = Integer.parseInt(dimensionsActiveTasksGroupIOS.split(" ")[1]);
        int endXGroup = Integer.parseInt(dimensionsActiveTasksGroupIOS.split(" ")[2]);
        int endYGroup = Integer.parseInt(dimensionsActiveTasksGroupIOS.split(" ")[3]);

        //fetch x and y axis of First Active task
        String dimensionsFirstActiveTaskIOS = dashboardPage.fetchTheDimensionsOfFirstActiveTaskIOS();
        int startXFirst = Integer.parseInt(dimensionsFirstActiveTaskIOS.split(" ")[0]);
        int startYFirst = Integer.parseInt(dimensionsFirstActiveTaskIOS.split(" ")[1]);
        int endXFirst = Integer.parseInt(dimensionsFirstActiveTaskIOS.split(" ")[2]);
        int endYFirst = Integer.parseInt(dimensionsFirstActiveTaskIOS.split(" ")[3]);

        //fetch x and y axis of Second Active task
        String dimensionsSecondActiveTaskIOS = dashboardPage.fetchTheDimensionsOfSecondActiveTaskIOS();
        int startXSecond = Integer.parseInt(dimensionsSecondActiveTaskIOS.split(" ")[0]);
        int startYSecond = Integer.parseInt(dimensionsSecondActiveTaskIOS.split(" ")[1]);
        int endXSecond = Integer.parseInt(dimensionsSecondActiveTaskIOS.split(" ")[2]);
        int endYSecond = Integer.parseInt(dimensionsSecondActiveTaskIOS.split(" ")[3]);

        //Get total dimension of Active tasks group
        double totalYDimGroup=endYGroup-startYGroup;
        double totalXDimGroup=endXGroup-startXGroup;

        //Get total dimension of first Active tasks Card
        double totalYDimFirst=endYFirst-startYFirst;
        double totalXDimFirst=endXFirst-startXFirst;

        //Get total dimension of second Active tasks Card
        double totalYDimSecond=endYSecond-startYSecond;
        double totalXDimSecond=endXSecond-startXSecond;

        //Horizontal distance from left side of group to left side of first active task
        double diffBetStartXGroupStartXFirst = startXFirst - startXGroup;

        //Horizontal width of first active task
        double horizontalWidthFirst = endXFirst - startXFirst;

        //Horizontal distance from right side of first active task to left side of second active task
        double diffBetEndXFirstStartXSecond = startXSecond - endXFirst;

        //Horizontal width of second active task
        double horizontalWidthSecond = endXSecond - startXSecond;

        //Horizontal distance from right side of second active task to right side of active task group
        double diffBetEndXSecondEndXGroup = endXGroup - endXSecond;

        //Percentage Horizontal distance from left side of active task group to left side of first active task
        double PercentageStartXGroupStartXFirst=(diffBetStartXGroupStartXFirst/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageStartXGroupStartXFirst)), "3.6");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal Distance from Left side of the active task group to left side of the first active task in Zeplin is 3.6 and the percentage found in UI is "+decimalFormat.format(PercentageStartXGroupStartXFirst));

        //Percentage Horizontal width of first active task
        double PercentageHorizontalWidthFirst=(horizontalWidthFirst/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageHorizontalWidthFirst)), "55.3");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal width of the first active task in Zeplin is 55.3 and the percentage found in UI is "+decimalFormat.format(PercentageHorizontalWidthFirst));

        //Percentage Horizontal distance from right side of first active task to left side of second active task
        double PercentageEndXFirstStartXSecond=(diffBetEndXFirstStartXSecond/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageEndXFirstStartXSecond)), "2.8");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal Distance from right side of the first active task to left side of the second active task in Zeplin is 2.8 and the percentage found in UI is "+decimalFormat.format(PercentageEndXFirstStartXSecond));

        //Percentage Horizontal width of second active task
        double PercentageHorizontalWidthSecond=(horizontalWidthSecond/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageHorizontalWidthSecond)), "38.3");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal width of the second active task in Zeplin is 38.3 and the percentage found in UI is "+decimalFormat.format(PercentageHorizontalWidthSecond));

        //Percentage Horizontal distance from right side of second active task to right side of active task group
        double PercentageEndXSecondEndXGroup=(diffBetEndXSecondEndXGroup/totalXDimGroup)*100;
        softAssert.assertEquals(String.valueOf(decimalFormat.format(PercentageEndXSecondEndXGroup)), "0");
        iTestListenerImplementation.test.log(Status.FAIL, "The Percentage Horizontal Distance from right side of the first active task to left side of the second active task in Zeplin is 0 and the percentage found in UI is "+decimalFormat.format(PercentageEndXFirstStartXSecond));

        softAssert.assertAll();
    }
}