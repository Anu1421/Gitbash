package sampletests;

import com.google.common.collect.ImmutableMap;
import genericutility.AndroidWebDriverUtility;
import genericutility.BaseClass;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import objectrepository.DashboardPage;
import objectrepository.HeartRatePage;
import objectrepository.SettingsPage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

public class Sample extends BaseClass {
    AndroidWebDriverUtility androidWebDriverUtility = new AndroidWebDriverUtility();
    DashboardPage dashboardPage ;
    public void swipe(WebDriver driver,int startX, int startY, int endX, int endY, int swipeTime,String direction) {
//        TouchAction touchAction=new TouchAction((PerformsTouchActions) driver);
//        touchAction.press(PointOption.point(startX, startY))
//                .waitAction(waitOptions(Duration.ofSeconds(swipeTime)))
//                .moveTo(PointOption.point(endX, endY)).release().perform();
        HashMap<String, Object> swipeObject = new HashMap<String, Object>();
        swipeObject.put("startX", startX);
        swipeObject.put("startY", startY);
        swipeObject.put("endX", endX);
        swipeObject.put("endY", endY);
        swipeObject.put("duration", swipeTime);
        swipeObject.put("direction",direction);
        ((AndroidDriver)driver).executeScript("mobile: swipeGesture", swipeObject);
    }

    public static void dragElementToElement( WebDriver driver, WebElement ele, WebElement toElement, int speed)
    {
        HashMap<Object,Object> args = new HashMap<>();
        args.put("elementId", ((RemoteWebElement)ele).getId());
        int endX=toElement.getLocation().getX()+toElement.getSize().getWidth();
        int endY=toElement.getLocation().getY()+toElement.getSize().getHeight();
        //System.out.println(endX+" "+endY);
        args.put("endX", endX);
        args.put("endY", endY);
        args.put("speed",speed*250);
        ((AndroidDriver)driver).executeScript("mobile:dragGesture", args);

    }

//    public static void scrollToElement(WebDriver driver,String direction, String attribute, String value) {
//        HashMap<String, Object> scrollObject = new HashMap<String, Object>();
//        scrollObject.put("strategy", "scroll");
//        scrollObject.put("selector", "1");
//        scrollObject.put("direction", direction);
//        scrollObject.put("element", null);
//        scrollObject.put("text", value);
//        scrollObject.put("elementToMatch", attribute);
//        ((AndroidDriver)driver).executeScript("mobile:scroll", scrollObject);
//    }

    public static void scrollToElement(WebDriver driver,String direction,String attribute, String value) {
            String selector = "new UiSelector().descriptionContains(\"" + value + "\").resourceIdMatches(\".*" + attribute + ".*\")";
            HashMap<String, String> scrollObject = new HashMap<String, String>();
            scrollObject.put("direction", direction);
            scrollObject.put("selector", selector);
        ((AndroidDriver)driver).executeScript("mobile:scrollGesture", scrollObject);
        }





    @Test
    public void androidSampleTest() {
        dashboardPage = new DashboardPage(driver);
        scrollToElement(driver,"up","text","Music for you");
    }

}