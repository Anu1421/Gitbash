package tests;

import genericutility.BaseClass;
import genericutility.JSONUtility;
import genericutility.JavaUtility;
import io.appium.java_client.InteractsWithApps;
import io.appium.java_client.android.AndroidDriver;
import objectrepository.*;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

@Listeners(genericutility.iTestListenerImplementation.class)
public class HeartRateModuleTest extends BaseClass {

    DashboardPage dashboardPage;
    HeartRatePage heartRatePage;
    NotificationAndControlCentre notificationAndControlCentre;
    CalendarPage calendarPage;
    JavaUtility javaUtility;

    @Parameters({"deviceName","os"})
    @Test
    public void tc006_HeartRateCurrentAndPreviousWeekViewTest(String deviceName, String OS){
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Heart Rate Summary Icon
        dashboardPage.clickOnHeartRateUnderMyHealth();
        //Click on Week tab
        heartRatePage=new HeartRatePage(driver);
        heartRatePage.clickOnWeekTab();
        //Navigate to previous weeks by clicking on previous toggle button
        heartRatePage.clickOnPreviousBtn();
        Reporter.log("HeartRate_TC006_HeartRateCurrentAndPreviousWeekViewTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc008_HeartRateCurrentAndPreviousMonthViewTest(String deviceName, String OS){
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Heart Rate Summary Icon
        dashboardPage.clickOnHeartRateUnderMyHealth();
        //Click on Month tab
        heartRatePage=new HeartRatePage(driver);
        heartRatePage.clickOnMonthTab();
        //Navigate to previous month by clicking on previous toggle button
        heartRatePage.clickOnPreviousBtn();
        Reporter.log("HeartRate_TC008_HeartRateCurrentAndPreviousMonthViewTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName", "os"})
    @Test
    public void tc010_HeartRateSummaryWhenNoInternetTest(String deviceName, String OS){
        //turn off Wi-Fi
        notificationAndControlCentre = new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleWiFi(driver, OS);
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Heart Rate Summary Icon
        dashboardPage.clickOnHeartRateUnderMyHealth();
        //Click on Week tab
        heartRatePage=new HeartRatePage(driver);
        heartRatePage.clickOnWeekTab();
        //Click on Month tab
        heartRatePage.clickOnMonthTab();
        Reporter.log("HeartRate_TC010_HeartRateSummaryWhenNoInternetTest is pass on " + deviceName, true);
        //Turn on Wi-Fi
        notificationAndControlCentre.toggleWiFi(driver, OS);
    }

    @Parameters({"deviceName", "os"})
    @Test
    public void tc011_014_015_HeartRateSummaryWhenBTOffAndBackArrowKillAppAndReopenTest(String deviceName, String OS){
        //Turn Off Bluetooth
        notificationAndControlCentre = new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleBluetooth(driver, OS);
        //close bluetooth PopUp
        BluetoothIsOffPopUp btpopUp=new BluetoothIsOffPopUp(driver);
        btpopUp.clickOnClosePopUpBtn();
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Heart Rate Summary Icon
        dashboardPage.clickOnHeartRateUnderMyHealth();
        //Click on Week tab
        heartRatePage=new HeartRatePage(driver);
        heartRatePage.clickOnWeekTab();
        //Click on Month tab
        heartRatePage.clickOnMonthTab();
        //Turn on bluetooth
        notificationAndControlCentre.toggleBluetooth(driver, OS);
        Reporter.log("HeartRate_TC011_HeartRateSummaryWhenBTOffTest is pass on " + deviceName, true);
        //Click on Back btn in HR screen
        heartRatePage.clickOnBackBtn();
        //Check if user lands in Dashboard screen
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("HeartRate_TC014_HeartRateBackArrowTest is pass on " + deviceName, true);
        //Click on Heart Rate Summary Icon
        dashboardPage.clickOnHeartRateUnderMyHealth();
        //Kill app and reopen
        try {
            ((InteractsWithApps)driver).terminateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
        }
        catch (Exception e){
            e.printStackTrace();
        }
        ((InteractsWithApps)driver).activateApp((String) JSONUtility.fetchDataFromJson(deviceName,"AppPackage"));
        //Check if user lands in Dashboard screen
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("HeartRate_TC015_HeartRateKillAppAndReopenTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc012_HeartRateSummariesWatchNotConnectedTest(String deviceName, String OS) {
        //Unpair the watch
        dashboardPage=new DashboardPage(driver);
        dashboardPage.unpairWatch(driver);
        //Swipe down to My Health section
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Heart Rate Summary Icon
        dashboardPage.clickOnHeartRateUnderMyHealth();
        //Check if user lands in Heart Rate Summary screen
        heartRatePage=new HeartRatePage(driver);
        heartRatePage.checkIfUserLandsInHeartRatePage();
        Reporter.log("HeartRate_TC012_HeartRateSummariesWatchNotConnectedTest is pass on " + deviceName, true);
        //Pair the watch
        heartRatePage.clickOnBackBtn();
        dashboardPage.pairWatch();
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc017_HeartRateDayViewOfHRTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Heart Rate Summary Icon
        dashboardPage.clickOnHeartRateUnderMyHealth();
        //Click on Calendar icon
        heartRatePage=new HeartRatePage(driver);
        heartRatePage.clickOnCalendarIcon();
        //Click on 22 Dec date which has HR data
        calendarPage=new CalendarPage(driver);
        calendarPage.clickOnYear2023MonthFebruaryAndDate16ndOkBtn();
        //Check if 22 Dec HR data is displayed
        heartRatePage.checkIfUserLandsInSelectedDateHRPage("16 Feb");
        Reporter.log("HeartRate_TC017_HeartRateDayViewOfHRTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc018_HeartRateWeekViewOfHRTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Heart Rate Summary Icon
        dashboardPage.clickOnHeartRateUnderMyHealth();
        //Click on week tab
        heartRatePage=new HeartRatePage(driver);
        heartRatePage.clickOnWeekTab();
        //Click on Calendar icon
        heartRatePage=new HeartRatePage(driver);
        heartRatePage.clickOnCalendarIcon();
        //Click on 19-25 week of Dec which has HR data
        calendarPage=new CalendarPage(driver);
        calendarPage.clickOnYear2022MonthDecemberAndDate18AndOkBtn();
        //Check if 19 to 25 Dec HR data is displayed
        heartRatePage.checkIfUserLandsInSelectedDateHRPage("12 - 18 Dec");
        Reporter.log("HeartRate_TC018_HeartRateWeekViewOfHRTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc019_HeartRateMonthViewOfHRTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Heart Rate Summary Icon
        dashboardPage.clickOnHeartRateUnderMyHealth();
        //Click on month tab
        heartRatePage=new HeartRatePage(driver);
        heartRatePage.clickOnMonthTab();
        //Click on Calendar icon
        heartRatePage=new HeartRatePage(driver);
        heartRatePage.clickOnCalendarIcon();
        //Click on December month
        calendarPage=new CalendarPage(driver);
        calendarPage.clickOn2022YearAndDecemberMonth();
        //Check if December HR data is displayed
        heartRatePage.checkIfUserLandsInSelectedDateHRPage("Dec");
        Reporter.log("HeartRate_TC019_HeartRateMonthViewOfHRTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc020_HeartRateShiftBetweenDayWeekMonthSummariesTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Heart Rate Summary Icon
        dashboardPage.clickOnHeartRateUnderMyHealth();
        //Click on Day tab
        heartRatePage=new HeartRatePage(driver);
        heartRatePage.clickOnDayTab();
        //Check if Today HR data is displayed
        heartRatePage.checkIfUserLandsInSelectedDateHRPage("Today");
        //Click on Week tab
        heartRatePage.clickOnWeekTab();
        //Check if current Week HR data is displayed
        javaUtility=new JavaUtility();
        heartRatePage.checkIfUserLandsInSelectedDateHRPage(javaUtility.getDatesFromMonToSunForPresentWeek());
        //Click on month tab
        heartRatePage.clickOnMonthTab();
        //Check if current month HR data is displayed
        heartRatePage.checkIfUserLandsInSelectedDateHRPage(javaUtility.fetchOnlyMonthInMonFormat());
        Reporter.log("HeartRate_TC020_HeartRateShiftBetweenDayWeekMonthSummariesTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc021_022_023_032_HeartRateBurningZonesAndPercentageAndScreenTitleAndIconTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Heart Rate Summary Icon
        dashboardPage.clickOnHeartRateUnderMyHealth();
        //Check if all HR zones are displayed
        heartRatePage=new HeartRatePage(driver);
        heartRatePage.checkIfAllHRZonesAreDisplayed();
        Reporter.log("HeartRate_TC021_022_HeartRateBurningZonesTest is pass on " + deviceName, true);
        //Check if Total HR percentage is equal to 100
        heartRatePage.checkIfTotalHRPercentageIsHundred();
        Reporter.log("HeartRate_TC023_HeartRateBurningZonesHundredPercentageTest is pass on " + deviceName, true);
        //Check if Heart Rate page header is displayed as per requirement
        heartRatePage.checkIfHeartRateTitleAndIconIsDisplayed();
        Reporter.log("HeartRate_TC032_HeartRateScreenHeaderAndIconTest is pass on " + deviceName, true);
        //Check if BPM is displayed for Y-axis of the HR graph
        heartRatePage.checkIfBPMIsDisplayedOnTheYAxisOfHRGraph();
    }
}