package tests;

import genericutility.BaseClass;
import genericutility.JSONUtility;
import genericutility.WebDriverUtility;
import io.appium.java_client.InteractsWithApps;
import objectrepository.*;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class SettingsModuleTest extends BaseClass {
    DashboardPage dashboardPage;
    SettingsPage settingsPage;
    LiftYourWristToViewPopUp liftYourWristToViewPopUp;
    AlertPopUpForWatch alertPopUp;
    WatchNotConnectedAlertPopUp watchNotConnectedAlertPopUp;
    WatchFacesPage watchFacesPage;
    SedentaryAlertPopUp sedentaryAlertPopUp;
    AlertPopUpForWatch alertPopUpForWatch;
    NotificationAndControlCentre notificationAndControlCentre;
    BluetoothIsOffPopUp bluetoothIsOffPopUp;
    AutoHRPopUp autoHRPopUp;
    UnpairWatchPopUp unpairWatchPopUp;
    EditProfilePage editProfilePage;
    SelectAnActionPopUp selectAnActionPopUp;
    AboutPage aboutPage;
    ReportErrorPopUp reportErrorPopUp;
    AlertPopUpForInternet alertPopUpForInternet;
    UnitSystemPopUp unitSystemPopUp;
    FindYourWatchPopUp findYourWatchPopUp;
    SelectContactsPage selectContactsPage;
    FavouriteContactsPage favouriteContactsPage;
    ScreenTimeoutPopUp screenTimeoutPopUp;
    BluetoothCallingPopUp bluetoothCallingPopUp;

//    @Parameters({"deviceName","product", "os"})
//    @Test
//    public void tc001_002_SettingsDisplayTest(String deviceName, String productName, String OS) {
//        if (features.contains("settings")) {
//            //Click on settings tab
//            dashboardPage=new DashboardPage(driver);
//            dashboardPage.clickOnSettingsTab();
//            Reporter.log("Settings_TC001_SettingsClickTest is pass on "+deviceName, true);
//            //Check if all the options in the settings page are displayed
//            settingsPage=new SettingsPage(driver);
//            settingsPage.checkForElements(driver, OS);
//            Reporter.log("Settings_TC002_SettingsDisplayTest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product", "os"})
//    @Test
//    public void tc008_LiftToViewNoInternetTest(String deviceName, String productName, String OS){
//        if (features.contains("liftToView")){
//            //turn off Wi-Fi
//            notificationAndControlCentre=new NotificationAndControlCentre(driver);
//            notificationAndControlCentre.toggleWiFi(driver, OS);
//            //Click on settings tab
//            dashboardPage.clickOnSettingsTab();
//            //Click on My watch and click on lift to view
//            settingsPage=new SettingsPage(driver);
//            settingsPage.clickOnMyWatchOptionAndClickOnLiftToViewOption(driver, OS);
//            //Turn off lift to view
//            liftYourWristToViewPopUp=new LiftYourWristToViewPopUp(driver);
//            liftYourWristToViewPopUp.turnOffLiftYourWristToView(driver);
//            Reporter.log("Settings_TC008_LiftToViewNoInternetTest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product", "os"})
//    @Test
//    public void tc009_LiftToViewWatchNotConnectedTest(String deviceName, String productName, String OS) {
//        if (features.contains("liftToView")) {
//            //unpair the watch
//            dashboardPage=new DashboardPage(driver);
//            dashboardPage.unpairWatch(driver);
//            //Click on settings tab
//            dashboardPage.clickOnSettingsTab();
//            //Click on My watch and click on lift to view
//            settingsPage=new SettingsPage(driver);
//            settingsPage.clickOnMyWatchOptionAndClickOnLiftToViewOption(driver, OS);
//            //Verify whether proper error message is displayed when watch is not connected
//            alertPopUp=new AlertPopUpForWatch(driver);
//            alertPopUp.checkAlertMessage(driver,OS);
//            Reporter.log("Settings_TC009_LiftToViewWatchNotConnectedTest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product"})
//    @Test
//    public void tc014_WatchFacesWatchNotConnectedTurnOffTheWatchTest(String deviceName, String productName) {
//            if (features.contains("watchFaces")) {
//                //unpair the watch
//                dashboardPage=new DashboardPage(driver);
//                dashboardPage.unpairWatch(driver);
//                //Click on watch faces option
//                dashboardPage.clickOnWatchFacesTab();
//                //Verify whether proper error message is displayed when watch is not connected
//                watchFacesPage = new WatchFacesPage(driver);
//                watchFacesPage.clickOnFirstWatchFace();
//                watchFacesPage.checkIfProperToastMessageIsDisplayedWhenWatchIsNotConnected(driver, productName);
//                Reporter.log("Settings_TC014_WatchFacesWatchNotConnectedTurnOffTheWatchTest is pass on "+deviceName, true);
//            }
//        else {
//                throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product", "os"})
//    @Test
//    public void tc019_020_021_027_WatchFacesHorizontalScrollVerticalScrollCategoriesDisplayAndBackToSettingsTest(String deviceName, String productName, String OS) {
//            if (features.contains("watchFaces")) {
//                //Click on watch faces option
//                dashboardPage=new DashboardPage(driver);
//                dashboardPage.clickOnWatchFacesTab();
//                //scroll horizontally through watch faces
//                watchFacesPage=new WatchFacesPage(driver);
//                watchFacesPage.scrollHorizontallyThroughWatchFaces(driver, OS,0);
//                //Check if all the categories are displayed
//                watchFacesPage.checkIfAllCategoriesAreDisplayed(driver, productName, OS);
//                //scroll horizontally through watch faces
//                watchFacesPage.scrollHorizontallyThroughWatchFaces(driver, OS,1);
//                Reporter.log("Settings_TC019_WatchFacesVerticalScrollingTest is pass on "+deviceName, true);
//                Reporter.log("Settings_TC020_WatchFacesHorizontalScrollingTest is pass on "+deviceName, true);
//                Reporter.log("Settings_TC021_WatchFacesCategoriesDisplayTest is pass on "+deviceName, true);
//                //click on Dashboard button
//                watchFacesPage.clickOnDashboardTab();
//                //Verify whether user lands in Dashboard page
//                dashboardPage.checkIfUserLandsInDashboard();
//                Reporter.log("Settings_TC027_WatchFacesBackArrowTest is pass on "+deviceName, true);
//        }
//        else {
//                throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"product", "deviceName", "os"})
//    @Test
//    public void tc029_SedentaryAlertONTest(String deviceName, String productName, String OS){
//        if (features.contains("sedentaryAlert")) {
//            //Click on settings tab
//            dashboardPage=new DashboardPage(driver);
//            dashboardPage.clickOnSettingsTab();
//            //click on Health option and click on Sedentary Alert option
//            settingsPage=new SettingsPage(driver);
//            settingsPage.clickOnHeathOption();
//            settingsPage.clickOnSedentaryAlertOption();
//            //Turn off Sedentary Alert
//            sedentaryAlertPopUp=new SedentaryAlertPopUp(driver);
//            sedentaryAlertPopUp.turnOnSedentaryAlert(driver, OS);
//            //Check if Sedentary Alert is turned off
//            settingsPage.clickOnSedentaryAlertOption();
//            sedentaryAlertPopUp.checkIfSedentaryAlertIsTurnedOn();
//            Reporter.log("Settings_TC029_SedentaryAlertONTest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product", "os"})
//    @Test
//    public void tc032_SedentaryAlertSetIntervalTest(String deviceName, String productName, String OS){
//        if (features.contains("sedentaryAlert")) {
//            //Click on settings tab
//            dashboardPage=new DashboardPage(driver);
//            dashboardPage.clickOnSettingsTab();
//            //click on Health option and click on Sedentary Alert option
//            settingsPage=new SettingsPage(driver);
//            settingsPage.clickOnHealthAndClickOnSedentaryAlertOption(driver, OS);
//            //Change the sedentary interval to 30 mins
//            sedentaryAlertPopUp=new SedentaryAlertPopUp(driver);
//            String sedentaryInterval = sedentaryAlertPopUp.moveTheSedentaryAlertIntervalSliderToSpecifiedDuration(OS,"30");
//            //Check if Sedentary Alert interval is set to 30 mins
//            sedentaryAlertPopUp.checkIfProperIntervalDurationIsShownWhenSliderIsMovedToSpecificDuration(OS, sedentaryInterval);
//            //Change the sedentary interval to 60 mins
//            sedentaryAlertPopUp=new SedentaryAlertPopUp(driver);
//            sedentaryInterval = sedentaryAlertPopUp.moveTheSedentaryAlertIntervalSliderToSpecifiedDuration(OS,"60");
//            //Check if Sedentary Alert interval is set to 60 mins
//            sedentaryAlertPopUp.checkIfProperIntervalDurationIsShownWhenSliderIsMovedToSpecificDuration(OS, sedentaryInterval);
//            //Change the sedentary interval to 120 mins
//            sedentaryAlertPopUp=new SedentaryAlertPopUp(driver);
//            sedentaryInterval = sedentaryAlertPopUp.moveTheSedentaryAlertIntervalSliderToSpecifiedDuration(OS,"120");
//            //Check if Sedentary Alert interval is set to 120 mins
//            sedentaryAlertPopUp.checkIfProperIntervalDurationIsShownWhenSliderIsMovedToSpecificDuration(OS, sedentaryInterval);
//            //Change the sedentary interval to 180 mins
//            sedentaryAlertPopUp=new SedentaryAlertPopUp(driver);
//            sedentaryInterval = sedentaryAlertPopUp.moveTheSedentaryAlertIntervalSliderToSpecifiedDuration(OS,"180");
//            //Check if Sedentary Alert interval is set to 180 mins
//            sedentaryAlertPopUp.checkIfProperIntervalDurationIsShownWhenSliderIsMovedToSpecificDuration(OS, sedentaryInterval);
//            Reporter.log("Settings_TC032_SedentaryAlertSetIntervalTest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product", "os"})
//    @Test
//    public void tc034_SedentaryAlertOFFTest(String deviceName, String productName, String OS){
//            if (features.contains("sedentaryAlert")) {
//                //Click on settings tab
//                dashboardPage=new DashboardPage(driver);
//                dashboardPage.clickOnSettingsTab();
//                //click on Health option and click on Sedentary Alert option
//                settingsPage=new SettingsPage(driver);
//                settingsPage.clickOnHeathOption();
//                settingsPage.clickOnSedentaryAlertOption();
//                //Turn off Sedentary Alert
//                sedentaryAlertPopUp=new SedentaryAlertPopUp(driver);
//                sedentaryAlertPopUp.turnOffSedentaryAlert(driver, OS);
//                //Check if Sedentary Alert is turned off
//                settingsPage.clickOnSedentaryAlertOption();
//                sedentaryAlertPopUp.checkIfSedentaryAlertIsTurnedOff(OS);
//                Reporter.log("Settings_TC034_SedentaryAlertOFFTest is pass on "+deviceName, true);
//            }
//        else {
//                throw new SkipException("Feature not available in "+productName);
//            }
//    }
//
//    @Parameters({"deviceName","product", "os"})
//    @Test
//    public void tc035_SedentaryAlertNoInternetTest(String deviceName, String productName, String OS){
//            if (features.contains("sedentaryAlert")) {
//                //turn off Wi-Fi
//                notificationAndControlCentre=new NotificationAndControlCentre(driver);
//                notificationAndControlCentre.toggleWiFi(driver, OS);
//                //Click on settings tab
//                dashboardPage=new DashboardPage(driver);
//                dashboardPage.clickOnSettingsTab();
//                //click on Health option and click on Sedentary Alert option
//                settingsPage=new SettingsPage(driver);
//                settingsPage.clickOnHeathOption();
//                settingsPage.clickOnSedentaryAlertOption();
//                //Turn off Sedentary Alert
//                sedentaryAlertPopUp=new SedentaryAlertPopUp(driver);
//                sedentaryAlertPopUp.turnOffSedentaryAlert(driver, OS);
//                //Check if Sedentary Alert is turned off
//                settingsPage.clickOnSedentaryAlertOption();
//                sedentaryAlertPopUp.checkIfSedentaryAlertIsTurnedOff(OS);
//                Reporter.log("Settings_TC035_SedentaryAlertNoInternetTest is pass on "+deviceName, true);
//            }
//            else {
//                throw new SkipException("Feature not available in "+productName);
//            }
//    }
//
//    @Parameters({"deviceName","product","os"})
//    @Test
//    public void tc036_SedentaryAlertWatchNotConnectedTest(String deviceName, String productName,String OS){
//            if (features.contains("sedentaryAlert")) {
//                //unpair the watch
//                dashboardPage=new DashboardPage(driver);
//                dashboardPage.unpairWatch(driver);
//                //Click on settings tab
//                dashboardPage.clickOnSettingsTab();
//                //click on Health option and click on Sedentary Alert option
//                settingsPage=new SettingsPage(driver);
//                settingsPage.clickOnHeathOption();
//                settingsPage.clickOnSedentaryAlertOption();
//                //Verify whether proper error message is displayed when watch is not connected
//                alertPopUpForWatch=new AlertPopUpForWatch(driver);
//                alertPopUpForWatch.checkAlertMessage(driver,OS);
//                Reporter.log("Settings_TC036_SedentaryAlertWatchNotConnectedTest is pass on "+deviceName, true);
//            }
//        else {
//                throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product", "os"})
//    @Test
//    public void tc038_AutoHRTurnOnTest(String deviceName, String productName, String OS){
//        if (features.contains("autoHR")) {
//            //Click on settings tab
//            dashboardPage=new DashboardPage(driver);
//            dashboardPage.clickOnSettingsTab();
//            //click on Health option and click on AutoHR Alert option
//            settingsPage=new SettingsPage(driver);
//            settingsPage.clickOnHeathOption();
//            settingsPage.clickOnAutoHRAlertOption();
//            //Turn on AutoHR Alert
//            autoHRPopUp=new AutoHRPopUp(driver);
//            autoHRPopUp.turnOnAutoHR(driver);
//            //Check if AutoHR alert is turned on
//            settingsPage.clickOnAutoHRAlertOption();
//            autoHRPopUp.checkIfAutoHRIsTurnedOn(driver, OS);
//            Reporter.log("Settings_TC038_AutoHRTurnOnTest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product", "os"})
//    @Test
//    public void tc039_AutoHRTurnOffTest(String deviceName, String productName, String OS){
//        if (features.contains("autoHR")) {
//            //Click on settings tab
//            dashboardPage=new DashboardPage(driver);
//            dashboardPage.clickOnSettingsTab();
//            //click on Health option and click on AutoHR Alert option
//            settingsPage=new SettingsPage(driver);
//            settingsPage.clickOnHeathOption();
//            settingsPage.clickOnAutoHRAlertOption();
//            //Turn off AutoHR Alert
//            autoHRPopUp=new AutoHRPopUp(driver);
//            autoHRPopUp.turnOffAutoHR(driver);
//            //Check if AutoHR alert is turned off
//            settingsPage.clickOnAutoHRAlertOption();
//            autoHRPopUp.checkIfAutoHRIsTurnedOff(driver, OS);
//            Reporter.log("Settings_TC039_AutoHRTurnOffTest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product","os"})
//    @Test
//    public void tc040_AutoHRWatchNotConnectedTest(String deviceName, String productName, String OS){
//        if (features.contains("autoHR")) {
//            //unpair the watch
//            dashboardPage=new DashboardPage(driver);
//            dashboardPage.unpairWatch(driver);
//            //Click on settings tab
//            dashboardPage.clickOnSettingsTab();
//            //click on Health option and click on AutoHR Alert option
//            settingsPage=new SettingsPage(driver);
//            settingsPage.clickOnHeathOption();
//            settingsPage.clickOnAutoHRAlertOption();
//            //Verify whether proper error message is displayed when watch is not connected
//            alertPopUpForWatch=new AlertPopUpForWatch(driver);
//            alertPopUpForWatch.checkAlertMessage(driver,OS);
//            Reporter.log("Settings_TC040_AutoHRWatchNotConnectedTest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product", "os"})
//    @Test
//    public void tc041_AutoHRNoInternetTest(String deviceName, String productName, String OS){
//        if (features.contains("autoHR")) {
//            //turn off Wi-Fi
//            notificationAndControlCentre=new NotificationAndControlCentre(driver);
//            notificationAndControlCentre.toggleWiFi(driver, OS);
//            //Click on settings tab
//            dashboardPage=new DashboardPage(driver);
//            dashboardPage.clickOnSettingsTab();
//            //click on Health option and click on Sedentary Alert option
//            settingsPage=new SettingsPage(driver);
//            settingsPage.clickOnHeathOption();
//            settingsPage.clickOnAutoHRAlertOption();
//            //Turn off AutoHR Alert
//            autoHRPopUp=new AutoHRPopUp(driver);
//            autoHRPopUp.turnOffAutoHR(driver);
//            //Check if AutoHR alert is turned off
//            settingsPage.clickOnAutoHRAlertOption();
//            autoHRPopUp.checkIfAutoHRIsTurnedOff(driver, OS);
//            Reporter.log("Settings_TC041_AutoHRNoInternetTest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
////    @Test
////    public void tc042_UnpairWatchTest(){
////        if (features.contains("unpair")) {
////            //Click on settings tab
////            dashboardPage=new DashboardPage(driver);
////            dashboardPage.clickOnSettingsTab();
////            //Click on My watch and click on unpair
////            settingsPage=new SettingsPage(driver);
////            settingsPage.clickOnMyWatchOptionAndClickOnUnpairOption(driver);
////            //provide unpair watch confirmation
////            UnpairWatchPopUp unpairWatchPopUp=new UnpairWatchPopUp(driver);
////            unpairWatchPopUp.unpairWatchFromDevice();
////            //Check if watch is successfully unpaired
////            UnpairWatchPage unpairWatchPage=new UnpairWatchPage(driver);
////            unpairWatchPage.watchUnpairedConfirmation();
////            Reporter.log("Settings_TC042_UnpairWatchTest is pass", true);
////        }
////        else {
////            throw new SkipException("Feature not available in the watch");
////        }
////    }
////
////    @Test
////    public void tc043_UnpairWatchNoInternetConnectivityTest(){
////        if (features.contains("unpair")) {
////            //turn off Wi-Fi
////            driver.setConnection(new ConnectionStateBuilder().withWiFiDisabled().build());
////            //Click on settings tab
////            dashboardPage=new DashboardPage(driver);
////            dashboardPage.clickOnSettingsTab();
////            //Click on My watch and click on unpair
////            settingsPage=new SettingsPage(driver);
////            settingsPage.clickOnMyWatchOptionAndClickOnUnpairOption(driver);
////            //provide unpair watch confirmation
////            UnpairWatchPopUp unpairWatchPopUp=new UnpairWatchPopUp(driver);
////            unpairWatchPopUp.unpairWatchFromDevice();
////            //Check if watch is successfully unpaired
////            UnpairWatchPage unpairWatchPage=new UnpairWatchPage(driver);
////            unpairWatchPage.watchUnpairedConfirmation();
////            //Check if watch is unpaired
////            settingsPage.clickOnBackBtn();
////            dashboardPage.checkIfWatchIsUnpaired(driver);
////            Reporter.log("Settings_TC043_UnpairWatchNoInternetConnectivityTest is pass", true);
////        }
////        else {
////            throw new SkipException("Feature not available in the watch");
////        }
////    }
//
//    @Parameters({"deviceName","product", "os"})
//    @Test
//    public void tc044_UnpairingClickXTest(String deviceName, String productName, String OS){
//        if (features.contains("unpair")) {
//            //Click on settings tab
//            dashboardPage=new DashboardPage(driver);
//            dashboardPage.clickOnSettingsTab();
//            //Click on My watch and click on unpair
//            settingsPage=new SettingsPage(driver);
//            settingsPage.clickOnMyWatchOptionAndClickOnUnpairOption(driver, OS);
//            //Click on close unpair popup
//            unpairWatchPopUp=new UnpairWatchPopUp(driver);
//            unpairWatchPopUp.closeUnpairPopUp();
//            //User should land in Settings page
//            settingsPage.checkIfSettingsPageIsDisplayed();
//            Reporter.log("Settings_TC044_UnpairingClickXTest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product","os"})
//    @Test
//    public void tc045_UnpairWatchKillAppAndReopenTest(String deviceName, String productName, String OS){
//        if (features.contains("unpair")) {
//            //Click on settings tab
//            dashboardPage = new DashboardPage(driver);
//            dashboardPage.clickOnSettingsTab();
//            //Click on My watch and click on unpair
//            settingsPage = new SettingsPage(driver);
//            settingsPage.clickOnMyWatchOptionAndClickOnUnpairOption(driver, OS);
//            //Close the app
//            try {
//                ((InteractsWithApps) driver).terminateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
//            } catch (Exception e){
//                e.printStackTrace();
//            }
//            //Relaunch the app
//            ((InteractsWithApps)driver).activateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
//            //Check is user lands in Dashboard
//            dashboardPage.checkIfUserLandsInDashboard();
//            Reporter.log("Settings_TC045_UnpairWatchKillAppAndReopenTest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
////    @Test
////    public void tc047_UnpairWatchCheckForSummariesTest(){
////        if (features.contains("unpair")) {
////            //Click on settings tab
////            dashboardPage=new DashboardPage(driver);
////            dashboardPage.clickOnSettingsTab();
////            //Click on My watch and click on unpair
////            settingsPage=new SettingsPage(driver);
////            settingsPage.clickOnMyWatchOptionAndClickOnUnpairOption(driver);
////            //provide unpair watch confirmation
////            UnpairWatchPopUp unpairWatchPopUp=new UnpairWatchPopUp(driver);
////            unpairWatchPopUp.unpairWatchFromDevice();
////            //Check if watch is successfully unpaired
////            UnpairWatchPage unpairWatchPage=new UnpairWatchPage(driver);
////            unpairWatchPage.watchUnpairedConfirmation();
////            //Navigate to the dashboard from the settings page
////            settingsPage.clickOnBackBtn();
////            //Check if all pages like My Fitness, Sleep, Heart Rate, Multi Sport display related data
////            dashboardPage.clickOnHealthTab();
////            HeartRatePage heartRatePage=new HeartRatePage(driver);
////            heartRatePage.clickOnHeartRateBloodOxygenAndBloodPressureAndCLickOnBackBtn();
////            dashboardPage.clickOnMultiSportTab();
////            dashboardPage.clickOnMyFitnessTab();
////            dashboardPage.clickOnSleepTab();
////            Reporter.log("Settings_TC047_UnpairWatchCheckForSummariesTest is pass", true);
////            //Require unique locators
////        }
////        else {
////            throw new SkipException("Feature not available in the watch");
////        }
////    }
////    @Test
////    public void tc093_ProfileUpdateImageGalleryTest(){
////        if (features.contains("editProfile")) {
////            //Click on settings tab
////            dashboardPage=new DashboardPage(driver);
////            dashboardPage.clickOnSettingsTab();
////            //Click on edit profile button
////            settingsPage=new SettingsPage(driver);
////            settingsPage.clickOnEditProfile();
////            //Click on user Image
////            editProfilePage=new EditProfilePage(driver);
////            editProfilePage.clickOnUserProfileImage();
////            //Click on Pick Image
////            selectAnActionPopUp=new SelectAnActionPopUp(driver);
////            selectAnActionPopUp.clickOnPickImageOption();
////            //select image from gallery
////            gallerySelectItemPage=new GallerySelectItemPage(driver);
////            gallerySelectItemPage.selectImageAndClickOnNext();
////            //Save the changes
////            editProfilePage.clickOnSaveChangesBtn();
////            Reporter.log("Settings_TC093_ProfileUpdateImageGalleryTest is pass", true);
////        }
////        else {
////            throw new SkipException("Feature not available in the watch");
////        }
////    }
////
////    @Test
////    public void tc094_ProfileUpdateImageCameraAccessGivenTest(){
////        if (features.contains("editProfile")) {
////            //Click on settings tab
////            DashboardPage dashboardPage = new DashboardPage(driver);
////            dashboardPage.clickOnSettingsTab();
////            //Click on edit profile button
////            SettingsPage settingsPage = new SettingsPage(driver);
////            settingsPage.clickOnEditProfile();
////            //Click on user Image
////            EditProfilePage editProfilePage = new EditProfilePage(driver);
////            editProfilePage.clickOnUserProfileImage();
////            //Click on Launch Camera option
////            SelectAnActionPopUp selectAnActionPopUp=new SelectAnActionPopUp(driver);
////            selectAnActionPopUp.clickOnLaunchCameraOption();
////            //Take a picture
////            SystemCameraPage systemCameraPage=new SystemCameraPage(driver);
////            systemCameraPage.captureImageAndSetAsProfilePic();
////            //Save the changes
////            editProfilePage.clickOnSaveChangesBtn();
////            Reporter.log("Settings_TC094_ProfileUpdateImageCameraAccessGivenTest is pass", true);
////        }
////        else {
////            throw new SkipException("Feature not available in the watch");
////        }
////    }
//
//    @Parameters({"deviceName","product"})
//    @Test
//    public void tc098_ProfileRemoveImageTest(String deviceName, String productName){
//        if (features.contains("editProfile")) {
//            //Click on settings tab
//            dashboardPage = new DashboardPage(driver);
//            dashboardPage.clickOnSettingsTab();
//            //Click on edit profile button
//            settingsPage = new SettingsPage(driver);
//            settingsPage.clickOnEditProfile();
//            //Click on user Image
//            editProfilePage = new EditProfilePage(driver);
//            editProfilePage.clickOnUserProfileImage();
//            //Click on Launch Camera option
//            selectAnActionPopUp = new SelectAnActionPopUp(driver);
//            selectAnActionPopUp.clickOnRemoveImageOption();
//            //Save the changes
//            editProfilePage.clickOnSaveChangesBtn();
//            //Check the confirmation Toast Message
//            editProfilePage.checkForToastMessage();
//            Reporter.log("Settings_TC098_ProfileRemoveImageTest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product","os"})
//    @Test
//    public void tc100_103_106_ChangeStepGoalSleepGoalMultiSportGoalWatchNotConnectedTest(String deviceName, String productName, String OS){
//        if (features.contains("Goals")) {
//            //unpair the watch
//            dashboardPage = new DashboardPage(driver);
//            dashboardPage.unpairWatch(driver);
//            //Click on settings tab
//            dashboardPage.clickOnSettingsTab();
//            //Click on Goals option
//            settingsPage=new SettingsPage(driver);
//            settingsPage.clickOnGoalOption();
//            //click on Step Goal option
//            settingsPage.clickOnStepGoalOption();
//            //Check if proper error message is displayed when
//            alertPopUp=new AlertPopUpForWatch(driver);
//            alertPopUp.checkAlertMessage(driver,OS);
//            Reporter.log("Settings_TC100_ChangeStepGoalWatchNotConnectedTest is pass on "+deviceName, true);
//            alertPopUp.clickOnOkButton();
//            //click on Sleep Goal option
//            settingsPage.clickOnSleepGoalOption();
//            //Check if proper error message is displayed when
//            alertPopUp.checkAlertMessage(driver,OS);
//            Reporter.log("Settings_TC103_ChangeSleepGoalWatchNotConnectedTest is pass on "+deviceName, true);
//            alertPopUp.clickOnOkButton();
//            //click on Multi Sport Goal option
//            settingsPage.clickOnMultiSportGoalOption();
//            //Check if proper error message is displayed when
//            alertPopUp.checkAlertMessage(driver,OS);
//            Reporter.log("Settings_TC106_ChangeMultiSportGoalWatchNotConnectedTest is pass on "+deviceName, true);
//            alertPopUp.clickOnOkButton();
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product", "os"})
//    @Test
//    public void tc110_UnitSystemNoInternetTest(String deviceName, String productName, String OS){
//        if (features.contains("unitSystem")) {
//            //turn off Wi-Fi
//            notificationAndControlCentre=new NotificationAndControlCentre(driver);
//            notificationAndControlCentre.toggleWiFi(driver, OS);
//            //Click on settings tab
//            dashboardPage=new DashboardPage(driver);
//            dashboardPage.clickOnSettingsTab();
//            //click on My Watch option and then click on Unit System
//            settingsPage=new SettingsPage(driver);
//            settingsPage.clickOnMyWatchOptionAndThenUnitSystemOption();
//            //Check if user can change the unit system even if there is no internet
//            unitSystemPopUp=new UnitSystemPopUp(driver);
//            unitSystemPopUp.checkIfUserIsAbleToChangeUnitSystem();
//            Reporter.log("Settings_TC110_UnitSystemNoInternetTest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product","os"})
//    @Test
//    public void tc111_UnitSystemWatchNotConnectedTest(String deviceName, String productName, String OS){
//        if (features.contains("unitSystem")) {
//            //unpair the watch
//            dashboardPage = new DashboardPage(driver);
//            dashboardPage.unpairWatch(driver);
//            //Click on settings tab
//            dashboardPage.clickOnSettingsTab();
//            //click on My Watch option and then click on Unit System
//            settingsPage=new SettingsPage(driver);
//            settingsPage.clickOnMyWatchOptionAndThenUnitSystemOption();
//            //Verify whether proper error message is displayed when watch is not connected
//            alertPopUpForWatch=new AlertPopUpForWatch(driver);
//            alertPopUpForWatch.checkAlertMessage(driver,OS);
//            Reporter.log("Settings_TC111_UnitSystemWatchNotConnectedTest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product"})
//    @Test
//    public void tc123_FindWatchUITest(String deviceName, String productName){
//        if (features.contains("findYourWatch")) {
//            //Click on settings tab
//            dashboardPage = new DashboardPage(driver);
//            dashboardPage.clickOnSettingsTab();
//            //click on My Watch option and then click on Find Your Watch
//            settingsPage = new SettingsPage(driver);
//            settingsPage.clickOnMyWatchAndClickOnFindYourWatch();
//            //Check if Find your watch pop up is displayed
//            findYourWatchPopUp=new FindYourWatchPopUp(driver);
//            findYourWatchPopUp.checkIfFindYourWatchPopUpIsDisplayed();
//            Reporter.log("Settings_TC123_FindWatchUITest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product","os"})
//    @Test
//    public void tc124_125_FindWatchWhenWatchNotConnectedTest(String deviceName, String productName, String OS){
//        if (features.contains("findYourWatch")) {
//            //unpair the watch
//            dashboardPage = new DashboardPage(driver);
//            dashboardPage.unpairWatch(driver);
//            //Click on settings tab
//            dashboardPage = new DashboardPage(driver);
//            dashboardPage.clickOnSettingsTab();
//            //click on My Watch option and then click on Find Your Watch
//            settingsPage = new SettingsPage(driver);
//            settingsPage.clickOnMyWatchAndClickOnFindYourWatch();
//            //Verify whether proper error message is displayed when watch is not connected
//            alertPopUpForWatch=new AlertPopUpForWatch(driver);
//            alertPopUpForWatch.checkAlertMessage(driver,OS);
//            Reporter.log("Settings_TC124_125_FindWatchWhenWatchNotConnectedTest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
////    @Test
////    public void tc128_AlarmUIWhenAlarmsAreSetTest(){
////        if (features.contains("Alarm")) {
////            //Click on settings tab
////            dashboardPage = new DashboardPage(driver);
////            dashboardPage.clickOnSettingsTab();
////            //Click on My watch and click on Alarms
////            settingsPage = new SettingsPage(driver);
////            settingsPage.clickOnMyWatchOptionAndClickOnAlarmOption(driver);
////            Reporter.log("Settings_TC128_AlarmUIWhenAlarmsAreSetTest is pass", true);
////        }
////        else {
////            throw new SkipException("Feature not available in the watch");
////        }
////    }
////
////    @Test
////    public void tc129_AlarmUIWhenNoAlarmsSetTest(){
////        if (features.contains("Alarm")) {
////            //Click on settings tab
////            dashboardPage = new DashboardPage(driver);
////            dashboardPage.clickOnSettingsTab();
////            //Click on My watch and click on Alarms
////            settingsPage = new SettingsPage(driver);
////            settingsPage.clickOnMyWatchOptionAndClickOnAlarmOption(driver);
////            Reporter.log("Settings_TC129_AlarmUIWhenNoAlarmsSetTest is pass", true);
////        }
////        else {
////            throw new SkipException("Feature not available in the watch");
////        }
////    }
//
//    @Parameters({"deviceName","product", "os"})
//    @Test
//    public void tc138_AlarmWhenWatchNotConnectedTest(String deviceName, String productName, String OS){
//        if (features.contains("Alarm")) {
//            //unpair the watch
//            dashboardPage = new DashboardPage(driver);
//            dashboardPage.unpairWatch(driver);
//            //Click on settings tab
//            dashboardPage = new DashboardPage(driver);
//            dashboardPage.clickOnSettingsTab();
//            //Click on My watch and click on Alarms
//            settingsPage = new SettingsPage(driver);
//            settingsPage.clickOnMyWatchOptionAndClickOnAlarmOption(driver, OS);
//            //Verify whether proper error message is displayed when watch is not connected
//            alertPopUpForWatch=new AlertPopUpForWatch(driver);
//            alertPopUpForWatch.checkAlertMessage(driver,OS);
//            Reporter.log("Settings_TC138_AlarmWhenWatchNotConnectedTest is pass on "+deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }
//
//    @Parameters({"deviceName","product", "os"})
//    @Test
//    public void tc139_AlarmWhenBTOffInMobileTest(String deviceName, String productName, String OS){
//        if (features.contains("Alarm")) {
//            //Turn Off Bluetooth
//            notificationAndControlCentre = new NotificationAndControlCentre(driver);
//            notificationAndControlCentre.toggleBluetooth(driver, OS);
//            //Close the bluetooth is off popup
//            bluetoothIsOffPopUp=new BluetoothIsOffPopUp(driver);
//            bluetoothIsOffPopUp.clickOnClosePopUpBtn();
//            //Click on settings tab
//            dashboardPage = new DashboardPage(driver);
//            dashboardPage.clickOnSettingsTab();
//            //Click on My watch and click on Alarms
//            settingsPage = new SettingsPage(driver);
//            settingsPage.clickOnMyWatchOptionAndClickOnAlarmOption(driver, OS);
//            if (OS.equalsIgnoreCase("Android")) {
//                //Check if Bluetooth is Off popup is displayed
//                bluetoothIsOffPopUp = new BluetoothIsOffPopUp(driver);
//                bluetoothIsOffPopUp.checkIfBluetoothIsOffPopUpIsDisplayed();
//            } else if (OS.equalsIgnoreCase("IOS")) {
//                //Verify whether proper error message is displayed when watch is not connected
//                alertPopUpForWatch=new AlertPopUpForWatch(driver);
//                alertPopUpForWatch.checkAlertMessage(driver,OS);
//            }
//            //Turn on bluetooth
//            notificationAndControlCentre.toggleBluetooth(driver, OS);
//            Reporter.log("Settings_TC139_AlarmWhenBTOffInMobileTest is pass on " + deviceName, true);
//        }
//        else {
//            throw new SkipException("Feature not available in "+productName);
//        }
//    }

    @Parameters({"deviceName","product","os"})
    @Test
    public void tc149_150_151_152_153_AboutReflexTest(String deviceName, String productName, String OS){
        if (features.contains("About")) {
            //Click on settings tab
            dashboardPage = new DashboardPage(driver);
            dashboardPage.clickOnSettingsTab();
            //Click on About option
            settingsPage=new SettingsPage(driver);
            settingsPage.clickOnAboutOption();
            //Check if all options are displayed as per requirement
            aboutPage=new AboutPage(driver);
            aboutPage.checkIfAllComponentsArePresent();
            Reporter.log("Settings_TC149_AboutReflexTest is pass on "+deviceName, true);
            //Check if user is able to click on Privacy Policy and Privacy Policy page is displayed
            aboutPage.checkIfPrivacyPolicyPageIsDisplayed(driver);
            Reporter.log("Settings_TC150_AboutReflexPrivacyPolicyTest is pass on "+deviceName, true);
            //Navigate back to About Page
            aboutPage.clickOnBackBtn(driver);
            //Check if user is able to click on User Manual and User Manual page is displayed
            aboutPage.checkIfUserManualPageIsDisplayed(driver);
            Reporter.log("Settings_TC151_AboutReflexUserManualTest is pass on "+deviceName, true);
            //Navigate back to About Page
            aboutPage.clickOnBackBtn(driver);
            //Check if user is able to click on About the Products and Titan Home page is displayed
            aboutPage.checkIfAboutTheProductsIsDisplayed(driver);
            Reporter.log("Settings_TC152_AboutReflexAboutTheProductsTest is pass on "+deviceName, true);
            //Navigate back to About Page
            aboutPage.clickOnBackBtn(driver);
            //Check if user is able to click on About the Company and About the Company page is displayed
            aboutPage.checkIfAboutTheCompanyIsDisplayed(driver);
            //Navigate back to About Page
            aboutPage.clickOnBackBtn(driver);
            Reporter.log("Settings_TC153_AboutReflexAboutTheCompanyTest is pass on "+deviceName, true);
        }
        else {
            throw new SkipException("Feature not available in "+productName);
        }
    }

    @Parameters({"deviceName","product", "os"})
    @Test
    public void tc154_AboutReflexWhenNoInternetTest(String deviceName, String productName, String OS){
        if (features.contains("About")) {
            //turn off Wi-Fi
            notificationAndControlCentre=new NotificationAndControlCentre(driver);
            notificationAndControlCentre.toggleWiFi(driver, OS);
            //Click on settings tab
            dashboardPage = new DashboardPage(driver);
            dashboardPage.clickOnSettingsTab();
            //Click on About option
            settingsPage=new SettingsPage(driver);
            settingsPage.clickOnAboutOption();
            //Check if all options are displayed as per requirement
            aboutPage=new AboutPage(driver);
            aboutPage.checkIfAllComponentsArePresent();
            Reporter.log("Settings_TC154_AboutReflexWhenNoInternetTest is pass on "+deviceName, true);
        }
        else {
            throw new SkipException("Feature not available in "+productName);
        }
    }

    @Parameters({"deviceName","product","os"})
    @Test
    public void tc155_AboutReflexWhenWatchNotConnectedOrOutOfCoverageAreaTest(String deviceName, String productName, String OS){
        if (features.contains("About")) {
            //unpair the watch
            dashboardPage = new DashboardPage(driver);
            dashboardPage.unpairWatch(driver);
            //Click on settings tab
            dashboardPage.clickOnSettingsTab();
            //Click on About option
            settingsPage=new SettingsPage(driver);
            settingsPage.clickOnAboutOption();
            //Check if all options are displayed as per requirement
            aboutPage=new AboutPage(driver);
            aboutPage.checkIfAllComponentsArePresent();
            Reporter.log("Settings_TC155_AboutReflexWhenWatchNotConnectedOrOutOfCoverageAreaTest is pass on "+deviceName, true);
        }
        else {
            throw new SkipException("Feature not available in "+productName);
        }
    }

    @Parameters({"deviceName","product","os"})
    @Test
    public void tc171_ReportIssueTest(String deviceName, String productName, String OS) {
        if (features.contains("reportError")) {
            //Click on settings tab
            dashboardPage = new DashboardPage(driver);
            dashboardPage.clickOnSettingsTab();
            //Click on General option and then click on Report Error option
            settingsPage = new SettingsPage(driver);
            settingsPage.clickOnGeneralOptionAndThenClickOnReportErrorOption(driver, OS);
            //Enter error details and click on send button
            reportErrorPopUp=new ReportErrorPopUp(driver);
            reportErrorPopUp.sendErrorReport(OS, "error");
            //Check if report has been sent
            settingsPage.checkIfErrorReportHasBeenSentSuccessfully(driver);
            Reporter.log("Settings_TC171_ReportIssueTest is pass on "+deviceName, true);
        }
        else {
            throw new SkipException("Feature not available in "+productName);
        }
    }

    @Parameters({"deviceName","product", "os"})
    @Test
    public void tc172_ReportIssueNoInternetTest(String deviceName, String productName, String OS){
        if (features.contains("reportError")) {
            //turn off Wi-Fi
            notificationAndControlCentre=new NotificationAndControlCentre(driver);
            notificationAndControlCentre.toggleWiFi(driver, OS);
            //Click on settings tab
            dashboardPage = new DashboardPage(driver);
            dashboardPage.clickOnSettingsTab();
            //Click on General option and then click on Report Error option
            settingsPage = new SettingsPage(driver);
            settingsPage.clickOnGeneralOptionAndThenClickOnReportErrorOption(driver, OS);
            //Enter error details and click on send button
            reportErrorPopUp=new ReportErrorPopUp(driver);
            reportErrorPopUp.sendErrorReport(OS, "error");
            //Verify the error message
            alertPopUpForInternet=new AlertPopUpForInternet(driver);
            alertPopUpForInternet.checkAlertMessage(driver, OS);
            Reporter.log("Settings_TC172_ReportIssueNoInternetTest is pass on "+deviceName, true);
        }
        else {
            throw new SkipException("Feature not available in "+productName);
        }
    }

    @Parameters({"deviceName","product", "os"})
    @Test
    public void tc173_175_177_179_185_FavouriteContactClickOnFavouriteContactsInBTRangeWithInternetOnWithLocationsOnWhenContactsAddedPreviouslyTest(String deviceName, String productName, String OS){
        if (features.contains("favouriteContacts")) {
            //Click on settings tab
            dashboardPage = new DashboardPage(driver);
            dashboardPage.clickOnSettingsTab();
            //Click on My watch option and then Click on Favourite Contacts
            settingsPage=new SettingsPage(driver);
            settingsPage.clickOnMyWatchOptionAndThenClickOnFavouriteContactsOption(driver, OS);
            //Check if user lands in Favourite Contacts screen when contacts were previously added to favourites
            favouriteContactsPage=new FavouriteContactsPage(driver);
            favouriteContactsPage.checkIfUserLandsInFavouriteContactsPage();
            Reporter.log("Settings_TC173_FavouriteContactClickOnFavouriteContactsTest is pass on "+deviceName, true);
            Reporter.log("Settings_TC175_FavouriteContactClickOnFavouriteContactsInBTRangeTest is pass on "+deviceName, true);
            Reporter.log("Settings_TC177_FavouriteContactClickOnFavouriteContactsWithInternetOnTest is pass on "+deviceName, true);
            Reporter.log("Settings_TC179_FavouriteContactClickOnFavouriteContactsWithLocationsOnTest is pass on "+deviceName, true);
            Reporter.log("Settings_TC185_FavouriteContactClickOnFavouriteContactsWhenContactsAddedPreviouslyTest is pass on "+deviceName, true);
        }
        else {
            throw new SkipException("Feature not available in "+productName);
        }
    }

    @Parameters({"deviceName","product", "os"})
    @Test
    public void tc174_FavouriteContactWhenBTOffTest(String deviceName, String productName, String OS) {
        if (features.contains("favouriteContacts")) {
            //Turn Off Bluetooth
            notificationAndControlCentre = new NotificationAndControlCentre(driver);
            notificationAndControlCentre.toggleBluetooth(driver, OS);
            //Close the bluetooth is off popup
            if (OS.equalsIgnoreCase("IOS")){
                bluetoothIsOffPopUp=new BluetoothIsOffPopUp(driver);
                bluetoothIsOffPopUp.clickOnClosePopUpBtn();
            }
            //Click on settings tab
            dashboardPage = new DashboardPage(driver);
            dashboardPage.clickOnSettingsTab();
            //Click on My watch option and then Click on Favourite Contacts
            settingsPage=new SettingsPage(driver);
            settingsPage.clickOnMyWatchOptionAndThenClickOnFavouriteContactsOption(driver, OS);
            //Check if Bluetooth is Off popup is displayed
            bluetoothIsOffPopUp=new BluetoothIsOffPopUp(driver);
            bluetoothIsOffPopUp.checkIfBluetoothIsOffPopUpIsDisplayed();
            //Turn on bluetooth
            notificationAndControlCentre.toggleBluetooth(driver, OS);
            Reporter.log("Settings_TC174_FavouriteContactWhenBTOffTest is pass on "+deviceName, true);
        }
        else {
            throw new SkipException("Feature not available in "+productName);
        }
    }

    @Parameters({"deviceName","product", "os"})
    @Test
    public void tc178_181_FavouriteContactTurnOffInternetAndClickOnFavouriteContactsKillAppAndReopenTest(String deviceName, String productName, String OS) {
        if (features.contains("favouriteContacts")) {
            //turn off Wi-Fi
            notificationAndControlCentre=new NotificationAndControlCentre(driver);
            notificationAndControlCentre.toggleWiFi(driver, OS);
            //Click on settings tab
            dashboardPage = new DashboardPage(driver);
            dashboardPage.clickOnSettingsTab();
            //Click on My watch option and then Click on Favourite Contacts
            settingsPage=new SettingsPage(driver);
            settingsPage.clickOnMyWatchOptionAndThenClickOnFavouriteContactsOption(driver, OS);
            //Check if user lands in Favourite Contacts screen when internet is turned off
            favouriteContactsPage=new FavouriteContactsPage(driver);
            favouriteContactsPage.checkIfUserLandsInFavouriteContactsPage();
            Reporter.log("Settings_TC178_FavouriteContactTurnOffInternetAndClickOnFavouriteContactsTest is pass on "+deviceName, true);
            //Kill app and reopen app
            try {
                ((InteractsWithApps) driver).terminateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
            } catch (Exception e){
                e.printStackTrace();
            }
            ((InteractsWithApps)driver).activateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
            //Check if user lands in Dashboard page
            dashboardPage.checkIfUserLandsInDashboard();
            Reporter.log("Settings_TC181_FavouriteContactKillAppAndReopenTest is pass on "+deviceName, true);
        }
        else {
            throw new SkipException("Feature not available in "+productName);
        }
    }

    @Parameters({"deviceName","product", "os"})
    @Test
    public void tc190_FavouriteContactDeleteTheFavouriteContact(String deviceName, String productName, String OS) throws InterruptedException {
        if (features.contains("favouriteContacts")) {
            //Click on settings tab
            dashboardPage = new DashboardPage(driver);
            dashboardPage.clickOnSettingsTab();
            //Click on My watch option and then Click on Favourite Contacts
            settingsPage=new SettingsPage(driver);
            settingsPage.clickOnMyWatchOptionAndThenClickOnFavouriteContactsOption(driver, OS);
            //Check if user lands in Favourite Contacts screen
            favouriteContactsPage=new FavouriteContactsPage(driver);
            favouriteContactsPage.checkIfUserLandsInFavouriteContactsPage();
            //Delete Harivardan's contact from Favourite Contacts
            favouriteContactsPage.deleteHarivardanNumberAndClickOnSave(driver);
            //Check if Contacts have been synced
            settingsPage.checkIfContactsSyncedSuccessfully(driver);
            Reporter.log("Settings_TC190_FavouriteContactDeleteFavouriteContactTest is pass on "+deviceName, true);
        }
        else {
            throw new SkipException("Feature not available in "+productName);
        }
    }

    @Parameters({"deviceName","product", "os"})
    @Test
    public void tc9184_188_189_FavouriteContactWhenNoContactWasPreviouslyAddedTest(String deviceName, String productName, String OS) throws InterruptedException {
        if (features.contains("favouriteContacts")) {
            //Click on settings tab
            dashboardPage = new DashboardPage(driver);
            dashboardPage.clickOnSettingsTab();
            //Click on My watch option and then Click on Favourite Contacts
            settingsPage=new SettingsPage(driver);
            settingsPage.clickOnMyWatchOptionAndThenClickOnFavouriteContactsOption(driver, OS);
            //Check if user lands in Select Contacts screen when no contacts were previously added to favourites
            selectContactsPage=new SelectContactsPage(driver);
            selectContactsPage.checkIfUserLandsInSelectContactPage();
            Reporter.log("Settings_TC184_FavouriteContactWhenNoContactWasPreviouslyAddedTest is pass on "+deviceName, true);
            //Add contacts to favourites
            selectContactsPage.addHarivardanMobileNumberToFavouritesAndClickOnSave();
            //Check if Favourite Contacts page is displayed and Harivardan's number is displayed
            favouriteContactsPage=new FavouriteContactsPage(driver);
//            favouriteContactsPage.checkIfUserLandsInFavouriteContactsPage();
            //Save the favourite contact
            favouriteContactsPage.clickOnSaveBtn();
            //Go back to Favourite contacts page
            settingsPage.clickOnMyWatchOptionAndThenClickOnFavouriteContactsOption(driver, OS);
            //Favourite contacts page should be displayed
            favouriteContactsPage.checkIfUserLandsInFavouriteContactsPage();
            //Click on Add more button
            favouriteContactsPage.clickOnAddMoreBtn();
            //User will land in Select contacts page, Select more contacts and click on save btn
            selectContactsPage.addMoreContactsAndClickOnSave();
            //Check if contacts added in the select contact page are reflecting in Favourite contacts page
            favouriteContactsPage.checkIfContactsHaveBeenAdded();
            Reporter.log("Settings_TC188_FavouriteContactVerifyToAddMoreContactsTest is pass on "+deviceName, true);
            //Save the favourite contact
            favouriteContactsPage.clickOnSaveBtn();
            //Check if Contacts have been synced
            settingsPage.checkIfContactsSyncedSuccessfully(driver);
            Reporter.log("Settings_TC189_FavouriteContactSaveFavouriteContactsTest is pass on "+deviceName, true);
        }
        else {
            throw new SkipException("Feature not available in "+productName);
        }
    }

    @Parameters({"deviceName","product", "os"})
    @Test
    public void tc9186_187_FavouriteContactAddMaxContactsMoreThanMaxContactsTest(String deviceName, String productName, String OS) throws InterruptedException {
        if (features.contains("favouriteContacts")) {
            //Click on settings tab
            dashboardPage=new DashboardPage(driver);
            dashboardPage.clickOnSettingsTab();
            //Click on My watch option and then Click on Favourite Contacts
            settingsPage=new SettingsPage(driver);
            settingsPage.clickOnMyWatchOptionAndThenClickOnFavouriteContactsOption(driver, OS);
            //Favourite contacts page should be displayed
            favouriteContactsPage=new FavouriteContactsPage(driver);
            favouriteContactsPage.checkIfUserLandsInFavouriteContactsPage();
            //Click on add more btn
            favouriteContactsPage.clickOnAddMoreBtn();
            //add max contacts
            selectContactsPage=new SelectContactsPage(driver);
            selectContactsPage.selectMaxContactsAndClickOnSave(driver);
            //Check if max contacts are added
            favouriteContactsPage.checkIfMaxContactsAreAdded();
            //Check if proper message is displayed when max contacts are added
            favouriteContactsPage.checkIfDeleteContactMessageIsDisplayed();
            //Save the favourite contact
            favouriteContactsPage.clickOnSaveBtn();
            //Wait till the contacts are saved
            WebDriverUtility.waitForPageToLoad(driver,120);
            //Check if Contacts have been synced
            settingsPage.checkIfContactsSyncedSuccessfully(driver);
            Reporter.log("Settings_TC186_FavouriteContactAddMaxContactsTest is pass on "+deviceName, true);
            Reporter.log("Settings_TC187_FavouriteContactAddMoreThanMaxContactsTest is pass on "+deviceName, true);
        }
        else {
            throw new SkipException("Feature not available in "+productName);
        }
    }

    @Parameters({"deviceName","product", "os"})
    @Test
    public void tc195_ScreenTimeoutPopUpDisplayTest(String deviceName, String productName, String OS) {
        if (features.contains("screenTimeout")) {
            //Click on settings tab
            dashboardPage = new DashboardPage(driver);
            dashboardPage.clickOnSettingsTab();
            //Click on My watch option and then Click on ScreenTimeout
            settingsPage = new SettingsPage(driver);
            settingsPage.clickOnMyWatchOptionAndThenClickOnScreenTimeoutOption(driver, OS);
            //Check if Screen Timeout Pop Up is displayed
            screenTimeoutPopUp=new ScreenTimeoutPopUp(driver);
            screenTimeoutPopUp.checkIfScreenTimeoutPopUpIsDisplayed();
            Reporter.log("Settings_TC195_ScreenTimeoutPopUpDisplayTest is pass on "+deviceName, true);
        } else {
            throw new SkipException("Feature not available in " + productName);
        }
    }

    @Parameters({"deviceName","product","os"})
    @Test
    public void tc196_ScreenTimeoutWatchNotConnectedTest(String deviceName, String productName, String OS) {
        if (features.contains("screenTimeout")) {
            //unpair the watch
            dashboardPage = new DashboardPage(driver);
            dashboardPage.unpairWatch(driver);
            //Click on settings tab
            dashboardPage = new DashboardPage(driver);
            dashboardPage.clickOnSettingsTab();
            //Click on My watch option and then Click on ScreenTimeout
            settingsPage = new SettingsPage(driver);
            settingsPage.clickOnMyWatchOptionAndThenClickOnScreenTimeoutOption(driver, OS);
            //Verify whether proper error message is displayed when watch is not connected
            alertPopUpForWatch=new AlertPopUpForWatch(driver);
            alertPopUpForWatch.checkAlertMessage(driver,OS);
            Reporter.log("Settings_TC196_ScreenTimeoutWatchNotConnectedTest is pass on "+deviceName, true);
        } else {
            throw new SkipException("Feature not available in " + productName);
        }
    }

    @Parameters({"deviceName","product", "os"})
    @Test
    public void tc197_ScreenTimeoutNoInternetTest(String deviceName, String productName, String OS) {
        if (features.contains("screenTimeout")) {
            //turn off Wi-Fi
            notificationAndControlCentre=new NotificationAndControlCentre(driver);
            notificationAndControlCentre.toggleWiFi(driver, OS);
            //Click on settings tab
            dashboardPage = new DashboardPage(driver);
            dashboardPage.clickOnSettingsTab();
            //Click on My watch option and then Click on ScreenTimeout
            settingsPage = new SettingsPage(driver);
            settingsPage.clickOnMyWatchOptionAndThenClickOnScreenTimeoutOption(driver, OS);
            //Check if Screen Timeout Pop Up is displayed
            screenTimeoutPopUp=new ScreenTimeoutPopUp(driver);
            screenTimeoutPopUp.checkIfScreenTimeoutPopUpIsDisplayed();
            Reporter.log("Settings_TC197_ScreenTimeoutNoInternetTest is pass on "+deviceName, true);
        } else {
            throw new SkipException("Feature not available in " + productName);
        }
    }

    @Parameters({"deviceName","product","os"})
    @Test
    public void tc198_BluetoothCallingPopUpDisplayTest(String deviceName, String productName, String OS) {
        if (features.contains("bluetoothCalling")) {
            //Click on settings tab
            dashboardPage = new DashboardPage(driver);
            dashboardPage.clickOnSettingsTab();
            //Click on My watch option and then Click on Bluetooth Calling
            settingsPage = new SettingsPage(driver);
            settingsPage.clickOnMyWatchOptionAndThenClickOnBluetoothCallingOption(driver, OS);
            //Check if Bluetooth Calling Pop Up is displayed
            bluetoothCallingPopUp=new BluetoothCallingPopUp(driver);
            bluetoothCallingPopUp.checkIfBluetoothCallingPopUpIsDisplayed(OS);
            Reporter.log("Settings_TC198_BluetoothCallingPopUpDisplayTest is pass on "+deviceName, true);
        } else {
            throw new SkipException("Feature not available in " + productName);
        }
    }

    @Parameters({"deviceName","product","os"})
    @Test
    public void tc199_BluetoothCallingWatchNotConnectedTest(String deviceName, String productName, String OS) {
        if (features.contains("bluetoothCalling")) {
            //unpair the watch
            dashboardPage = new DashboardPage(driver);
            dashboardPage.unpairWatch(driver);
            //Click on settings tab
            dashboardPage = new DashboardPage(driver);
            dashboardPage.clickOnSettingsTab();
            //Click on My watch option and then Click on Bluetooth Calling
            settingsPage = new SettingsPage(driver);
            settingsPage.clickOnMyWatchOptionAndThenClickOnBluetoothCallingOption(driver, OS);
            //Verify whether proper error message is displayed when watch is not connected
            alertPopUpForWatch=new AlertPopUpForWatch(driver);
            alertPopUpForWatch.checkAlertMessage(driver,OS);
            Reporter.log("Settings_TC199_BluetoothCallingWatchNotConnectedTest is pass on "+deviceName, true);
        } else {
            throw new SkipException("Feature not available in " + productName);
        }
    }

    @Parameters({"deviceName","product", "os"})
    @Test
    public void tc200_BluetoothCallingNoInternetTest(String deviceName, String productName, String OS) {
        if (features.contains("bluetoothCalling")) {
            //turn off Wi-Fi
            notificationAndControlCentre=new NotificationAndControlCentre(driver);
            notificationAndControlCentre.toggleWiFi(driver, OS);
            //Click on settings tab
            dashboardPage = new DashboardPage(driver);
            dashboardPage.clickOnSettingsTab();
            //Click on My watch option and then Click on Bluetooth Calling
            settingsPage = new SettingsPage(driver);
            settingsPage.clickOnMyWatchOptionAndThenClickOnBluetoothCallingOption(driver, OS);
            //Check if Bluetooth Calling Pop Up is displayed
            bluetoothCallingPopUp=new BluetoothCallingPopUp(driver);
            bluetoothCallingPopUp.checkIfBluetoothCallingPopUpIsDisplayed(OS);
            Reporter.log("Settings_TC200_BluetoothCallingNoInternetTest is pass on "+deviceName, true);
        } else {
            throw new SkipException("Feature not available in " + productName);
        }
    }
}