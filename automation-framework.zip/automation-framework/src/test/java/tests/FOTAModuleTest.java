package tests;

import genericutility.BaseClass;
import objectrepository.*;
import org.testng.Reporter;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class FOTAModuleTest extends BaseClass {
    DashboardPage dashboardPage;
    SettingsPage settingsPage;
    FirmwareUpdatePage firmwareUpdatePage;
    AlertPopUpForInternet alertPopUpForInternet;
    AlertPopUpForWatch alertPopUpForWatch;
    NotificationAndControlCentre notificationAndControlCentre;
    @Parameters({"deviceName", "os"})
    @Test
    public void tc002_UpdateWatchUpToDateTest(String deviceName, String OS){
        //Click on settings tab
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnSettingsTab();
        //Click on My Watch option and swipe down to update watch option
        settingsPage=new SettingsPage(driver);
        settingsPage.clickOnMyWatchOptionAndThenClickOnUpdateWatchOption(driver, OS);
        //Check if user lands in update watch screen
        firmwareUpdatePage=new FirmwareUpdatePage(driver);
        firmwareUpdatePage.checkIfUserLandsInFirmwareUpdatePage(OS);
        //Check if up-to-date message is displayed when watch is already updated
        firmwareUpdatePage.checkIfNoUpdateFoundMessageIsDisplayed(OS);
        Reporter.log("UpdateWatch_TC002_UpdateWatchUpToDateTest is pass on "+deviceName, true);
    }

    @Parameters({"deviceName", "os"})
    @Test
    public void tc005_UpdateWatchNoInternetTest(String deviceName, String OS){
        //turn off Wi-Fi
        notificationAndControlCentre=new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleWiFi(driver, OS);
        //Click on settings tab
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnSettingsTab();
        //Click on My Watch option and swipe down to update watch option
        settingsPage=new SettingsPage(driver);
        settingsPage.clickOnMyWatchOptionAndThenClickOnUpdateWatchOption(driver, OS);
        //Check if alert pop up is displayed when there is no internet connection
        alertPopUpForInternet=new AlertPopUpForInternet(driver);
        alertPopUpForInternet.checkAlertMessage(driver, OS);
        Reporter.log("UpdateWatch_TC005_UpdateWatchNoInternetTest is pass on "+deviceName, true);
    }

    @Parameters({"deviceName", "os"})
    @Test
    public void tc006_UpdateWatchWatchNotConnectedTest(String deviceName, String OS){
        //Unpair the watch
        dashboardPage=new DashboardPage(driver);
        dashboardPage.unpairWatch(driver);
        //Click on settings tab
        dashboardPage.clickOnSettingsTab();
        //Click on My Watch option and swipe down to update watch option
        settingsPage=new SettingsPage(driver);
        settingsPage.clickOnMyWatchOptionAndThenClickOnUpdateWatchOption(driver, OS);
        //Check if alert pop up is displayed when watch is not connected
        alertPopUpForWatch=new AlertPopUpForWatch(driver);
        alertPopUpForWatch.checkAlertMessage(driver, OS);
        Reporter.log("UpdateWatch_TC006_UpdateWatchWatchNotConnectedTest is pass on "+deviceName, true);
    }
}