package tests;

import genericutility.BaseClass;
import objectrepository.*;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class MyCycleModuleTest extends BaseClass {
    DashboardPage dashboardPage;
    MyCyclePage myCyclePage;
    StartNewCyclePopUp startNewCyclePopUp;
    EditPeriodCalendarPage editPeriodCalendarPage;
    CalendarPage calendarPage;
    AddSymptomsLogPopUp addSymptomsLogPopUp;
    @Parameters({"deviceName","os"})
    @Test
    public void tc017_066_067_MyCycleDisplayAllFieldsOnMyCyclePageTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on My Cycle Icon
        dashboardPage.clickOnMyCycleUnderMyHealth();
        //Check if all elements are displayed
        myCyclePage=new MyCyclePage(driver);
        myCyclePage.checkIfAllElementsArePresent(driver, OS);
        Reporter.log("MyCycle_TC017_66_67_MyCycleDisplayAllFieldsOnMyCyclePageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc018_019_020_021_MyCycleDisplayAndClickStartBtnVerifyPopUpAndStartOfNewCycleTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on My Cycle Icon
        dashboardPage.clickOnMyCycleUnderMyHealth();
        //Check if Start period btn is displayed in the middle of the graph and is clickable
        myCyclePage=new MyCyclePage(driver);
        myCyclePage.checkIfStartBtnIsDisplayedAndIsClickable();
        Reporter.log("MyCycle_TC018_019_MyCycleDisplayAndClickableStartBtnTest is pass on " + deviceName, true);
        //Click on start period button
        myCyclePage.clickOnStartPeriodBtn();
        //Check if start new cycle pop up is displayed
        startNewCyclePopUp=new StartNewCyclePopUp(driver);
        startNewCyclePopUp.checkIfUserLandsInStartNewCyclePopUp();
        Reporter.log("MyCycle_TC020_MyCycleDisplayStartNewCyclePopUpTest is pass on " + deviceName, true);
        //Click on start btn and check if the day of period says day 1 and also check if Last period date is today's date
        startNewCyclePopUp.clickOnStartBtn();
        myCyclePage.checkIfDayOfPeriodIsResetToDayOne(driver, OS);
        myCyclePage.checkIfLastPeriodDateIsCurrentDate();
        Reporter.log("MyCycle_TC021_MyCycleStartNewCycleTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc022_028_029_MyCycleDisplayEditBtnTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on My Cycle Icon
        dashboardPage.clickOnMyCycleUnderMyHealth();
        //Check if Edit period btn is displayed in the middle of the graph and is clickable
        myCyclePage=new MyCyclePage(driver);
        myCyclePage.checkIfStartBtnIsDisplayedAndIsClickable();
        Reporter.log("MyCycle_TC022_MyCycleDisplayEditBtnTest is pass on " + deviceName, true);
        //Click on Edit period btn
        myCyclePage.clickOnEditPeriodBtn();
        //Click on discard btn
        editPeriodCalendarPage=new EditPeriodCalendarPage(driver);
        editPeriodCalendarPage.clickOnDiscardBtn();
        //Check if user lands in My Cycle page
        myCyclePage.checkIfUserLandsInMyCyclePage();
        Reporter.log("MyCycle_TC028_MyCycleClickEditBtnThenClickDiscardBtnTest is pass on " + deviceName, true);
        //Click on Edit period btn
        myCyclePage.clickOnEditPeriodBtn();
        //Click on back btn
        editPeriodCalendarPage.clickOnBackBtn();
        //Check if user lands in My Cycle page
        myCyclePage.checkIfUserLandsInMyCyclePage();
        Reporter.log("MyCycle_TC029_MyCycleClickEditBtnThenClickBackBtnTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc036_MyCycleGraphSwipeRightToLeftTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on My Cycle Icon
        dashboardPage.clickOnMyCycleUnderMyHealth();
        //Swipe right in My Cycle page
        myCyclePage=new MyCyclePage(driver);
        myCyclePage.swipeRightOnMyCyclePage(driver, OS);
        //Check if user can view bar graph
        myCyclePage.checkIfUserCanViewBarGraphs();
        Reporter.log("MyCycle_TC036_MyCycleSwipeRightOnMyCyclePageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc039_040_048_MyCyclePreviousAndNextBtnAbovePieChartTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on My Cycle Icon
        dashboardPage.clickOnMyCycleUnderMyHealth();
        //Click on next button above pie chart
        myCyclePage=new MyCyclePage(driver);
        myCyclePage.clickOnNextBtn();
        //Repeat click for 5 times
        myCyclePage.clickOnNextBtnFiveTimes();
        //Click on previous button above pie chart
        myCyclePage.clickOnPreviousBtn();
        //Repeat click for 10 times
        myCyclePage.clickOnPreviousBtnTenTimes();
        Reporter.log("MyCycle_TC039_MyCyclePreviousAndNextBtnTest is pass on " + deviceName, true);
        //Check if edit btn is displayed
        myCyclePage.checkIfEditBtnIsDisplayedAndIsClickable();
        Reporter.log("MyCycle_TC048_MyCycleVerifyScrollableDatesSelectPreviousDateTest is pass on " + deviceName, true);
        //Click on calendar icon
        myCyclePage.clickOnCalendarIcon();
        //Check if user lands in Calendar Page
        calendarPage=new CalendarPage(driver);
        calendarPage.checkIfUserLandsInCalendarPage();
        Reporter.log("MyCycle_TC040_MyCycleVerifyCalendarViewScreenTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc049_052_053_062_MyCycleClickOnPlusBtnAndSymptomsScreenTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on My Cycle Icon
        dashboardPage.clickOnMyCycleUnderMyHealth();
        //Click on Add logs btn
        myCyclePage=new MyCyclePage(driver);
        myCyclePage.clickOnAddLogsBtn();
        //Check if user lands in Symptoms screen
        addSymptomsLogPopUp=new AddSymptomsLogPopUp(driver);
        addSymptomsLogPopUp.checkIfUserLandsInAddSymptomsLogPopUp();
        Reporter.log("MyCycle_TC049_MyCycleClickOnPlusBtnTest is pass on " + deviceName, true);
        //Check if all sections are displayed in Add symptoms log pop up
        addSymptomsLogPopUp.checkIfAllSectionsAreDisplayed(driver, OS);
        Reporter.log("MyCycle_TC052_062_MyCycleSymptomsScreenWithMedicationSectionTest is pass on " + deviceName, true);
        //Click on close pop up btn
        addSymptomsLogPopUp.clickOnClosePopUpBtn();
        //Check if user lands in My Cycle page
        myCyclePage.checkIfUserLandsInMyCyclePage();
        Reporter.log("MyCycle_TC053_MyCycleSymptomsScreenCloseTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc059_060_061_068_MyCycleAddSymptomsLogSaveTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on My Cycle Icon
        dashboardPage.clickOnMyCycleUnderMyHealth();
        //Click on Add logs btn
        myCyclePage.clickOnAddLogsBtn();
        //Click on save Btn
        addSymptomsLogPopUp.clickOnSaveBtn();
        //Check if user lands in My Cycle page
        myCyclePage.checkIfUserLandsInMyCyclePage();
        Reporter.log("MyCycle_TC059_061_MyCycleSymptomsScreenSaveTest is pass on " + deviceName, true);
        //Click on Add logs btn
        myCyclePage.clickOnAddLogsBtn();
        //Select any one symptom
        addSymptomsLogPopUp.selectBloatingAsSymptom();
        //Check if the selected symptom/s are displayed under my logs
        myCyclePage.checkIfBloatingIsAddedAsSymptomUnderMySymptomsLogs();
        Reporter.log("MyCycle_TC060_068_MyCycleSymptomsScreenSaveAfterSymptomSelectionTest is pass on " + deviceName, true);
        //Click on '+' symbol beside symptom name

    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc063_MyCycleAddSymptomsLogEnterSpecialCharacterInMedicationTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on My Cycle Icon
        dashboardPage.clickOnMyCycleUnderMyHealth();
        //Click on Add logs btn
        myCyclePage=new MyCyclePage(driver);
        myCyclePage.clickOnAddLogsBtn();
        //Swipe down to medications section
        addSymptomsLogPopUp=new AddSymptomsLogPopUp(driver);
        addSymptomsLogPopUp.swipeDownToMedicationsSection(driver, OS);
        //Enter special characters in the medication text field and click on save btn
        addSymptomsLogPopUp.enterCharactersInMedicationsTextFieldAndClickOnSaveBtn("!@#$%^&*()");
        //Swipe down to my logs section
        myCyclePage.swipeDownToMySymptomsLogs(driver, OS);
        //Check if medications icon is displayed
        myCyclePage.checkIfMedicationsIsAddedAsSymptomUnderMySymptomsLogs();
        Reporter.log("MyCycle_TC063_MyCycleAddSymptomsLogEnterSpecialCharacterInMedicationTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc064_065_MyCycleAddSymptomsLogEnterMoreThanMaxCharacterInMedicationTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on My Cycle Icon
        dashboardPage.clickOnMyCycleUnderMyHealth();
        //Click on Add logs btn
        myCyclePage=new MyCyclePage(driver);
        myCyclePage.clickOnAddLogsBtn();
        //Swipe down to medications section
        addSymptomsLogPopUp=new AddSymptomsLogPopUp(driver);
        addSymptomsLogPopUp.swipeDownToMedicationsSection(driver, OS);
        //Enter more than max(120) characters i.e, enter 130 characters, in the medication text field
        addSymptomsLogPopUp.enterCharactersInMedicationsTextField("asdfghjklmnbvcxzqwertyuiopasdfghjklmnbvcxzqwertyuiopasdfghjklmnbvcxzqwertyuiopasdfghjklmnbvcxzqwertyuiopasdfghjklmnbvcxzqwertyuiop");
        //Check if only 120 characters are displayed
        Assert.assertTrue(addSymptomsLogPopUp.fetchTheCountOfCharactersEnteredInTheMedicationTextField()==120);
        Reporter.log("MyCycle_TC064_065_MyCycleAddSymptomsLogEnterMoreThanMaxCharacterInMedicationTest is pass on " + deviceName, true);
    }
}