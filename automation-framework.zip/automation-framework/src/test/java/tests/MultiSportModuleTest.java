package tests;

import genericutility.BaseClass;
import genericutility.JSONUtility;
import io.appium.java_client.InteractsWithApps;
import io.appium.java_client.android.AndroidDriver;
import objectrepository.*;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.time.Duration;

@Listeners(genericutility.iTestListenerImplementation.class)
public class MultiSportModuleTest extends BaseClass {
    DashboardPage dashboardPage;
    MultiSportTimelinePage multiSportTimelinePage;
    MultiSportActivitySummaryPage multiSportActivitySummaryPage;
    NotificationAndControlCentre notificationAndControlCentre;
    BluetoothIsOffPopUp bluetoothIsOffPopUp;
    SettingsPage settingsPage;
    UnitSystemPopUp unitSystemPopUp;

    @Parameters({"deviceName", "os"})
    @Test
    public void tc001_002_MultiSportTimelineAndBackArrowTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Check if Calories, Step, Distance and Time totals are displayed
        multiSportTimelinePage =new MultiSportTimelinePage(driver);
        multiSportTimelinePage.checkIfCalStepsDistAndActiveTimeAreDisplayed(driver);
        Reporter.log("MultiSport_TC001_MultiSportTimelineTest is pass on " + deviceName, true);
        //Click on back btn in Multi Sport screen
        multiSportTimelinePage.clickOnBackBtn();
        //Check if user lands in Dashboard screen
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("MultiSport_TC002_MultiSportTimelineAndBackArrowTest is pass on " + deviceName, true);
    }

    @Parameters("deviceName")
    @Test
    public void tc003_MultiSportTimelineWhenUnitSystemChangedTest(String deviceName){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Check if the Distance is shown in km/mi in the MultiSport Timeline page
        multiSportTimelinePage = new MultiSportTimelinePage(driver);
        String unitBefore=multiSportTimelinePage.fetchTheUnitOfDistance();
        //Change the unit system from the settings
        //Go back to dashboard
        multiSportTimelinePage.clickOnBackBtn();
        //Click on settings tab
        dashboardPage.clickOnSettingsTab();
        //Click on My watch option and then click on unit system option
        settingsPage=new SettingsPage(driver);
        settingsPage.clickOnMyWatchOptionAndThenUnitSystemOption();
        //Change the unit system to Metric/Imperial
        unitSystemPopUp=new UnitSystemPopUp(driver);
        unitSystemPopUp.changeUnitToImperialOrMetric();
        //Check if confirmation toast message is displayed
        settingsPage.checkConfirmationToastMessageForChanges();
        //Navigate to MultiSport timeline page and check if the unit for distance has changed
        //Click on dashboard tab
        settingsPage.clickOnDashboardBtn();
        //Click on Multi Sport Summary Icon
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Check if the Distance is shown in km/mi in the MultiSport Timeline page
        String unitAfter=multiSportTimelinePage.fetchTheUnitOfDistance();
        //Check if unit of distance is changed
        if (unitBefore.equalsIgnoreCase("km")){
            Assert.assertEquals(unitAfter, "mi");
        } else if (unitBefore.equalsIgnoreCase("mi")) {
            Assert.assertEquals(unitAfter, "km");
        }
    }

    @Parameters("deviceName")
    @Test
    public void tc005_MultiSportKillAppAndReopenTest(String deviceName){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Check if Calories, Step, Distance and Time totals are displayed
        multiSportTimelinePage =new MultiSportTimelinePage(driver);
        multiSportTimelinePage.checkIfCalStepsDistAndActiveTimeAreDisplayed(driver);
        //Close the app
        ((InteractsWithApps)driver).terminateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
        //launch the app
        ((AndroidDriver)driver).activateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
        //Check if user lands in Dashboard screen
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("MultiSport_TC005_MultiSportKillAppAndReopenTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc007_MultiSportWeekTabKillAppAndReopenTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Click on This Week tab
        multiSportTimelinePage =new MultiSportTimelinePage(driver);
        multiSportTimelinePage.clickOnThisWeekTab();
        //Check if Calories, Step, Distance and Time totals are displayed
        multiSportTimelinePage.checkIfCalStepsDistAndActiveTimeAreDisplayed(driver);
        //Close the app
        ((InteractsWithApps)driver).terminateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
        //launch the app
        ((AndroidDriver)driver).activateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
        //Check if user lands in Dashboard screen
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("MultiSport_TC007_MultiSportWeekTabKillAppAndReopenTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc009_MultiSportMonthTabKillAppAndReopenTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Click on This Month tab
        multiSportTimelinePage =new MultiSportTimelinePage(driver);
        multiSportTimelinePage.clickOnThisMonthTab();
        //Check if Calories, Step, Distance and Time totals are displayed
        multiSportTimelinePage.checkIfCalStepsDistAndActiveTimeAreDisplayed(driver);
        //Close the app
        ((InteractsWithApps)driver).terminateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
        //launch the app
        ((InteractsWithApps)driver).activateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
        //Check if user lands in Dashboard screen
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("MultiSport_TC009_MultiSportMonthTabKillAppAndReopenTest is pass on "+deviceName,  true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc013_014_MultiSportSelectActivitySummaryViewAndBackArrowTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Check if Calories, Step, Distance and Time totals are displayed
        multiSportTimelinePage =new MultiSportTimelinePage(driver);
        multiSportTimelinePage.checkIfCalStepsDistAndActiveTimeAreDisplayed(driver);
        //Click on First activity
        multiSportTimelinePage.clickOnFirstActivity();
        //Check if BPM graph is displayed
        multiSportActivitySummaryPage=new MultiSportActivitySummaryPage(driver);
        multiSportActivitySummaryPage.checkIfBPMIsDisplayedAsYAxisParameterForActivityGraph(OS);
        Reporter.log("MultiSport_TC013_MultiSportSelectActivitySummaryViewTest is pass on " + deviceName, true);
        //Click on back button
        multiSportActivitySummaryPage.clickOnBackBtn();
        //Check if user lands in MultiSport summary screen
        multiSportTimelinePage.checkIfUserLandsInMultiSportSummaryScreen();
        Reporter.log("MultiSport_TC014_MultiSportSelectActivityAndBackArrowTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc027_MultiSportSelectActivityClickOnWeekMonthAndScrollBetweenActivitiesTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Check if Calories, Step, Distance and Time totals are displayed
        multiSportTimelinePage =new MultiSportTimelinePage(driver);
        multiSportTimelinePage.checkIfCalStepsDistAndActiveTimeAreDisplayed(driver);
        //Click on any activity
        multiSportTimelinePage.clickOnFirstActivity();
        //Click on week tab
        multiSportActivitySummaryPage=new MultiSportActivitySummaryPage(driver);
        multiSportActivitySummaryPage.clickOnThisWeekTab();
        //Scroll between  different activities
        multiSportActivitySummaryPage.scrollBetweenDifferentActivities();
        //click on week tab
        multiSportActivitySummaryPage.clickOnThisMonthTab();
        //Scroll between  different activities
        multiSportActivitySummaryPage.scrollBetweenDifferentActivities();
        Reporter.log("MultiSport_TC027_MultiSportSelectActivityClickOnWeekMonthAndScrollBetweenActivitiesTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc034_035_MultiSportRunningActivityVerifyActivityPageTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Click on First running activity
        multiSportTimelinePage=new MultiSportTimelinePage(driver);
        multiSportTimelinePage.clickOnFirstRunningMultiSport(driver, OS);
        //Check if Steps, Distance, Calories, Avg HR, Avg Pace and Duration are displayed
        multiSportActivitySummaryPage=new MultiSportActivitySummaryPage(driver);
        multiSportActivitySummaryPage.checkIfAllRunningOrWalkingOrHikingParametersAreDisplayed();
        Reporter.log("MultiSport_TC034_035_MultiSportRunningActivityVerifyActivityPageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc036_MultiSportWalkingActivityVerifyActivityPageTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Click on First walking activity
        multiSportTimelinePage=new MultiSportTimelinePage(driver);
        multiSportTimelinePage.clickOnFirstWalkingMultiSport();
        //Check if Steps, Distance, Calories, Avg HR, Avg Pace and Duration are displayed
        multiSportActivitySummaryPage=new MultiSportActivitySummaryPage(driver);
        multiSportActivitySummaryPage.checkIfAllRunningOrWalkingOrHikingParametersAreDisplayed();
        Reporter.log("MultiSport_TC036_MultiSportWalkingActivityVerifyActivityPageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc038_MultiSportSkippingActivityVerifyActivityPageTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Click on First Skipping activity
        multiSportTimelinePage=new MultiSportTimelinePage(driver);
        multiSportTimelinePage.clickOnFirstSkippingMultiSport();
        //Check if Calories, Avg HR and Duration are displayed
        multiSportActivitySummaryPage=new MultiSportActivitySummaryPage(driver);
        multiSportActivitySummaryPage.checkIfAllOtherMultiSportParametersAreDisplayed();
        Reporter.log("MultiSport_TC038_MultiSportSkippingActivityVerifyActivityPageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc041_MultiSportHikingActivityVerifyActivityPageTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Click on First Hiking activity
        multiSportTimelinePage=new MultiSportTimelinePage(driver);
        multiSportTimelinePage.clickOnFirstHikingActivity();
        //Check if Steps, Distance, Calories, Avg HR, Avg Pace and Duration are displayed
        multiSportActivitySummaryPage=new MultiSportActivitySummaryPage(driver);
        multiSportActivitySummaryPage.checkIfAllRunningOrWalkingOrHikingParametersAreDisplayed();
        Reporter.log("MultiSport_TC041_MultiSportHikingActivityVerifyActivityPageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc043_MultiSportBasketballActivityVerifyActivityPageTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Click on First Basketball activity
        multiSportTimelinePage=new MultiSportTimelinePage(driver);
        multiSportTimelinePage.clickOnFirstBasketballActivity(driver, OS);
        //Check if Calories, Avg HR and Duration are displayed
        multiSportActivitySummaryPage=new MultiSportActivitySummaryPage(driver);
        multiSportActivitySummaryPage.checkIfAllOtherMultiSportParametersAreDisplayed();
        Reporter.log("MultiSport_TC043_MultiSportBasketballActivityVerifyActivityPageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc044_MultiSportFootballActivityVerifyActivityPageTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Click on First Football activity
        multiSportTimelinePage=new MultiSportTimelinePage(driver);
        multiSportTimelinePage.clickOnFirstFootballActivity(driver, OS);
        //Check if Steps, Calories, Avg HR and Duration are displayed
        multiSportActivitySummaryPage=new MultiSportActivitySummaryPage(driver);
        multiSportActivitySummaryPage.checkIfAllFootballOrCricketOrRugbyParametersAreDisplayed();
        Reporter.log("MultiSport_TC044_MultiSportFootballActivityVerifyActivityPageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc046_MultiSportCricketActivityVerifyActivityPageTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Click on First Cricket activity
        multiSportTimelinePage=new MultiSportTimelinePage(driver);
        multiSportTimelinePage.clickOnFirstCricketActivity(driver, OS);
        //Check if Steps, Calories, Avg HR and Duration are displayed
        multiSportActivitySummaryPage=new MultiSportActivitySummaryPage(driver);
        multiSportActivitySummaryPage.checkIfAllFootballOrCricketOrRugbyParametersAreDisplayed();
        Reporter.log("MultiSport_TC046_MultiSportCricketActivityVerifyActivityPageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc047_MultiSportYogaActivityVerifyActivityPageTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Click on First Yoga activity
        multiSportTimelinePage=new MultiSportTimelinePage(driver);
        multiSportTimelinePage.clickOnFirstYogaActivity(driver, OS);
        //Check if Calories, Avg HR and Duration are displayed
        multiSportActivitySummaryPage=new MultiSportActivitySummaryPage(driver);
        multiSportActivitySummaryPage.checkIfAllOtherMultiSportParametersAreDisplayed();
        Reporter.log("MultiSport_TC047_MultiSportYogaActivityVerifyActivityPageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc048_MultiSportCyclingActivityVerifyActivityPageTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Click on First Cycling activity
        multiSportTimelinePage=new MultiSportTimelinePage(driver);
        multiSportTimelinePage.clickOnFirstCyclingActivity(driver, OS);
        //Check if Calories, Avg HR and Duration are displayed
        multiSportActivitySummaryPage=new MultiSportActivitySummaryPage(driver);
        multiSportActivitySummaryPage.checkIfAllOtherMultiSportParametersAreDisplayed();
        Reporter.log("MultiSport_TC048_MultiSportCyclingActivityVerifyActivityPageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc049_MultiSportSpinningActivityVerifyActivityPageTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Click on First Spinning activity
        multiSportTimelinePage=new MultiSportTimelinePage(driver);
        multiSportTimelinePage.clickOnFirstSpinningActivity();
        //Check if Calories, Avg HR and Duration are displayed
        multiSportActivitySummaryPage=new MultiSportActivitySummaryPage(driver);
        multiSportActivitySummaryPage.checkIfAllOtherMultiSportParametersAreDisplayed();
        Reporter.log("MultiSport_TC049_MultiSportSpinningActivityVerifyActivityPageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc050_MultiSportDancingActivityVerifyActivityPageTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Click on First Dancing activity
        multiSportTimelinePage=new MultiSportTimelinePage(driver);
        multiSportTimelinePage.clickOnFirstDancingActivity();
        //Check if Calories, Avg HR and Duration are displayed
        multiSportActivitySummaryPage=new MultiSportActivitySummaryPage(driver);
        multiSportActivitySummaryPage.checkIfAllOtherMultiSportParametersAreDisplayed();
        Reporter.log("MultiSport_TC050_MultiSportDancingActivityVerifyActivityPageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc052_MultiSportRugbyActivityVerifyActivityPageTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Click on First Rugby activity
        multiSportTimelinePage=new MultiSportTimelinePage(driver);
        multiSportTimelinePage.clickOnFirstRugbyActivity(driver, OS);
        //Check if Steps, Calories, Avg HR and Duration are displayed
        multiSportActivitySummaryPage=new MultiSportActivitySummaryPage(driver);
        multiSportActivitySummaryPage.checkIfAllFootballOrCricketOrRugbyParametersAreDisplayed();
        Reporter.log("MultiSport_TC052_MultiSportRugbyActivityVerifyActivityPageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc054_MultiSportFreeTrainingActivityVerifyActivityPageTest(String deviceName, String OS){
        //Click on Multi Sport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Click on First Free Training activity
        multiSportTimelinePage=new MultiSportTimelinePage(driver);
        multiSportTimelinePage.clickOnFirstFreeTrainingActivity();
        //Check if Calories, Avg HR and Duration are displayed
        multiSportActivitySummaryPage=new MultiSportActivitySummaryPage(driver);
        multiSportActivitySummaryPage.checkIfAllOtherMultiSportParametersAreDisplayed();
        Reporter.log("MultiSport_TC054_MultiSportFreeTrainingActivityVerifyActivityPageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName"})
    @Test
    public void tc077_MultiSportSummariesWatchNotConnectedTest(String deviceName) {
        //Unpair the watch
        dashboardPage=new DashboardPage(driver);
        dashboardPage.unpairWatch(driver);
        //Click on MultiSport Summary Icon
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Check if user lands in MultiSport Summary screen
        multiSportTimelinePage =new MultiSportTimelinePage(driver);
        multiSportTimelinePage.checkIfUserLandsInMultiSportSummaryScreen();
        Reporter.log("HeartRate_TC077_MultiSportSummariesWatchNotConnectedTest is pass on " + deviceName, true);
        //Pair the watch
        multiSportTimelinePage.clickOnBackBtn();
        dashboardPage.pairWatch();
    }

    @Parameters({"deviceName", "os"})
    @Test
    public void tc078_MultiSportSummariesBTOffTest(String deviceName, String OS) {
        //Turn Off Bluetooth
        notificationAndControlCentre = new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleBluetooth(driver, OS);
        //Close the bluetooth is off popup
        bluetoothIsOffPopUp=new BluetoothIsOffPopUp(driver);
        bluetoothIsOffPopUp.clickOnClosePopUpBtn();
        //Click on MultiSport Summary Icon
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Check if user lands in MultiSport Summary screen
        multiSportTimelinePage =new MultiSportTimelinePage(driver);
        multiSportTimelinePage.checkIfUserLandsInMultiSportSummaryScreen();
        Reporter.log("HeartRate_TC078_MultiSportSummariesBTOffTest is pass on " + deviceName, true);
        //Turn on bluetooth
        notificationAndControlCentre.toggleBluetooth(driver, OS);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc079_MultiSportSummariesKillAppAndReopenTest(String deviceName, String OS) {
        //Click on MultiSport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Check if user lands in MultiSport Summary screen
        multiSportTimelinePage =new MultiSportTimelinePage(driver);
        multiSportTimelinePage.checkIfUserLandsInMultiSportSummaryScreen();
        //Close the app
        ((InteractsWithApps)driver).terminateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
        //launch the app
        ((InteractsWithApps)driver).activateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
        //Check if user lands in Dashboard screen
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("HeartRate_TC079_MultiSportSummariesKillAppAndReopenTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc080_MultiSportAppInBackgroundAndReopenTest(String deviceName, String OS) {
        //Click on MultiSport Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnMultiSportSummaryIcon();
        //Check if user lands in MultiSport Summary screen
        multiSportTimelinePage =new MultiSportTimelinePage(driver);
        multiSportTimelinePage.checkIfUserLandsInMultiSportSummaryScreen();
        //Run the app in background
        ((InteractsWithApps)driver).runAppInBackground(Duration.ofSeconds(2));
        //launch the app
        ((InteractsWithApps)driver).activateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
        //Check if user lands in MultiSport screen
        multiSportTimelinePage.checkIfUserLandsInMultiSportSummaryScreen();
        Reporter.log("HeartRate_TC080_MultiSportAppInBackgroundAndReopenTest is pass on " + deviceName, true);
    }
}