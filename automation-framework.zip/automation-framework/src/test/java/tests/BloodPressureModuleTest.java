package tests;

import genericutility.BaseClass;
import genericutility.JSONUtility;
import genericutility.JavaUtility;
import io.appium.java_client.InteractsWithApps;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import objectrepository.*;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class BloodPressureModuleTest extends BaseClass {
    DashboardPage dashboardPage;
    BloodPressurePage bloodPressurePage;
    JavaUtility javaUtility;
    CalendarPage calendarPage;
    NotificationAndControlCentre notificationAndControlCentre;
    BluetoothIsOffPopUp bluetoothIsOffPopUp;
    @Parameters({"deviceName","os"})
    @Test
    public void tc001_002_003_016_BloodPressureClickOnBPCardVerifyLatestDataTest(String deviceName, String OS){
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Fetch the latest value of Blood Pressure from the health card
        String bpValueInDashboard=dashboardPage.fetchTheLatestValueOfBloodPressureFromHealthCard(OS).substring(0,5);
        //Click on Blood Pressure Summary Icon
        dashboardPage.clickOnBloodPressureUnderMyHealth();
        //Check if user lands in Blood Pressure screen
        bloodPressurePage=new BloodPressurePage(driver);
        bloodPressurePage.checkIfUserLandsInBloodPressureSummaryPage(OS);
        Reporter.log("BloodPressure_TC001_BloodPressureSummaryTest is pass on " + deviceName, true);
        //Check if user lands in day view
        bloodPressurePage.checkIfUserLandsInDayViewOfBloodPressureSummaryPage(OS);
        Reporter.log("BloodPressure_TC002_BloodPressureSummaryDayViewTest is pass on " + deviceName, true);
        //Check if the latest value on dashboard is equal to the latest value in Blood Pressure summary page
        String bpValueInBPPage = bloodPressurePage.fetchTheLatestBPValueFromTheReadingsSection(OS).substring(0,5);
        Assert.assertEquals(bpValueInDashboard, bpValueInBPPage);
        Reporter.log("BloodPressure_TC003_016_BloodPressureLatestDataTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc013_014_015_017_018_019_025_028_038_050_BloodPressureDayWeekAndMonthViewAndPreviousDayWeekAndMonthViewTest(String deviceName, String OS){
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Pressure Summary Icon
        dashboardPage.clickOnBloodPressureUnderMyHealth();
        //Check if user lands in Blood Pressure screen
        bloodPressurePage=new BloodPressurePage(driver);
        bloodPressurePage.checkIfUserLandsInBloodPressureSummaryPage(OS);
        //Click on previous button and check if user lands in yesterday page
        bloodPressurePage.clickOnPreviousBtn();
        bloodPressurePage.checkIfUserLandsInSelectedDaysOfBloodPressureSummaryPage(OS, "Yesterday");
        //Check if Blood pressure data is shown
        bloodPressurePage.checkIfBloodPressureDataIsDisplayed();
        //CLick on previous button again and check if user lands in day before yesterday page
        javaUtility=new JavaUtility();
        bloodPressurePage.clickOnPreviousBtn();
        bloodPressurePage.checkIfUserLandsInSelectedDaysOfBloodPressureSummaryPage(OS,javaUtility.getPreviousDate(2));
        Reporter.log("BloodPressure_TC013_017_018_BloodPressurePreviousDayViewTest is pass on " + deviceName, true);
        //Click on week tab
        bloodPressurePage.clickOnWeekTab();
        //Check if user lands in current week view of BP page
        bloodPressurePage.checkIfUserLandsInSelectedDaysOfBloodPressureSummaryPage(OS, javaUtility.getDatesFromMonToSunForPresentWeek());
        Reporter.log("BloodPressure_TC019_BloodPressureWeekViewTest is pass on " + deviceName, true);
        //Click on previous week
        bloodPressurePage.clickOnPreviousBtn();
        //Check if Blood pressure data is shown
        bloodPressurePage.checkIfBloodPressureDataIsDisplayed();
        Reporter.log("BloodPressure_TC014_BloodPressurePreviousWeekViewTest is pass on " + deviceName, true);
        //Click on month tab
        bloodPressurePage.clickOnMonthTab();
        //Check if user lands in month view
        bloodPressurePage.checkIfUserLandsInSelectedDaysOfBloodPressureSummaryPage(OS, javaUtility.fetchOnlyMonthInMonFormat());
        Reporter.log("BloodPressure_TC025_028_BloodPressureMonthViewTest is pass on " + deviceName, true);
        //Click on previous week
        bloodPressurePage.clickOnPreviousBtn();
        //Check if Blood pressure data is shown
        bloodPressurePage.checkIfBloodPressureDataIsDisplayed();
        Reporter.log("BloodPressure_TC015_038_BloodPressurePreviousMonthViewTest is pass on " + deviceName, true);
        Reporter.log("BloodPressure_TC050_BloodPressureNavigateBetweenDayWeekAndMonthViewTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc023_031_060_BloodPressureDisplayOfBPUnitInYAxisTest(String deviceName, String OS){
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Pressure Summary Icon
        dashboardPage.clickOnBloodPressureUnderMyHealth();
        //Check if user lands in Blood Pressure screen
        bloodPressurePage=new BloodPressurePage(driver);
        bloodPressurePage.checkIfUserLandsInBloodPressureSummaryPage(OS);
        //Click on week tab
        bloodPressurePage.clickOnWeekTab();
        //Check if Mon to Sun is displayed as values in the x-axis of the Blood pressure graph
        bloodPressurePage.checkIfMonToSunIsDisplayedAsValuesInXAxis(OS);
        Reporter.log("BloodPressure_TC023_BloodPressureWeekViewGraphXAxisTest is pass on " + deviceName, true);
        //Click on month tab
        bloodPressurePage.clickOnMonthTab();
        //Check if 1W to 5W is displayed as values in the x-axis of the Blood pressure graph
        bloodPressurePage.checkIfAllWeekValuesAreDisplayedInXAxis(OS);
        Reporter.log("BloodPressure_TC031_BloodPressureMonthViewGraphXAxisTest is pass on " + deviceName, true);
        //Check if mmHg is displayed as value in the Y-Axis of the BP graph
        bloodPressurePage.checkIfProperUnitOfBPIsDisplayedAtYAxisOfGraph(OS);
        Reporter.log("BloodPressure_TC060_BloodPressureDisplayOfBPUnitInYAxisTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc026_BloodPressureWeekViewAverageValueTest(String deviceName, String OS){
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Pressure Summary Icon
        dashboardPage.clickOnBloodPressureUnderMyHealth();
        //Check if user lands in Blood Pressure screen
        bloodPressurePage=new BloodPressurePage(driver);
        bloodPressurePage.checkIfUserLandsInBloodPressureSummaryPage(OS);
        //Click on week tab
        bloodPressurePage.clickOnWeekTab();
        //Fetch the average value in week view
        String avgInWeekView=bloodPressurePage.fetchTheBPValue(OS);
        //Swipe to readings section
        bloodPressurePage.swipeToReadingsSection(driver, OS);
        //Fetch the average of all readings found in the readings section
        String avgOfReadings=bloodPressurePage.getTheAverageOfAllValuesUnderReadingsSection();
        //Check if the average value shown in the Week page is equal to the average value of all readings found in the readings section
        Assert.assertEquals(avgInWeekView, avgOfReadings);
        Reporter.log("BloodPressure_TC026_BloodPressureWeekViewAverageValueTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc037_BloodPressureMonthViewValuesInSpindleTest(String deviceName, String OS){
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Pressure Summary Icon
        dashboardPage.clickOnBloodPressureUnderMyHealth();
        //Check if user lands in Blood Pressure screen
        bloodPressurePage=new BloodPressurePage(driver);
        bloodPressurePage.checkIfUserLandsInBloodPressureSummaryPage(OS);
        //Click on month tab
        bloodPressurePage.clickOnMonthTab();
        //Check if the BP values and date are displayed in the spindle
        bloodPressurePage.checkIfBPValuesAndTimeIsDisplayedInSpindle(driver, OS);
        Reporter.log("BloodPressure_TC037_BloodPressureMonthViewValuesInSpindleTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc039_040_BloodPressureMonthViewAverageValueInSpindleTest(String deviceName, String OS){
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Pressure Summary Icon
        dashboardPage.clickOnBloodPressureUnderMyHealth();
        //Check if user lands in Blood Pressure screen
        bloodPressurePage=new BloodPressurePage(driver);
        bloodPressurePage.checkIfUserLandsInBloodPressureSummaryPage(OS);
        //Click on month tab
        bloodPressurePage.clickOnMonthTab();
        //Check if the average values of all the readings in the spindle is equal to the average shown in the month view screen
        String avgValueAsPerSpindle = bloodPressurePage.getTheAverageOfAllValuesInSpindleInMonthView(driver, OS);
        String avgValueAsPerValueShownInMonthView = bloodPressurePage.fetchTheBPValue(OS);
        Assert.assertEquals(avgValueAsPerSpindle, avgValueAsPerValueShownInMonthView);
        Reporter.log("BloodPressure_TC039_040_BloodPressureMonthViewAverageValueInSpindleTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc043_044_045_BloodPressureDayViewWeekViewAndMonthViewDateNextToCalendarTest(String deviceName, String OS){
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Pressure Summary Icon
        dashboardPage.clickOnBloodPressureUnderMyHealth();
        //Check if user lands in Blood Pressure screen
        bloodPressurePage=new BloodPressurePage(driver);
        bloodPressurePage.checkIfUserLandsInBloodPressureSummaryPage(OS);
        //Check if user lands in day view with today displayed next to the calendar icon
        bloodPressurePage.checkIfUserLandsInDayViewOfBloodPressureSummaryPage(OS);
        Reporter.log("BloodPressure_TC043_BloodPressureDayViewDateNextToCalendarTest is pass on " + deviceName, true);
        //Click on week tab
        bloodPressurePage.clickOnWeekTab();
        //Check if current week dates range is displayed next to calendar icon
        javaUtility=new JavaUtility();
        bloodPressurePage.checkIfUserLandsInSelectedDaysOfBloodPressureSummaryPage(OS, javaUtility.getDatesFromMonToSunForPresentWeek());
        Reporter.log("BloodPressure_TC044_BloodPressureWeekViewDateNextToCalendarTest is pass on " + deviceName, true);
        //Click on month tab
        bloodPressurePage.clickOnMonthTab();
        //Check if current month name is displayed next to calendar icon
        bloodPressurePage.checkIfUserLandsInSelectedDaysOfBloodPressureSummaryPage(OS, javaUtility.fetchOnlyMonthInMonFormat());
        Reporter.log("BloodPressure_TC045_BloodPressureMonthViewDateNextToCalendarTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc046_048_049_BloodPressureDayViewWeekViewAndMonthViewBackArrowFromCalendarTest(String deviceName, String OS){
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Pressure Summary Icon
        dashboardPage.clickOnBloodPressureUnderMyHealth();
        //Check if user lands in Blood Pressure screen
        bloodPressurePage=new BloodPressurePage(driver);
        bloodPressurePage.checkIfUserLandsInBloodPressureSummaryPage(OS);
        //Click on Calendar icon
        bloodPressurePage.clickOnCalendarIcon();
        //Click on back button
        calendarPage=new CalendarPage(driver);
        calendarPage.clickOnBackBtn();
        //Check if user lands in Blood Pressure day summary screen
        bloodPressurePage.checkIfUserLandsInDayViewOfBloodPressureSummaryPage(OS);
        Reporter.log("BloodPressure_TC046_BloodPressureDayViewBackArrowFromCalendarTest is pass on " + deviceName, true);
        //Click on week tab
        bloodPressurePage.clickOnWeekTab();
        //Click on Calendar icon
        bloodPressurePage.clickOnCalendarIcon();
        //Click on back button
        calendarPage.clickOnBackBtn();
        //Check if user lands in Blood Pressure week summary screen
        javaUtility=new JavaUtility();
        bloodPressurePage.checkIfUserLandsInSelectedDaysOfBloodPressureSummaryPage(OS, javaUtility.getDatesFromMonToSunForPresentWeek());
        Reporter.log("BloodPressure_TC048_BloodPressureWeekViewBackArrowFromCalendarTest is pass on " + deviceName, true);
        //Click on month tab
        bloodPressurePage.clickOnMonthTab();
        //Click on Calendar icon
        bloodPressurePage.clickOnCalendarIcon();
        //Click on back button
        calendarPage.clickOnBackBtn();
        //Check if user lands in Blood Pressure month summary screen
        bloodPressurePage.checkIfUserLandsInSelectedDaysOfBloodPressureSummaryPage(OS, javaUtility.getDateInDDSpaceMonFormat());
        Reporter.log("BloodPressure_TC049_BloodPressureMonthViewBackArrowFromCalendarTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc047_BloodPressureCalendarSelectedDayViewTest(String deviceName, String OS){
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Pressure Summary Icon
        dashboardPage.clickOnBloodPressureUnderMyHealth();
        //Check if user lands in Blood Pressure screen
        bloodPressurePage=new BloodPressurePage(driver);
        bloodPressurePage.checkIfUserLandsInBloodPressureSummaryPage(OS);
        //Click on Calendar icon
        bloodPressurePage.clickOnCalendarIcon();
        //Select 3rd April as the date
        calendarPage=new CalendarPage(driver);
        calendarPage.clickOn3rdApril2023();
        //Check if user lands in the selected date BP summary screen
        bloodPressurePage.checkIfUserLandsInSelectedDaysOfBloodPressureSummaryPage(OS, "03 Apr");
        Reporter.log("BloodPressure_TC047_BloodPressureCalendarSelectedDayViewTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc052_BloodPressureDescriptionTileInDayViewWeekViewAndMonthViewTest(String deviceName, String OS){
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Pressure Summary Icon
        dashboardPage.clickOnBloodPressureUnderMyHealth();
        //Check if user lands in Blood Pressure screen
        bloodPressurePage=new BloodPressurePage(driver);
        bloodPressurePage.checkIfUserLandsInBloodPressureSummaryPage(OS);
        //Check if Blood Pressure description tile is displayed at the bottom of the screen
        bloodPressurePage.checkIfBloodPressureInformationTileIsDisplayedAtTheBottomOfTheScreen(driver, OS);
        //Click on week tab
        bloodPressurePage.clickOnWeekTab();
        //Check if Blood Pressure description tile is displayed at the bottom of the screen
        bloodPressurePage.checkIfBloodPressureInformationTileIsDisplayedAtTheBottomOfTheScreen(driver, OS);
        //Click on month tab
        bloodPressurePage.clickOnMonthTab();
        //Check if Blood Pressure description tile is displayed at the bottom of the screen
        bloodPressurePage.checkIfBloodPressureInformationTileIsDisplayedAtTheBottomOfTheScreen(driver, OS);
        Reporter.log("BloodPressure_TC052_BloodPressureDescriptionTileInDayViewWeekViewAndMonthViewTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc054_BloodPressureKillAppAndReopenTest(String deviceName, String OS){
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Pressure Summary Icon
        dashboardPage.clickOnBloodPressureUnderMyHealth();
        //Check if user lands in Blood Pressure screen
        bloodPressurePage=new BloodPressurePage(driver);
        bloodPressurePage.checkIfUserLandsInBloodPressureSummaryPage(OS);
        //Close the app
        try {
            ((InteractsWithApps) driver).terminateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
        } catch (Exception e){
            e.printStackTrace();
        }
        //launch the app
        ((InteractsWithApps)driver).activateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
        //Check if user lands in dashboard screen
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("BloodPressure_TC054_BloodPressureKillAppAndReopenTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc055_BloodPressureBackBtnTest(String deviceName, String OS){
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Pressure Summary Icon
        dashboardPage.clickOnBloodPressureUnderMyHealth();
        //Check if user lands in Blood Pressure screen
        bloodPressurePage=new BloodPressurePage(driver);
        bloodPressurePage.checkIfUserLandsInBloodPressureSummaryPage(OS);
        //Click on Back btn
        bloodPressurePage.clickOnBackBtn();
        //Check if user lands in dashboard screen
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("BloodPressure_TC055_BloodPressureBackBtnTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc057_BloodPressureWatchNotConnectedTest(String deviceName, String OS){
        //Unpair the watch
        dashboardPage=new DashboardPage(driver);
        dashboardPage.unpairWatch(driver);
        //Swipe down to My Health section
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Pressure Summary Icon
        dashboardPage.clickOnBloodPressureUnderMyHealth();
        //Check if user lands in Blood Pressure screen
        bloodPressurePage=new BloodPressurePage(driver);
        bloodPressurePage.checkIfUserLandsInBloodPressureSummaryPage(OS);
        Reporter.log("BloodPressure_TC057_BloodPressureWatchNotConnectedTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc058_BloodPressureBTOffTest(String deviceName, String OS){
        //Turn-off BT
        notificationAndControlCentre=new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleBluetooth(driver, OS);
        //Close the bluetooth is off popup
        bluetoothIsOffPopUp=new BluetoothIsOffPopUp(driver);
        bluetoothIsOffPopUp.clickOnClosePopUpBtn();        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Pressure Summary Icon
        dashboardPage.clickOnBloodPressureUnderMyHealth();
        //Check if user lands in Blood Pressure screen
        bloodPressurePage=new BloodPressurePage(driver);
        bloodPressurePage.checkIfUserLandsInBloodPressureSummaryPage(OS);
        Reporter.log("BloodPressure_TC058_BloodPressureBTOffTest is pass on " + deviceName, true);
    }
}