package tests;

import genericutility.BaseClass;
import genericutility.JavaUtility;
import objectrepository.*;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

@Listeners(genericutility.iTestListenerImplementation.class)
public class SleepModuleTest extends BaseClass {

    DashboardPage dashboardPage;
    SleepPage sleepPage;
    SleepDebtPopUp sleepDebtPopUp;
    SleepScorePopUp sleepScorePopUp;
    NotificationAndControlCentre notificationAndControlCentre;
    CalendarPage calendarPage;
    BluetoothIsOffPopUp bluetoothIsOffPopUp;

    @Parameters({"deviceName","os"})
    @Test
    public void tc001_006_042_043_044_045_046_047_SleepSummaryViewPreviousDayViewWithSleepDebtAndSleepTestIconDisplayTest(String deviceName, String OS){
        //Swipe down to My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Sleep Summary Icon
        dashboardPage.clickOnSleepUnderMyHealth();
        //Check if all elements in Sleep page are displayed
        sleepPage=new SleepPage(driver);
        sleepPage.checkIfAllElementsInSleepPageAreDisplayed();
        //Check if sleep debt icon is displayed
        sleepPage.checkIfSleepDebtInfoIconIsDisplayed();
        Reporter.log("Sleep_TC043_SleepDebtInfoIconTest is pass on " + deviceName, true);
        //Check if sleep score icon is displayed
        sleepPage.checkIfSleepScoreInfoIconIsDisplayed();
        Reporter.log("Sleep_TC044_SleepScoreInfoIconTest is pass on " + deviceName, true);
        //Check if proper information is displayed when user clicks on Sleep Debt info icon and Sleep score info icon
        sleepPage.clickOnSleepDebtInfoIcon();
        sleepDebtPopUp=new SleepDebtPopUp(driver);
        sleepDebtPopUp.checkIfProperSleepDebtMessageIsDisplayed();
        Reporter.log("Sleep_TC042_47_SleepDebtInfoMessageAndCloseMarkTest is pass on " + deviceName, true);
        sleepDebtPopUp.clickOnClosePopUpBtn();
        sleepPage.clickOnSleepScoreInfoIcon();
        sleepScorePopUp=new SleepScorePopUp(driver);
        sleepScorePopUp.checkIfProperSleepScoreMessageIsDisplayed();
        Reporter.log("Sleep_TC045_46_SleepScoreInfoMessageAndCloseMarkTest is pass on " + deviceName, true);
        sleepScorePopUp.clickOnClosePopUpBtn();
        Reporter.log("Sleep_TC001_SleepSummaryViewTest is pass on " + deviceName, true);
        //Click on previous btn
        sleepPage.clickOnPreviousBtn();
        //Check if user lands in previous day
        sleepPage.checkIfUserLandsInPreviousDay();
        //Click on previous btn again
        sleepPage.clickOnPreviousBtn();
        Reporter.log("Sleep_TC006_SleepDayViewPreviousDayViewTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc008_SleepPreviousWeekViewTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Sleep Summary Icon
        dashboardPage.clickOnSleepUnderMyHealth();
        //Click on week tab
        sleepPage=new SleepPage(driver);
        sleepPage.clickOnWeekTab();
        //Click on previous Btn
        sleepPage.clickOnPreviousBtn();
        //Click on previous btn again
        sleepPage.clickOnPreviousBtn();
        Reporter.log("Sleep_TC008_SleepWeekViewPreviousWeekViewTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc010_SleepPreviousMonthViewTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Sleep Summary Icon
        dashboardPage.clickOnSleepUnderMyHealth();
        //Click on week tab
        sleepPage=new SleepPage(driver);
        sleepPage.clickOnMonthTab();
        //Click on previous Btn
        sleepPage.clickOnPreviousBtn();
        Reporter.log("Sleep_TC010_SleepMonthViewPreviousMonthViewTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc018_019_SleepScoreAndSleepDebtInDayWeekAndMonthTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Sleep Summary Icon
        dashboardPage.clickOnSleepUnderMyHealth();
        //Check if sleep score and sleep Debt is displayed
        sleepPage=new SleepPage(driver);
        sleepPage.checkIfSleepScoreIsDisplayed();
        sleepPage.checkIfSleepDebtIsDisplayed();
        //Click on week tab
        sleepPage.clickOnWeekTab();
        //Check if sleep score and sleep Debt is displayed
        sleepPage.checkIfAvgSleepScoreIsDisplayed();
        sleepPage.checkIfSleepDebtIsDisplayed();
        //Click on month tab
        sleepPage.clickOnMonthTab();
        //Check if sleep score and sleep Debt is displayed
        sleepPage.checkIfAvgSleepScoreIsDisplayed();
        sleepPage.checkIfSleepDebtIsDisplayed();
        Reporter.log("Sleep_TC018_SleepScoreInDayWeekAndMonthTest is pass on " + deviceName, true);
        Reporter.log("Sleep_TC019_SleepDebtInDayWeekAndMonthTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc027_SleepSummaryBackArrowFromSleepScreenTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Sleep Summary Icon
        dashboardPage.clickOnSleepUnderMyHealth();
        //Check if user lands in sleep screen
        sleepPage=new SleepPage(driver);
        sleepPage.checkIfUserLandsInSleepScreen();
        //Click on back btn
        sleepPage.clickOnBackBtn();
        //Check if user lands in Dashboard screen
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("Sleep_TC027_SleepSummaryBackArrowFromSleepScreenTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc028_SleepSummaryBackButtonFromMobileTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Sleep Summary Icon
        dashboardPage.clickOnSleepUnderMyHealth();
        //Check if user lands in sleep screen
        sleepPage=new SleepPage(driver);
        sleepPage.checkIfUserLandsInSleepScreen();
        //Click on mobile back btn
        sleepPage.clickOnBackBtn();
        //Check if user lands in Dashboard screen
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("Sleep_TC028_SleepSummaryBackButtonFromMobileTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc029_SleepSummaryWhenNoInternetTest(String deviceName, String OS) {
        //turn off Wi-Fi
        notificationAndControlCentre=new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleWiFi(driver, OS);
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Sleep Summary Icon
        dashboardPage.clickOnSleepUnderMyHealth();
        //Click on week tab
        sleepPage=new SleepPage(driver);
        sleepPage.clickOnWeekTab();
        //Click on month tab
        sleepPage.clickOnMonthTab();
        Reporter.log("Sleep_TC029_SleepSummaryWhenNoInternetTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName", "os"})
    @Test
    public void tc030_SleepSummaryWhenNoBTTest(String deviceName, String OS) {
        //Turn Off Bluetooth
        notificationAndControlCentre = new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleBluetooth(driver, OS);
        //Close the bluetooth is off popup
        bluetoothIsOffPopUp=new BluetoothIsOffPopUp(driver);
        bluetoothIsOffPopUp.clickOnClosePopUpBtn();
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Sleep Summary Icon
        dashboardPage.clickOnSleepUnderMyHealth();
        //Click on week tab
        sleepPage=new SleepPage(driver);
        sleepPage.clickOnWeekTab();
        //Click on month tab
        sleepPage.clickOnMonthTab();
        //Turn on bluetooth
        notificationAndControlCentre.toggleBluetooth(driver, OS);
        Reporter.log("Sleep_TC030_SleepSummaryWhenNoBTTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc032_SleepCalendarWeekViewTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Sleep Summary Icon
        dashboardPage.clickOnSleepUnderMyHealth();
        //Click on week tab
        sleepPage=new SleepPage(driver);
        sleepPage.clickOnWeekTab();
        //Click on Calendar Icon
        sleepPage.clickOnCalendarIcon();
        //Select any week
        calendarPage=new CalendarPage(driver);
        calendarPage.clickOnYear2022MonthDecemberAndDate18AndOkBtn();
        //Check if user lands in the selected week page
        sleepPage.checkIfUserLandsInSelectedDateSleepPage("12 - 18 Dec");
        Reporter.log("Sleep_TC032_SleepCalendarWeekViewTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc033_SleepCalendarMonthViewTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Sleep Summary Icon
        dashboardPage.clickOnSleepUnderMyHealth();
        //Click on month tab
        sleepPage=new SleepPage(driver);
        sleepPage.clickOnMonthTab();
        //Click on Calendar Icon
        sleepPage.clickOnCalendarIcon();
        //Select any month
        calendarPage=new CalendarPage(driver);
        calendarPage.clickOnYear2022MonthDecemberAndOkBtn();
        //Check if user lands in the selected Month page
        sleepPage.checkIfUserLandsInSelectedDateSleepPage("Dec");
        Reporter.log("Sleep_TC033_SleepCalendarMonthViewTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc035_SleepShiftBetweenDayWeekAndMonthSummariesTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Sleep Summary Icon
        dashboardPage.clickOnSleepUnderMyHealth();
        //Check if user had landed in day view of sleep summaries
        sleepPage=new SleepPage(driver);
        sleepPage.checkIfUserLandsInSelectedDateSleepPage("Today");
        //Click on Week tab
        sleepPage.clickOnWeekTab();
        //Check if user has landed in the current week tab
        JavaUtility javaUtility=new JavaUtility();
        sleepPage.checkIfUserLandsInSelectedDateSleepPage(javaUtility.getDatesFromMonToSunForPresentWeek());
        //Click on month tab
        sleepPage.clickOnMonthTab();
        //Check if user lands in the selected Month page
        sleepPage.checkIfUserLandsInSelectedDateSleepPage(javaUtility.fetchOnlyMonthInMonFormat());
        Reporter.log("Sleep_TC033_SleepCalendarMonthViewTest is pass on " + deviceName, true);
    }
}