package tests;

import genericutility.AndroidWebDriverUtility;
import genericutility.BaseClass;
import genericutility.JavaUtility;
import genericutility.WebDriverUtility;
import objectrepository.*;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

@Listeners(genericutility.iTestListenerImplementation.class)
public class DashboardModuleTest extends BaseClass {
    DashboardPage dashboardPage;
    EditPageForMyHealthOptions editPageForMyHealthOptions;
    WebDriverUtility webdriverUtility;
    NotificationAndControlCentre notificationAndControlCentre;
    SettingsPage settingsPage;
    BluetoothIsOffPopUp bluetoothIsOffPopUp;
    SleepPage sleepPage;
    BloodOxygenPage bloodOxygenPage;
    MultiSportTimelinePage multiSportTimelinePage;
    MyCyclePage myCyclePage;
    HeartRatePage heartRatePage;
    TemperaturePage temperaturePage;
    SavedArticlesPage savedArticlesPage;
    ArticlePage articlePage;
    JavaUtility javaUtility;

    @Parameters({"deviceName","os"})
    @Test
    public void tc001_002_005_057_058_074_190_212_221_DashboardDisplayAllComponentsTestAndScrollTest(String deviceName, String OS){
        //Check if Titan logo is displayed
        dashboardPage=new DashboardPage(driver);
        dashboardPage.checkIfTitanLogoIsDisplayed();
        Reporter.log("Dashboard_TC001_DashboardDisplayTitanLogoTest is pass on " + deviceName, true);
        //Check if all components in the Dashboard are displayed
        dashboardPage.checkIfAllComponentsInDashboardAreDisplayed(driver, OS);
        Reporter.log("Dashboard_TC002_DashboardDisplayAllComponentsTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC057_DashboardDisplayOfActiveTaskTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC058_DashboardDisplayOfTotalZetaPointsTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC074_DashboardDisplayOfMyHealthTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC190_DashboardDisplayOfArticlesSectionTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC212_DashboardDisplayOfMusicSectionTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC221_DashboardDisplayOfTabsTest is pass on " + deviceName, true);
        if (OS.equalsIgnoreCase("Android")){
            webdriverUtility=new AndroidWebDriverUtility();
            //Scroll down in the Dashboard
            webdriverUtility.swipeScreen(driver, WebDriverUtility.Direction.DOWN);
            //Scroll up in the Dashboard
            webdriverUtility.swipeScreen(driver, WebDriverUtility.Direction.UP);
        } else if (OS.equalsIgnoreCase("IOS")) {
            //Scroll down in the Dashboard
            dashboardPage.swipeToTheElementOnTheDashboard1(driver, "up", "xpath", "//XCUIElementTypeButton[contains(@name,'paired')]");
            //Scroll up in the Dashboard
            dashboardPage.swipeToTheElementOnTheDashboard1(driver, "down","label", "Articles for you");
        }
        Reporter.log("Dashboard_TC005_DashboardScrollUpAndDownTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc006_DashboardRefreshTest(String deviceName, String OS) throws Throwable{
        //Scroll down in Dashboard to refresh
        dashboardPage=new DashboardPage(driver);
        dashboardPage.refreshDashboardScreen(driver, OS);
        dashboardPage.checkIfDataHasBeenSyncedFewSecondsAgo();
        Reporter.log("Dashboard_TC006_DashboardRefreshTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName"})
    @Test
    public void tc007_008_DashboardFitnessCardTest(String deviceName){
        //Check if all the Components in Fitness card are displayed
        dashboardPage=new DashboardPage(driver);
        dashboardPage.checkIfAllComponentsOfFitnessCardAreDisplayed();
        Reporter.log("Dashboard_TC007_DashboardFitnessCardTest is pass on " + deviceName, true);
        //Check if connected/disconnected icon is displayed
        dashboardPage.checkIfConnectedDisconnectedIconIsDisplayed();
        Reporter.log("Dashboard_TC008_DashboardConnectionIconDisplayTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc009_013_DashboardConnectedIconAndIconIfWatchWithinBTProximityTest(String deviceName, String OS){
        //Check if Connected Icon is displayed
        dashboardPage=new DashboardPage(driver);
        dashboardPage.checkIfConnectedIconIsDisplayed(OS);
        Reporter.log("Dashboard_TC009_DashboardConnectedIconDisplayTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC013_DashboardConnectedIconIfWatchWithinBTProximityTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName"})
    @Test
    public void tc010_DashboardConnectedOrDisconnectedIconIfWatchDisconnectedTest(String deviceName){
        //Unpair the watch
        dashboardPage=new DashboardPage(driver);
        dashboardPage.unpairWatch(driver);
        //Check if Disconnected Icon is displayed
        dashboardPage.checkIfDisconnectedIconIsDisplayed();
        Reporter.log("Dashboard_TC010_DashboardConnectedOrDisconnectedIconIfWatchDisconnectedTest is pass on " + deviceName, true);
        //Pair the watch
        dashboardPage.clickOnHomeBtn();
        dashboardPage.pairWatch();
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc011_012_DashboardDisconnectedIconAndIconIfWatchOutOfBTProximityTest(String deviceName, String OS){
        //Turn Off Bluetooth
        notificationAndControlCentre = new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleBluetooth(driver, OS);
        //Check if Disconnected Icon is displayed
        dashboardPage=new DashboardPage(driver);
        dashboardPage.checkIfDisconnectedIconIsDisplayed();
        Reporter.log("Dashboard_TC011_DashboardDisconnectedIconWhenBTOffTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC012_DashboardDisconnectedIconIfWatchOutOfBTProximityTest is pass on " + deviceName, true);
        //Turn on bluetooth
        notificationAndControlCentre.toggleBluetooth(driver, OS);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc014_DashboardConnectedOrDisconnectedIconIfFlightModeIsONTest(String deviceName, String OS){
        //turn on Flight Mode
        notificationAndControlCentre=new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleFlightMode(driver, OS);
        //Check if Disconnected Icon is displayed
        dashboardPage.checkIfDisconnectedIconIsDisplayed();
        Reporter.log("Dashboard_TC014_DashboardConnectedOrDisconnectedIconIfFlightModeIsONTest is pass on " + deviceName, true);
        //turn off Flight Mode
        notificationAndControlCentre.toggleFlightMode(driver, OS);
    }

    @Parameters({"deviceName"})
    @Test
    public void tc018_019_020_DashboardDisplayOfStepsSleepMultiSportInActivityCardsTest(String deviceName){
        //Check if Steps achieved text is displayed
        dashboardPage=new DashboardPage(driver);
        dashboardPage.checkIfStepsAchievedIsDisplayed();
        Reporter.log("Dashboard_TC018_DashboardDisplayOfStepsInActivityCardsTest is pass on " + deviceName, true);
        //Check if Sleep achieved text is displayed
        dashboardPage.checkIfSleepAchievedIsDisplayed();
        Reporter.log("Dashboard_TC019_DashboardDisplayOfSleepInActivityCardsTest is pass on " + deviceName, true);
        //Check if Multi Sport achieved text is displayed
        dashboardPage.checkIfMultiSportAchievedIsDisplayed();
        Reporter.log("Dashboard_TC020_DashboardDisplayOfMultiSportInActivityCardsTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName"})
    @Test
    public void tc021_DashboardVerifyLastSyncedMessageTest(String deviceName){
        //Check if Last synced few seconds ago is displayed
        dashboardPage=new DashboardPage(driver);
        dashboardPage.checkIfDataHasBeenSyncedFewSecondsAgo();
        Reporter.log("Dashboard_TC021_DashboardVerifyLastSyncedMessageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc043_044_045_DashboardChangeStepSleepMultiSportGoalsWhenBTOffAndCheckIfReflectedInActivityCardTest(String deviceName, String OS){
        //Turn Off Bluetooth
        notificationAndControlCentre = new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleBluetooth(driver, OS);
        //Fetch the Step, Sleep and MultiSport target data from the Activity Cards
        dashboardPage=new DashboardPage(driver);
        String stepTargetBeforeChange = dashboardPage.fetchStepTargetDataFromActivityCards();
        String sleepTargetBeforeChange = dashboardPage.fetchSleepTargetDataFromActivityCards();
        String multiSportTargetBeforeChange = dashboardPage.fetchMultiSportTargetDataFromActivityCards();
        //Change Step, Sleep and MultiSport goals in settings
        //Navigate to settings screen
        dashboardPage.clickOnSettingsTab();
        //Click on goals and click on Step goal
        settingsPage=new SettingsPage(driver);
        settingsPage.clickOnGoalsOptionAndThenStepGoalOption();
        //Error message should be displayed
        bluetoothIsOffPopUp=new BluetoothIsOffPopUp(driver);
        bluetoothIsOffPopUp.checkIfBluetoothIsOffPopUpIsDisplayed();
        //Close the pop up
        bluetoothIsOffPopUp.clickOnClosePopUpBtn();
        //Click on Sleep goal
        settingsPage.clickOnSleepGoalOption();
        //Error message should be displayed
        bluetoothIsOffPopUp.checkIfBluetoothIsOffPopUpIsDisplayed();
        //Close the pop up
        bluetoothIsOffPopUp.clickOnClosePopUpBtn();
        //Click on MultiSport Goal
        settingsPage.clickOnMultiSportGoalOption();
        //Error message should be displayed
        bluetoothIsOffPopUp.checkIfBluetoothIsOffPopUpIsDisplayed();
        //Close the pop up
        bluetoothIsOffPopUp.clickOnClosePopUpBtn();
        //Click on Home/Dashboard Btn
        settingsPage.clickOnDashboardBtn();
        //Fetch the Step, Sleep and MultiSport target data from the Activity Cards
        String stepTargetAfterChange = dashboardPage.fetchStepTargetDataFromActivityCards();
        String sleepTargetAfterChange = dashboardPage.fetchSleepTargetDataFromActivityCards();
        String multiSportTargetAfterChange = dashboardPage.fetchMultiSportTargetDataFromActivityCards();
        //Check if the target values have changed
        Assert.assertTrue(stepTargetBeforeChange.equals(stepTargetAfterChange));
        Assert.assertTrue(sleepTargetBeforeChange.equals(sleepTargetAfterChange));
        Assert.assertTrue(multiSportTargetBeforeChange.equals(multiSportTargetAfterChange));
        Reporter.log("Dashboard_TC043_DashboardChangeStepGoalsWhenBTOffAndCheckIfReflectedInActivityCardTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC044_DashboardChangeSleepGoalsWhenBTOffAndCheckIfReflectedInActivityCardTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC045_DashboardChangeMultiSportGoalsWhenBTOffAndCheckIfReflectedInActivityCardTest is pass on " + deviceName, true);
        //Turn on bluetooth
        notificationAndControlCentre.toggleBluetooth(driver, OS);
    }
    @Parameters({"deviceName"})
    @Test
    public void tc047_DashboardSleepStepsMultiSportWhenNoDataTest(String deviceName){
        //Fetch data from Sleep, Steps and Multi Sport Activity circles
        dashboardPage=new DashboardPage(driver);
        String stepAchieved=dashboardPage.fetchStepAchievedDataFromActivityCards();
        String sleepAchieved=dashboardPage.fetchSleepAchievedDataFromActivityCards();
        String multiSportAchieved=dashboardPage.fetchMultiSportAchievedDataFromActivityCards();
        Assert.assertTrue(stepAchieved.equals("--"));
        Assert.assertTrue(sleepAchieved.equals("--"));
        Assert.assertTrue(multiSportAchieved.equals("--"));
        Reporter.log("Dashboard_TC047_DashboardSleepStepsMultiSportWhenNoDataTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName"})
    @Test
    public void tc059_DashboardSwipingOfActiveTasksCardsTest(String deviceName){
        //Swipe through active tasks and check if all active tasks are displayed
        dashboardPage=new DashboardPage(driver);
        dashboardPage.checkIfFirstActiveTaskIsDisplayed();
        dashboardPage.swipeToSecondActiveTaskFromFirstActiveTask(driver);
        dashboardPage.checkIfSecondActiveTaskIsDisplayed();
        Reporter.log("Dashboard_TC059_DashboardSwipingOfActiveTasksCardsTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName"})
    @Test
    public void tc060_061_DashboardProgressPercentageAndZetaPointsOfActiveTasksTest(String deviceName){
        //Check if progress percentage is displayed under individual active tasks icons
        dashboardPage=new DashboardPage(driver);
        dashboardPage.checkIfProgressPercentageIsDisplayedUnderEachActiveTaskIcon(driver);
        Reporter.log("Dashboard_TC060_DashboardProgressPerOfActiveTasksTest is pass on " + deviceName, true);
        //Check if zeta points are displayed for all active tasks
        dashboardPage.checkIfZetaPointsAreDisplayedForAllActiveTasks(driver);
        Reporter.log("Dashboard_TC061_DashboardDisplayOfZetaPointsOfActiveTasksTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc069_DashboardDisplayOfActiveTasksCardsWhenNoInternetTest(String deviceName, String OS){
        //turn off Wi-Fi
        notificationAndControlCentre=new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleWiFi(driver, OS);
        //Swipe through active tasks
        dashboardPage=new DashboardPage(driver);
        dashboardPage.checkIfFirstActiveTaskIsDisplayed();
        dashboardPage.swipeToSecondActiveTaskFromFirstActiveTask(driver);
        dashboardPage.checkIfSecondActiveTaskIsDisplayed();
        Reporter.log("Dashboard_TC069_DashboardDisplayOfActiveTasksCardsWhenNoInternetTest is pass on " + deviceName, true);
        //Turn on Wi-Fi
        notificationAndControlCentre.toggleWiFi(driver, OS);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc070_DashboardDisplayOfActiveTasksCardsWhenFlightModeONTest(String deviceName, String OS){
        //turn on Flight Mode
        notificationAndControlCentre=new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleFlightMode(driver, OS);
        //Swipe through active tasks
        dashboardPage=new DashboardPage(driver);
        dashboardPage.checkIfFirstActiveTaskIsDisplayed();
        dashboardPage.swipeToSecondActiveTaskFromFirstActiveTask(driver);
        dashboardPage.checkIfSecondActiveTaskIsDisplayed();
        Reporter.log("Dashboard_TC069_DashboardDisplayOfActiveTasksCardsWhenFlightModeONTest is pass on " + deviceName, true);
        //turn off Flight Mode
        notificationAndControlCentre.toggleFlightMode(driver, OS);
    }

    @Parameters({"deviceName"})
    @Test
    public void tc073_DashboardDisplayOfActiveTasksWhenWatchDisconnectedTest(String deviceName){
        //Unpair the watch
        dashboardPage=new DashboardPage(driver);
        dashboardPage.unpairWatch(driver);
        //Swipe through active tasks
        dashboardPage.checkIfFirstActiveTaskIsDisplayed();
        dashboardPage.swipeToSecondActiveTaskFromFirstActiveTask(driver);
        dashboardPage.checkIfSecondActiveTaskIsDisplayed();
        Reporter.log("Dashboard_TC073_DashboardDisplayOfActiveTasksWhenWatchDisconnectedTest is pass on " + deviceName, true);
        //Pair the watch
        dashboardPage.clickOnHomeBtn();
        dashboardPage.pairWatch();
    }

    @Parameters({"deviceName"})
    @Test
    public void tc075_085_DashboardEditMyHealthAndBackBtnTest(String deviceName){
        //Click on edit under My Health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnEditInMyHealthSection();
        //Check if user lands in Edit My Health Section Page
        editPageForMyHealthOptions=new EditPageForMyHealthOptions(driver);
        editPageForMyHealthOptions.checkIfUserLandsInEditMyHealthSectionPage();
        Reporter.log("Dashboard_TC075_DashboardEditMyHealthTest is pass on " + deviceName, true);
        //Click on back button
        editPageForMyHealthOptions.clickOnBackBtn();
        //Check if user lands in Dashboard page
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("Dashboard_TC085_DashboardEditMyHealthBackBtnTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc077_147_148_149_DashboardMyHealthEditScreenDisplayOfFeaturesTest(String deviceName, String OS){
        //Navigate to settings page
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnSettingsTab();
        //Fetch the gender
        settingsPage=new SettingsPage(driver);
        String gender = settingsPage.returnTheGenderOfTheUser();
        //Navigate to Dashboard
        settingsPage.clickOnDashboardBtn();
        //Swipe to my health section
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on edit btn in my health section
        dashboardPage.clickOnEditInMyHealthSection();
        //Check if all Features are displayed in the Edit My Health Page
        editPageForMyHealthOptions=new EditPageForMyHealthOptions(driver);
        editPageForMyHealthOptions.checkIfAllFeaturesAreDisplayed(gender);
        Reporter.log("Dashboard_TC077_DashboardMyHealthEditScreenDisplayOfFeaturesTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC147_DashboardDisplayOfMyCycleCardWhenFemaleIsSelectedAsGenderTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC148_DashboardDisplayOfMyCycleCardWhenMaleIsSelectedAsGenderTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC149_DashboardDisplayOfMyCycleCardWhenGenderIsChangedToFemaleFromMaleOrOthersTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc078_079_DashboardMyHealthEditScreenChangePositionOfCardsAndSaveTest(String deviceName, String OS){
        //Navigate to settings page and fetch the gender of the user
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnSettingsTab();
        //Fetch the gender
        settingsPage=new SettingsPage(driver);
        String gender = settingsPage.returnTheGenderOfTheUser();
        //Navigate to Dashboard
        settingsPage.clickOnDashboardBtn();
        //Swipe to my health section
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on edit btn in my health section
        dashboardPage.clickOnEditInMyHealthSection();
        //Check if all Features are displayed in the Edit My Health Page
        editPageForMyHealthOptions=new EditPageForMyHealthOptions(driver);
        editPageForMyHealthOptions.checkIfAllFeaturesAreDisplayed(gender);
        //Change the position of cards
        editPageForMyHealthOptions.changePositionsOfFeatures(driver, OS);
        Reporter.log("Dashboard_TC078_DashboardMyHealthEditScreenChangePositionOfCardsTest is pass on " + deviceName, true);
        //Click on save btn
        editPageForMyHealthOptions.clickOnSaveBtn();
        //Check if user lands in Dashboard
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("Dashboard_TC079_DashboardMyHealthEditScreenChangePositionOfCardsAndSaveTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc086_097_DashboardDisplayOfSleepCardTest(String deviceName, String OS){
        //Swipe to my health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Check if Sleep card is displayed
        dashboardPage.checkIfSleepFeatureIsDisplayedUnderMyHealthSection();
        Reporter.log("Dashboard_TC086_DashboardDisplayOfSleepCardTest is pass on " + deviceName, true);
        //Check if the user is able to click on the sleep card
        dashboardPage.clickOnSleepUnderMyHealth();
        //Check if user lands in Sleep summary screen
        sleepPage=new SleepPage(driver);
        sleepPage.checkIfUserLandsInSleepScreen();
        Reporter.log("Dashboard_TC097_DashboardClickOnSleepCardTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc099_110_DashboardDisplayOfBloodOxygenCardTest(String deviceName, String OS){
        //Swipe to my health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Check if Blood oxygen card is displayed
        dashboardPage.checkIfBloodOxygenFeatureIsDisplayedUnderMyHealthSection();
        Reporter.log("Dashboard_TC099_DashboardDisplayOfBloodOxygenCardTest is pass on " + deviceName, true);
        //Check if the user is able to click on the Blood oxygen card
        dashboardPage.clickOnBloodOxygenUnderMyHealth();
        //Check if user lands in Blood oxygen summary screen
        bloodOxygenPage=new BloodOxygenPage(driver);
        bloodOxygenPage.checkIfUserLandsInBloodOxygenScreen(OS);
        Reporter.log("Dashboard_TC110_DashboardClickOnBloodOxygenCardTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc113_114_115_116_119_125_DashboardDisplayOfTemperatureCardIconLastMeasuredValueAndClickTest(String deviceName, String OS){
        //Swipe to my health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Check if Temperature card is displayed
        dashboardPage.checkIfTemperatureFeatureIsDisplayedUnderMyHealthSection();
        Reporter.log("Dashboard_TC113_DashboardDisplayOfTemperatureCardTest is pass on " + deviceName, true);
        //Check if Temperature Icon is displayed
        dashboardPage.checkIfTemperatureIconIsDisplayedUnderMyHealthSection();
        Reporter.log("Dashboard_TC114_DashboardDisplayOfTemperatureIconTest is pass on " + deviceName, true);
        //Check if last measured time/date is displayed
        dashboardPage.checkIfLastMeasuredDateOrTimeForTemperatureIsDisplayedUnderMyHealthSection();
        Reporter.log("Dashboard_TC115_DashboardDisplayOfLatMeasuredTemperatureValueTest is pass on " + deviceName, true);
        //Check if Temperature value is displayed
        dashboardPage.checkIfLastMeasuredTemperatureValeIsDisplayedInTemperatureHealthCard();
        Reporter.log("Dashboard_TC116_119_DashboardDisplayOfTemperatureValueTest is pass on " + deviceName, true);
        //Check if user lands in temperature screen when user clicks on temperature health card
        //Click on Temperature health card
        dashboardPage.clickOnTemperatureHealthCard();
        //Check if user lands in Temperature Screen
        temperaturePage=new TemperaturePage(driver);
        temperaturePage.checkIfUserLandsInTemperatureScreen();

        temperaturePage.clickOnDayBtn();
        Reporter.log("Dashboard_TC125_DashboardDisplayOfTemperatureValueTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc121_DashboardValueOfTemperatureWhenUnitSystemChangedTest(String deviceName, String OS){
        //Swipe to my health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Fetch the temperature value from the Temperature card
        String tempBefore= dashboardPage.fetchTheTemperatureValueFromTemperatureCard();
        //Change the temperature unit system from settings
        //Click on settings tab
        dashboardPage.clickOnSettingsTab();
        //Click on My Watch and then click on Temperature unit system
        settingsPage=new SettingsPage(driver);
        settingsPage.clickOnMyWatchOptionAndClickOnTemperatureUnitSystemOption(driver, OS);
        //Click on Change to Imperial/Metric
        TemperatureUnitSystemPopUp temperatureUnitSystemPopUp=new TemperatureUnitSystemPopUp(driver);
        temperatureUnitSystemPopUp.clickOnChangeTemperatureUnitBtn();
        //Verify confirmation toast message
        settingsPage.checkConfirmationToastMessageForChanges();
        //Navigate to dashboard
        settingsPage.clickOnDashboardBtn();
        //Check if the temperature unit has changed
        String tempAfter= dashboardPage.fetchTheTemperatureValueFromTemperatureCard();
        float tempAfterCalculated;
        javaUtility=new JavaUtility();
        if (tempBefore.contains("℉")){
            Assert.assertTrue(tempAfter.contains("℃"));
            tempAfterCalculated = javaUtility.changeTempFromFahrenheitToCelsius(tempBefore);
            Assert.assertEquals(tempAfter, tempAfterCalculated);
            System.out.println(tempBefore);
            System.out.println(tempAfter);
            System.out.println(tempAfterCalculated);
        } else if (tempBefore.contains("℃")) {
            Assert.assertTrue(tempAfter.contains("℉"));
            tempAfterCalculated = javaUtility.changeTempFromCelsiusToFahrenheit(tempBefore);
            System.out.println(tempBefore);
            System.out.println(tempAfter);
            System.out.println(tempAfterCalculated);
            Assert.assertEquals(tempAfter, tempAfterCalculated);
            System.out.println(tempBefore);
            System.out.println(tempAfter);
            System.out.println(tempAfterCalculated);
        }
        Reporter.log("Dashboard_TC121_DashboardValueOfTemperatureWhenUnitSystemChangedTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc129_130_137_DashboardDisplayOfMultiSportCardTest(String deviceName, String OS){
        //Swipe to my health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Check if Multi Sport card is displayed
        dashboardPage.checkIfMultiSportFeatureIsDisplayedUnderMyHealthSection();
        Reporter.log("Dashboard_TC129_DashboardDisplayOfMultiSportCardTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC130_DashboardDisplayOfMultiSportIconTest is pass on " + deviceName, true);
        //Check if the user is able to click on the Multi Sport card
        dashboardPage.clickOnMultiSportUnderMyHealth();
        //Check if user lands in Multi Sport summary screen
        multiSportTimelinePage=new MultiSportTimelinePage(driver);
        multiSportTimelinePage.checkIfUserLandsInMultiSportSummaryScreen();
        Reporter.log("Dashboard_TC137_DashboardClickOnMultiSportCardTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc139_140_141_142_143_144_145_150_DashboardDisplayOfMyCycleCardTest(String deviceName, String OS){
        //Swipe to my health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Check if My Cycle card is displayed
        dashboardPage.checkIfMyCycleFeatureIsDisplayedUnderMyHealthSection();
        Reporter.log("Dashboard_TC139_DashboardDisplayOfMyCycleCardTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC140_DashboardDisplayOfMyCycleIconTest is pass on " + deviceName, true);
        //Check if user can see Current day and remaining days for next period
        dashboardPage.checkIfMyCycleCardUnderMyHealthDisplaysCurrentDayAndRemainingDaysOfPeriod();
        Reporter.log("Dashboard_TC141_DashboardDisplayOfCurrentDayUnderMyCycleCardTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC143_DashboardDisplayOfRemainingDaysUnderMyCycleCardTest is pass on " + deviceName, true);
        //Fetch Remaining days for next period from My Cycle card
        int remDaysFromMyCycleCard=dashboardPage.returnRemainingDaysForNextPeriodFromMyCycleCard();
        int curDayFromMyCycleCard=dashboardPage.returnCurrentDayOfPeriodFromMyCycleCard();
        //Check if period stage is displayed in My Cycle card
        dashboardPage.checkIfPeriodStageIsDisplayed();
        Reporter.log("Dashboard_TC145_DashboardDisplayOfStageInformationTest is pass on " + deviceName, true);
        //Check if the user is able to click on the My Cycle card
        dashboardPage.clickOnMyCycleUnderMyHealth();
        //Check if user lands in My Cycle summary screen
        myCyclePage=new MyCyclePage(driver);
        myCyclePage.checkIfUserLandsInMyCyclePage();
        Reporter.log("Dashboard_TC150_DashboardClickOnMyCycleCardTest is pass on " + deviceName, true);
        //Check if Remaining days for next period is same in My Cycle card as well as My Cycle page
        int remDaysFromMyCyclePage=myCyclePage.returnRemainingDaysForNextPeriodFromMyCyclePage();
        Assert.assertTrue(remDaysFromMyCycleCard==remDaysFromMyCyclePage);
        Reporter.log("Dashboard_TC142_DashboardRemainingDaysForNextPeriodOnMyCycleCardAndPageTest is pass on " + deviceName, true);
        int curDayFromMyCyclePage=myCyclePage.returnCurrentDayOfPeriodFromMyCyclePage();
        Assert.assertTrue(curDayFromMyCycleCard==curDayFromMyCyclePage);
        Reporter.log("Dashboard_TC144_DashboardCurrentDaysForNextPeriodOnMyCycleCardAndPageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc151_152_153_154_161_DashboardDisplayOfHeartRateCardTest(String deviceName, String OS){
        //Swipe to my health section
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Check if Heart Rate card is displayed
        dashboardPage.checkIfHeartRateFeatureIsDisplayedUnderMyHealthSection();
        Reporter.log("Dashboard_TC151_DashboardDisplayOfHeartRateCardTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC152_DashboardDisplayOfHeartRateIconTest is pass on " + deviceName, true);
        //Check if Heart Rate in bpm and Last measured time is displayed in Heart rate card
        dashboardPage.checkIfHeartRateInBpmAndLastSyncedTimeIsDisplayedInHeartRateCard();
        Reporter.log("Dashboard_TC153_DashboardDisplayOfHeartRateInBpmTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC154_DashboardDisplayOfHeartRateLastSyncedTimeTest is pass on " + deviceName, true);
        //Check if the user is able to click on the Heart Rate card
        dashboardPage.clickOnHeartRateUnderMyHealth();
        //Check if user lands in Heart Rate summary screen
        heartRatePage=new HeartRatePage(driver);
        heartRatePage.checkIfUserLandsInHeartRatePage();
        Reporter.log("Dashboard_TC161_DashboardClickOnHeartRateCardTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName"})
    @Test
    public void tc191_208_210_211_DashboardClickOnViewAllArticlesAndBackBtnTest(String deviceName){
        //Swipe to the bottom of the dashboard
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToTheBottomOfTheDashboard(driver);
        //Click on view all under Articles section
        dashboardPage.clickOnViewAllUnderArticlesSection();
        //Check if user lands in saved articles page
        savedArticlesPage =new SavedArticlesPage(driver);
        savedArticlesPage.checkIfUserLandsInArticlesPage();
        Reporter.log("Dashboard_TC191_DashboardClickOnViewAllArticlesTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC208_DashboardClickOnViewAllArticlesTest is pass on " + deviceName, true);
        //Click on back btn
        savedArticlesPage.clickOnBackBtn();
        //Check if user lands in Dashboard screen
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("Dashboard_TC210_DashboardBackArrowFunctionalityTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC211_DashboardBackArrowFunctionalityTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc192_193_DashboardArticlesSectionWhenBTOffAndOnTest(String deviceName, String OS){
        //Swipe to the bottom of the dashboard
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToTheBottomOfTheDashboard(driver);
        //Turn Off Bluetooth
        notificationAndControlCentre = new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleBluetooth(driver, OS);
        //Check if articles section is displayed
        dashboardPage.checkIfArticlesSectionIsDisplayed();
        Reporter.log("Dashboard_TC192_DashboardArticlesSectionWhenBTOffTest is pass on " + deviceName, true);
        //Turn on bluetooth
        notificationAndControlCentre.toggleBluetooth(driver, OS);
        //Check if articles section is displayed
        dashboardPage.checkIfArticlesSectionIsDisplayed();
        Reporter.log("Dashboard_TC193_DashboardArticlesSectionWhenBTOffAndOnTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName"})
    @Test
    public void tc194_DashboardArticlesSectionWhenWatchDisconnectedTest(String deviceName){
        //Swipe to the bottom of the dashboard
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToTheBottomOfTheDashboard(driver);
        //Unpair the watch
        dashboardPage=new DashboardPage(driver);
        dashboardPage.unpairWatch(driver);
        //Check if articles section is displayed
        dashboardPage.checkIfArticlesSectionIsDisplayed();
        Reporter.log("Dashboard_TC194_DashboardArticlesSectionWhenWatchDisconnectedTest is pass on " + deviceName, true);
        //Pair the watch
        dashboardPage.clickOnHomeBtn();
        dashboardPage.pairWatch();
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc195_196_DashboardArticlesSectionWhenInternetOffAndOnTest(String deviceName, String OS){
        //Swipe to the bottom of the dashboard
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToTheBottomOfTheDashboard(driver);
        //Check if articles section is displayed
        dashboardPage.checkIfArticlesSectionIsDisplayed();
        //turn off Wi-Fi
        notificationAndControlCentre=new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleWiFi(driver, OS);
        //turn on Wi-Fi
        notificationAndControlCentre.toggleWiFi(driver, OS);
        //Check if articles section is displayed
        dashboardPage.checkIfArticlesSectionIsDisplayed();
        Reporter.log("Dashboard_TC195_DashboardArticlesSectionWhenInternetOffTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC196_DashboardArticlesSectionWhenInternetOffAndOnTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc197_DashboardArticlesSectionWhenFlightModeOnTest(String deviceName, String OS){
        //Swipe to the bottom of the dashboard
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToTheBottomOfTheDashboard(driver);
        //turn on Flight Mode
        notificationAndControlCentre=new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleFlightMode(driver, OS);
        //Check if articles section is displayed
        dashboardPage.checkIfArticlesSectionIsDisplayed();
        Reporter.log("Dashboard_TC197_DashboardArticlesSectionWhenFlightModeOnTest is pass on " + deviceName, true);
        //turn off Flight Mode
        notificationAndControlCentre.toggleFlightMode(driver, OS);
    }

    @Parameters({"deviceName"})
    @Test
    public void tc198_199_200_201_202_203_204_205_206_207_DashboardScrollAbilityOfArticlesSectionAndDisplayOfIconsTest(String deviceName){
        //Swipe to the bottom of the dashboard
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToTheBottomOfTheDashboard(driver);
        //Check if articles section is displayed
        dashboardPage.checkIfArticlesSectionIsDisplayed();
        //Check if new text is displayed on the article image
        dashboardPage.checkIfNewTextIsDisplayedOnArticleImage();
        Reporter.log("Dashboard_TC206_DashboardScrollAbilityOfArticlesSectionTest is pass on " + deviceName, true);
        //Horizontal swipe through the articles
        dashboardPage.horizontalSwipeOnTheScreen(driver);
        dashboardPage.horizontalSwipeOnTheScreen(driver);
        dashboardPage.horizontalSwipeOnTheScreen(driver);
        Reporter.log("Dashboard_TC198_DashboardScrollAbilityOfArticlesSectionTest is pass on " + deviceName, true);
        //Check if popular icon is displayed
        dashboardPage.checkIfAllIconsAreDisplayedOnTheArticleImage();
        Reporter.log("Dashboard_TC199_DashboardDisplayOfPopularIconOnArticleImageTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC200_DashboardDisplayOfLikeIconOnArticleImageTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC202_DashboardDisplayOfShareIconOnArticleImageTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC204_DashboardDisplayOfSaveIconOnArticleImageTest is pass on " + deviceName, true);
        //Check if user is able to like the article
        dashboardPage.clickOnLikeArticleBtn();
        Reporter.log("Dashboard_TC201_DashboardClickAbilityOfLikeBtnTest is pass on " + deviceName, true);
        //Check if user is able to share the article
        dashboardPage.clickOnShareArticleBtn();
        Reporter.log("Dashboard_TC203_DashboardClickAbilityOfShareBtnTest is pass on " + deviceName, true);
        //Close the popup
        dashboardPage.clickOnCloseArticleSharepopUp();
        //Check if user is able to save the article
        dashboardPage.clickOnSaveArticleBtn();
        Reporter.log("Dashboard_TC205_DashboardClickAbilityOfSaveBtnTest is pass on " + deviceName, true);
        //Check if read tick mark is displayed when the user reads an article
        dashboardPage.checkIfReadTickIsDisplayedOnTheArticleImage();
        Reporter.log("Dashboard_TC207_DashboardDisplayOfReadTickOnArticleImageTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc213_214_DashboardMusicSectionWhenBTOffAndOnTest(String deviceName, String OS){
        //Swipe to the bottom of the dashboard
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToTheBottomOfTheDashboard(driver);
        //Turn Off Bluetooth
        notificationAndControlCentre = new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleBluetooth(driver, OS);
        //Check if music section is displayed
        dashboardPage.checkIfMusicSectionIsDisplayed();
        Reporter.log("Dashboard_TC213_DashboardMusicSectionWhenBTOffTest is pass on " + deviceName, true);
        //Turn on bluetooth
        notificationAndControlCentre.toggleBluetooth(driver, OS);
        //Check if articles section is displayed
        dashboardPage.checkIfMusicSectionIsDisplayed();
        Reporter.log("Dashboard_TC214_DashboardMusicSectionWhenBTOffAndOnTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName"})
    @Test
    public void tc215_DashboardMusicSectionWhenWatchDisconnectedTest(String deviceName){
        //Swipe to the bottom of the dashboard
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToTheBottomOfTheDashboard(driver);
        //Unpair the watch
        dashboardPage=new DashboardPage(driver);
        dashboardPage.unpairWatch(driver);
        //Check if music section is displayed
        dashboardPage.checkIfMusicSectionIsDisplayed();
        Reporter.log("Dashboard_TC215_DashboardMusicSectionWhenWatchDisconnectedTest is pass on " + deviceName, true);
        //Pair the watch
        dashboardPage.clickOnHomeBtn();
        dashboardPage.pairWatch();
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc216_217_DashboardMusicSectionWhenInternetOffAndOnTest(String deviceName, String OS){
        //Swipe to the bottom of the dashboard
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToTheBottomOfTheDashboard(driver);
        //Check if music section is displayed
        dashboardPage.checkIfMusicSectionIsDisplayed();
        //turn off Wi-Fi
        notificationAndControlCentre=new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleWiFi(driver, OS);
        //turn on Wi-Fi
        notificationAndControlCentre.toggleWiFi(driver, OS);
        //Check if music section is displayed
        dashboardPage.checkIfMusicSectionIsDisplayed();
        Reporter.log("Dashboard_TC216_DashboardMusicSectionWhenInternetOffTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC217_DashboardMusicSectionWhenInternetOffAndOnTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName"})
    @Test
    public void tc218_219_DashboardMusicPageWhenClickOnPlayBtnAndMusicPageTitleTest(String deviceName){
        //Swipe to the bottom of the dashboard
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToTheBottomOfTheDashboard(driver);
        //Check if music section is displayed
        dashboardPage.checkIfMusicSectionIsDisplayed();
        //Click on play btn
        dashboardPage.clickOnPlayMusicBtn();
        //Check if user lands in music page
        MusicPage musicPage=new MusicPage(driver);
        musicPage.checkIfUserLandsInMusicPage(driver);
        Reporter.log("Dashboard_TC218_DashboardMusicPageWhenClickOnPlayBtnTest is pass on " + deviceName, true);
        Reporter.log("Dashboard_TC219_DashboardMusicPageTitleTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName"})
    @Test
    public void tc223_DashboardClickOnArticleAndCheckArticleIsDisplayedTest(String deviceName){
        //Swipe to the bottom of the dashboard
        dashboardPage=new DashboardPage(driver);
        dashboardPage.swipeToTheBottomOfTheDashboard(driver);
        //Fetch the title of the first article
        String articleTitle=dashboardPage.fetchTheTitleOfFirstArticle();
        dashboardPage.clickOnFirstArticle();
        //Check if user lands in the selected article page
        articlePage=new ArticlePage(driver);
        String articleInView= articlePage.returnArticleTitle(driver);
        Assert.assertTrue(articleTitle.equalsIgnoreCase(articleInView));
        Reporter.log("Dashboard_TC223_DashboardClickOnArticleAndCheckArticleIsDisplayedTest is pass on " + deviceName, true);
    }
}