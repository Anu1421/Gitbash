package tests;

import com.aventstack.extentreports.Status;
import genericutility.BaseClass;
import genericutility.JSONUtility;
import genericutility.JavaUtility;
import genericutility.iTestListenerImplementation;
import io.appium.java_client.InteractsWithApps;
import objectrepository.*;
import org.testng.Reporter;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class BloodOxygenModuleTest extends BaseClass {
    DashboardPage dashboardPage;
    BloodOxygenPage bloodOxygenPage;
    CalendarPage calendarPage;
    NotificationAndControlCentre notificationAndControlCentre;
    JavaUtility javaUtility;
    BluetoothIsOffPopUp bluetoothIsOffPopUp;

    /**
     *  TC001_BloodOxygenVerifyClickOnSpO2IconUnderMyHealthTest
     *  TC004_BloodOxygenVerifyIfMaxMinAndLatestSpO2PercentagesAreDisplayedTest
     *  TC013_BloodOxygenVerifyIfUserCanNavigateToPreviousDaysTest
     */
    @Parameters("deviceName")
    @Test
    public void test001_004_013_BloodOxygen(String deviceName) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OSName);
        iTestListenerImplementation.test.log(Status.INFO, "Swipe to my health section has been performed");
        //Click on Blood Oxygen Icon
        dashboardPage.clickOnBloodOxygenUnderMyHealth();
        iTestListenerImplementation.test.log(Status.INFO, "Click on Blood Oxygen Icon has been performed");
        //Check if user lands in Blood Oxygen Day summary screen
        bloodOxygenPage=new BloodOxygenPage(driver);
        bloodOxygenPage.checkIfUserLandsInBloodOxygenScreen(OSName);
        iTestListenerImplementation.test.log(Status.INFO, "Check to see if user lands in Blood Oxygen Day summary screen has been done");
        iTestListenerImplementation.test.log(Status.PASS,"BloodOxygen_TC001_BloodOxygenVerifyClickOnSpO2IconUnderMyHealthTest is pass on " + deviceName);
        //Check if Latest, Maximum and Minimum percentages are displayed above the graph
        bloodOxygenPage.checkIfMaxMinAndLatestBloodOxygenPercentagesAreDisplayed();
        iTestListenerImplementation.test.log(Status.INFO, "Check to see if Latest, Maximum and Minimum percentages are displayed above the graph has been done");
        iTestListenerImplementation.test.log(Status.PASS, "BloodOxygen_TC004_BloodOxygenVerifyIfMaxMinAndLatestSpO2PercentagesAreDisplayedTest is pass on " + deviceName);
        //Check if user is able to navigate to previous days
        bloodOxygenPage.clickOnPreviousBtn();
        iTestListenerImplementation.test.log(Status.INFO, "Check to see if user is able to navigate to previous days has been done");
        //Check if user has landed in the previous day page
        bloodOxygenPage.checkIfUserLandsInPreviousDay(OSName);
        iTestListenerImplementation.test.log(Status.INFO, "Check to see if user has landed in the previous day page has been done");
        //Click on previous btn again
        bloodOxygenPage.clickOnPreviousBtn();
        iTestListenerImplementation.test.log(Status.INFO, "Click on previous btn has been performed");
        iTestListenerImplementation.test.log(Status.PASS, "BloodOxygen_TC013_BloodOxygenVerifyIfUserCanNavigateToPreviousDaysTest is pass on " + deviceName);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc014_017_023_046_BloodOxygenUserCanNavigateToPreviousWeekAndWeekViewTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Oxygen Icon
        dashboardPage.clickOnBloodOxygenUnderMyHealth();
        //Check if user lands in Blood Oxygen Day summary screen
        bloodOxygenPage=new BloodOxygenPage(driver);
        bloodOxygenPage.checkIfUserLandsInBloodOxygenScreen(OS);
        //Click on week tab
        bloodOxygenPage.clickOnWeekTab();
        //Check if user has landed in week view
        javaUtility=new JavaUtility();
        System.out.println(javaUtility.getDatesFromMonToSunForPresentWeek());
        bloodOxygenPage.checkIfUserLandsInSelectedDateSleepPage(javaUtility.getDatesFromMonToSunForPresentWeek(), OS);
        Reporter.log("BloodOxygen_TC017_46_BloodOxygenWeekViewTest is pass on " + deviceName, true);
        //Check if Avg, Max and Min percentages of SpO2 is displayed
        bloodOxygenPage.checkIfMaxMinAndAvgBloodOxygenPercentagesAreDisplayed();
        Reporter.log("BloodOxygen_TC023_BloodOxygenAvgMaxMinPercentagesOfSpO2InWeekViewTest is pass on " + deviceName, true);
        //Check if user is able to navigate to previous weeks
        bloodOxygenPage.clickOnPreviousBtn();
        //Click on previous btn again
        bloodOxygenPage.clickOnPreviousBtn();
        Reporter.log("BloodOxygen_TC014_BloodOxygenVerifyIfUserCanNavigateToPreviousWeeksTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc015_027_036_047_BloodOxygenUserCanNavigateToPreviousMonthTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Oxygen Icon
        dashboardPage.clickOnBloodOxygenUnderMyHealth();
        //Check if user lands in Blood Oxygen Day summary screen
        bloodOxygenPage=new BloodOxygenPage(driver);
        bloodOxygenPage.checkIfUserLandsInBloodOxygenScreen(OS);
        //Click on month tab
        bloodOxygenPage.clickOnMonthTab();
        //Check if user has landed in month view
        javaUtility=new JavaUtility();
        bloodOxygenPage.checkIfUserLandsInSelectedDateSleepPage(javaUtility.fetchOnlyMonthInMonFormat(), OS);
        Reporter.log("BloodOxygen_TC027_047_BloodOxygenMonthViewTest is pass on " + deviceName, true);
        //Check if Avg, Max and Min percentages of SpO2 is displayed
        bloodOxygenPage.checkIfMaxMinAndAvgBloodOxygenPercentagesAreDisplayed();
        Reporter.log("BloodOxygen_TC036_BloodOxygenAvgMaxMinPercentagesOfSpO2InMonthViewTest is pass on " + deviceName, true);
        //Check if user is able to navigate to previous month
        bloodOxygenPage.clickOnPreviousBtn();
        Reporter.log("BloodOxygen_TC015_BloodOxygenVerifyIfUserCanNavigateToPreviousMonthTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc041_042_043_BloodOxygenCurrentDayWeekAndMonthTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Oxygen Icon
        dashboardPage.clickOnBloodOxygenUnderMyHealth();
        //Check if user lands in Blood Oxygen Day summary screen
        bloodOxygenPage=new BloodOxygenPage(driver);
        bloodOxygenPage.checkIfUserLandsInBloodOxygenScreen(OS);
        //Check if Today is displayed at the place of today's date
        bloodOxygenPage.checkIfUserLandsInSelectedDateSleepPage("Today", OS);
        Reporter.log("BloodOxygen_TC041_CheckDayAndDateNextToCalendarInDayViewTest is pass on " + deviceName, true);
        //Click on Week tab
        bloodOxygenPage.clickOnWeekTab();
        //Check if user has landed in Week view
        javaUtility=new JavaUtility();
        bloodOxygenPage.checkIfUserLandsInSelectedDateSleepPage(javaUtility.getDatesFromMonToSunForPresentWeek(), OS);
        Reporter.log("BloodOxygen_TC042_CheckWeekNextToCalendarInWeekViewTest is pass on " + deviceName, true);
        //Click on month tab
        bloodOxygenPage.clickOnMonthTab();
        //Check if user has landed in month view
        javaUtility=new JavaUtility();
        bloodOxygenPage.checkIfUserLandsInSelectedDateSleepPage(javaUtility.fetchOnlyMonthInMonFormat(), OS);
        Reporter.log("BloodOxygen_TC043_CheckMonthNameNextToCalendarInMonthViewTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc044_045_BloodOxygenBackCarouselFromCalendarAndSelectAnyDayInCalendarDayViewTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Oxygen Icon
        dashboardPage.clickOnBloodOxygenUnderMyHealth();
        //Check if user lands in Blood Oxygen summary screen
        bloodOxygenPage=new BloodOxygenPage(driver);
        bloodOxygenPage.checkIfUserLandsInBloodOxygenScreen(OS);
        //Click on Calendar icon
        bloodOxygenPage.clickOnCalendarIcon();
        //Click on back btn
        calendarPage=new CalendarPage(driver);
        calendarPage.clickOnBackBtn();
        //Check if user lands in Blood Oxygen summary screen
        bloodOxygenPage.checkIfUserLandsInBloodOxygenScreen(OS);
        Reporter.log("BloodOxygen_TC044_BackCarouselFromCalendarInDayViewTest is pass on " + deviceName, true);
        //Click on Calendar icon
        bloodOxygenPage.clickOnCalendarIcon();
        //Select 5th January 2023
        calendarPage.clickOnYear2023MonthJanuaryAndDate5AndOkBtn();
        //Check if user has landed In 5th January SpO2 screen
        bloodOxygenPage.checkIfUserLandsInSelectedDateSleepPage("18 Feb", OS);
        Reporter.log("BloodOxygen_TC045_SelectAnyDayInCalendarInDayViewTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc048_050_BloodOxygenShiftBetweenDayWeekAndMonthSummariesAndBloodOxygenTileViewTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Oxygen Icon
        dashboardPage.clickOnBloodOxygenUnderMyHealth();
        //Check if user lands in Day summary screen
        bloodOxygenPage=new BloodOxygenPage(driver);
        bloodOxygenPage.checkIfUserLandsInSelectedDateSleepPage("Today", OS);
        //Check if Blood Oxygen tile is displayed in Day Summary view
        bloodOxygenPage.checkIfBloodOxygenTileIsDisplayed();
        //Click on week tab
        bloodOxygenPage.clickOnWeekTab();
        //Check if user lands in week summary screen
        javaUtility=new JavaUtility();
        bloodOxygenPage.checkIfUserLandsInSelectedDateSleepPage(javaUtility.getDatesFromMonToSunForPresentWeek(), OS);
        //Check if Blood Oxygen tile is displayed in Week Summary view
        bloodOxygenPage.checkIfBloodOxygenTileIsDisplayed();
        //Click on week tab
        bloodOxygenPage.clickOnMonthTab();
        //Check if user lands in Month summary screen
        bloodOxygenPage.checkIfUserLandsInSelectedDateSleepPage(javaUtility.fetchOnlyMonthInMonFormat(), OS);
        //Check if Blood Oxygen tile is displayed in Month Summary view
        bloodOxygenPage.checkIfBloodOxygenTileIsDisplayed();
        Reporter.log("BloodOxygen_TC048_BloodOxygenShiftBetweenDayWeekAndMonthSummariesTest is pass on " + deviceName, true);
        Reporter.log("BloodOxygen_TC050_BloodOxygenTileBelowGraphInDayWeekAndMonthSummariesTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName", "os"})
    @Test
    public void tc051_BloodOxygenNoInternetTest(String deviceName, String OS) {
        //turn off Wi-Fi
        notificationAndControlCentre = new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleWiFi(driver, OS);
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Oxygen Icon
        dashboardPage.clickOnBloodOxygenUnderMyHealth();
        //Check if user lands in Day summary screen
        bloodOxygenPage=new BloodOxygenPage(driver);
        bloodOxygenPage.checkIfUserLandsInSelectedDateSleepPage("Today", OS);
        Reporter.log("BloodOxygen_TC051_BloodOxygenNoInternetTest is pass on " + deviceName, true);
        //turn on wifi
        notificationAndControlCentre.toggleWiFi(driver, OS);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc052_BloodOxygenKillAppAndReopenTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Oxygen Icon
        dashboardPage.clickOnBloodOxygenUnderMyHealth();
        //Check if user lands in Blood Oxygen summary screen
        bloodOxygenPage=new BloodOxygenPage(driver);
        bloodOxygenPage.checkIfUserLandsInBloodOxygenScreen(OS);
        //Close the app
        try {
            ((InteractsWithApps) driver).terminateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
        } catch (Exception e){
            e.printStackTrace();
        }
        //launch the app
        ((InteractsWithApps)driver).activateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
        //Check if user lands in Dashboard
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("BloodOxygen_TC052_BloodOxygenKillAppAndReopenTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc053_BloodOxygenBackArrowTest(String deviceName, String OS) {
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Oxygen Icon
        dashboardPage.clickOnBloodOxygenUnderMyHealth();
        //Check if user lands in Blood Oxygen summary screen
        bloodOxygenPage=new BloodOxygenPage(driver);
        bloodOxygenPage.checkIfUserLandsInBloodOxygenScreen(OS);
        //Click on back btn
        bloodOxygenPage.clickOnBackBtn();
        //Check if user lands in Dashboard
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("BloodOxygen_TC053_BloodOxygenBackArrowTest is pass on " + deviceName, true);
    }

    @Parameters({"deviceName","os"})
    @Test
    public void tc055_BloodOxygenSummaryBandNotConnectedTest(String deviceName, String OS) {
        //Disconnect the watch
        dashboardPage = new DashboardPage(driver);
        dashboardPage.unpairWatch(driver);
        //Swipe down to My Health section
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Oxygen Icon
        dashboardPage.clickOnBloodOxygenUnderMyHealth();
        //Check if user lands in Day summary screen
        bloodOxygenPage=new BloodOxygenPage(driver);
        bloodOxygenPage.checkIfUserLandsInSelectedDateSleepPage("Today", OS);
        Reporter.log("BloodOxygen_TC055_BloodOxygenSummaryBandNotConnectedTest is pass on " + deviceName, true);
        //pair the watch
        bloodOxygenPage.clickOnBackBtn();
        dashboardPage.pairWatch();
    }

    @Parameters({"deviceName", "os"})
    @Test
    public void tc056_BloodOxygenSummaryBTOffTest(String deviceName, String OS) {
        //Turn Off Bluetooth
        notificationAndControlCentre = new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleBluetooth(driver, OS);
        //Close the bluetooth is off popup
        bluetoothIsOffPopUp=new BluetoothIsOffPopUp(driver);
        bluetoothIsOffPopUp.clickOnClosePopUpBtn();
        //Swipe down to My Health section
        dashboardPage = new DashboardPage(driver);
        dashboardPage.swipeToMyHealthSection(driver, OS);
        //Click on Blood Oxygen Icon
        dashboardPage.clickOnBloodOxygenUnderMyHealth();
        //Check if user lands in Blood Oxygen summary screen
        bloodOxygenPage=new BloodOxygenPage(driver);
        bloodOxygenPage.checkIfUserLandsInBloodOxygenScreen(OS);
        //Turn on bluetooth
        notificationAndControlCentre.toggleBluetooth(driver, OS);
        Reporter.log("BloodOxygen_TC056_BloodOxygenSummaryBTOffTest is pass on " + deviceName, true);
    }
}