package tests;

import genericutility.BaseClass;
import genericutility.JSONUtility;
import io.appium.java_client.InteractsWithApps;
import objectrepository.DashboardPage;
import objectrepository.MyFitnessPage;
import objectrepository.NotificationAndControlCentre;
import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

@Listeners(genericutility.iTestListenerImplementation.class)
public class MyFitnessModuleTest extends BaseClass {
    DashboardPage dashboardPage;
    MyFitnessPage myFitnessPage;
    NotificationAndControlCentre notificationAndControlCentre;

    @Test
    public void tc001_002_004_MyFitnessDailySummaryTest(){
        //Click on Steps Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnStepsSummaryIcon();
        //Check if Step, Distance and Calories are displayed
        myFitnessPage=new MyFitnessPage(driver);
        myFitnessPage.checkIfStepsDistAndCaloriesAreDisplayed();
        Reporter.log("MyFitness_TC001_MyFitnessDailySummaryTest is pass", true);
        //Check if Attention message is displayed below the graph
        myFitnessPage.checkIfAttentionMessageIsDisplayed(driver);
        Reporter.log("MyFitness_TC002_MyFitnessStepsDayViewTest is pass", true);
        Reporter.log("MyFitness_TC004_MyFitnessStepsDistanceCaloriesDayViewTest is pass", true);
    }

    @Test
    public void tc005_MyFitnessStepsWeekViewTest(){
        //Click on Steps Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnStepsSummaryIcon();
        //Click on Week tab
        myFitnessPage=new MyFitnessPage(driver);
        myFitnessPage.clickOnWeekTab();
        //Check if Step, Distance and Calories are displayed
        myFitnessPage.checkIfStepsDistAndCaloriesAreDisplayed();
        //Check if Attention message is displayed below the graph
        myFitnessPage.checkIfAttentionMessageIsDisplayed(driver);
        Reporter.log("MyFitness_TC005_MyFitnessStepsWeekViewTest is pass", true);
    }

    @Test
    public void tc006_MyFitnessStepsMonthViewTest(){
        //Click on Steps Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnStepsSummaryIcon();
        //Click on Month tab
        myFitnessPage=new MyFitnessPage(driver);
        myFitnessPage.clickOnMonthTab();
        //Check if Step, Distance and Calories are displayed
        myFitnessPage.checkIfStepsDistAndCaloriesAreDisplayed();
        //Check if Attention message is displayed below the graph
        myFitnessPage.checkIfAttentionMessageIsDisplayed(driver);
        Reporter.log("MyFitness_TC006_MyFitnessStepsMonthViewTest is pass", true);
    }

    @Parameters("os")
    @Test
    public void tc015_MyFitnessDailyViewPreviousViewTest(String OS){
        //Click on Steps Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnStepsSummaryIcon();
        //Check if Step, Distance and Calories are displayed
        myFitnessPage=new MyFitnessPage(driver);
        myFitnessPage.checkIfStepsDistAndCaloriesAreDisplayed();
        //Click on previous day till user reaches registration date
        myFitnessPage.clickOnPreviousDayTillRegistrationDate(OS);
        Reporter.log("MyFitness_TC015_MyFitnessDailyViewPreviousViewTest is pass", true);
    }

    @Test
    public void tc017_MyFitnessWeeklyViewCurrentAndPreviousViewTest(){
        //Click on Steps Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnStepsSummaryIcon();
        //Click on Week tab
        myFitnessPage=new MyFitnessPage(driver);
        myFitnessPage.clickOnWeekTab();
        //Check if Step, Distance and Calories are displayed
        myFitnessPage.checkIfStepsDistAndCaloriesAreDisplayed();
        //Click on previous week button
        myFitnessPage.clickOnPreviousBtn();
        Reporter.log("MyFitness_TC017_MyFitnessWeeklyViewCurrentAndPreviousViewTest is pass", true);
    }

    @Test
    public void tc019_033_MyFitnessMonthlyViewCurrentAndPreviousViewTest(){
        //Click on Steps Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnStepsSummaryIcon();
        //Click on Week tab
        myFitnessPage=new MyFitnessPage(driver);
        myFitnessPage.clickOnMonthTab();
        //Check if Step, Distance and Calories are displayed
        myFitnessPage.checkIfStepsDistAndCaloriesAreDisplayed();
        //Click on previous month button
        myFitnessPage.clickOnPreviousBtn();
        Reporter.log("MyFitness_TC019_MyFitnessMonthlyViewCurrentAndPreviousViewTest is pass", true);
        Reporter.log("MyFitness_TC033_MyFitnessDayWeekMonthViewCurrentAndPreviousViewTest is pass", true);
    }

    @Parameters("os")
    @Test
    public void tc021_MyFitnessFitnessSummaryWhenNoInternetTest(String OS){
        //turn off WiFi
        notificationAndControlCentre=new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleWiFi(driver, OS);
        //Click on Steps Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnStepsSummaryIcon();
        //Check if Step, Distance and Calories are displayed
        myFitnessPage=new MyFitnessPage(driver);
        myFitnessPage.checkIfStepsDistAndCaloriesAreDisplayed();
        //Click on Week tab
        myFitnessPage.clickOnWeekTab();
        //Check if Step, Distance and Calories are displayed
        myFitnessPage.checkIfStepsDistAndCaloriesAreDisplayed();
        //Click on Month tab
        myFitnessPage.clickOnMonthTab();
        //Check if Step, Distance and Calories are displayed
        myFitnessPage.checkIfStepsDistAndCaloriesAreDisplayed();
        Reporter.log("MyFitness_TC021_MyFitnessFitnessSummaryWhenNoInternetTest is pass", true);
        //Turn on Wi-Fi
        notificationAndControlCentre.toggleWiFi(driver, OS);
    }

    @Parameters("os")
    @Test
    public void tc022_MyFitnessFitnessSummaryWhenBTOffTest(String OS){
        //Turn Off Bluetooth
        notificationAndControlCentre = new NotificationAndControlCentre(driver);
        notificationAndControlCentre.toggleBluetooth(driver, OS);
        //Click on Steps Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnStepsSummaryIcon();
        //Check if Step, Distance and Calories are displayed
        myFitnessPage=new MyFitnessPage(driver);
        myFitnessPage.checkIfStepsDistAndCaloriesAreDisplayed();
        //Click on Week tab
        myFitnessPage.clickOnWeekTab();
        //Check if Step, Distance and Calories are displayed
        myFitnessPage.checkIfStepsDistAndCaloriesAreDisplayed();
        //Click on Month tab
        myFitnessPage.clickOnMonthTab();
        //Check if Step, Distance and Calories are displayed
        myFitnessPage.checkIfStepsDistAndCaloriesAreDisplayed();
        Reporter.log("MyFitness_TC022_MyFitnessFitnessSummaryWhenBTOffTest is pass", true);
        //Turn on bluetooth
        notificationAndControlCentre.toggleBluetooth(driver, OS);
    }

    @Parameters("deviceName")
    @Test
    public void tc027_MyFitnessKillAppAndReopenTest(String deviceName){
        //Click on Steps Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnStepsSummaryIcon();
        //Check if Step, Distance and Calories are displayed
        myFitnessPage=new MyFitnessPage(driver);
        myFitnessPage.checkIfStepsDistAndCaloriesAreDisplayed();
        //Relaunch the app
        ((InteractsWithApps)driver).terminateApp((String) JSONUtility.fetchDataFromJson(deviceName,"AppPackage"));
        ((InteractsWithApps)driver).activateApp((String) JSONUtility.fetchDataFromJson(deviceName,"AppPackage"));
        //Check if user lands in Dashboard page
        dashboardPage.checkIfUserLandsInDashboard();
        Reporter.log("MyFitness_TC027_MyFitnessKillAppAndReopenTest is pass", true);
    }

    @Test
    public void tc028_MyFitnessFitnessSummaryWhenWatchDisconnectedTest(){
        //Unpair the watch
        dashboardPage=new DashboardPage(driver);
        dashboardPage.unpairWatch(driver);
        //Click on Steps Summary Icon
        dashboardPage=new DashboardPage(driver);
        dashboardPage.clickOnStepsSummaryIcon();
        //Check if Step, Distance and Calories are displayed
        myFitnessPage=new MyFitnessPage(driver);
        myFitnessPage.checkIfStepsDistAndCaloriesAreDisplayed();
        //Click on Week tab
        myFitnessPage.clickOnWeekTab();
        //Check if Step, Distance and Calories are displayed
        myFitnessPage.checkIfStepsDistAndCaloriesAreDisplayed();
        //Click on Month tab
        myFitnessPage.clickOnMonthTab();
        //Check if Step, Distance and Calories are displayed
        myFitnessPage.checkIfStepsDistAndCaloriesAreDisplayed();
        Reporter.log("MyFitness_TC028_MyFitnessFitnessSummaryWhenWatchDisconnectedTest is pass", true);
        //Pair the watch
        myFitnessPage.clickOnBackBtn();
        dashboardPage.pairWatch();
    }
}