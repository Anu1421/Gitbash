package objectrepository;

import genericutility.AndroidWebDriverUtility;
import genericutility.WebDriverUtility;
import genericutility.IOSWebDriverUtility;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class AboutPage {
    WebDriverUtility webDriverUtility;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='ic_back_Img']/preceding-sibling::XCUIElementTypeButton")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label CONTAINS 'App Version :'")
    @FindBy(xpath = "//android.widget.TextView[@text='App Version :']/following-sibling::android.widget.TextView") private WebElement appVersion;

    @iOSXCUITFindBy(iOSNsPredicate = "label CONTAINS 'Firmware Version:'")
    @FindBy(xpath = "//android.widget.TextView[@text='Firmware Version :']/following-sibling::android.widget.TextView") private WebElement firmwareVersion;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Privacy Policy'")
    @FindBy(xpath = "//android.widget.TextView[@text='Privacy Policy']") private WebElement privacyPolicyOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'User Manual'")
    @FindBy(xpath = "//android.widget.TextView[@text='User Manual']") private WebElement userManualOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'About the Products'")
    @FindBy(xpath = "//android.widget.TextView[@text='About the Products']") private WebElement aboutTheProductsOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'About the Company'")
    @FindBy(xpath = "//android.widget.TextView[@text='About the Company']") private WebElement aboutTheCompanyOption;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Wearable Privacy Policy'")
    @FindAll({
            @FindBy(xpath = "//android.widget.TextView[@text='PRIVACY POLICY']"),
            @FindBy(xpath = "//android.widget.TextView[@text='Wearable Privacy Policy']")
    }) private WebElement titanPrivacyPolicyPage;

    @iOSXCUITFindBy(iOSNsPredicate = "value CONTAINS 'USER MANUAL'")
    @FindBy(xpath = "//android.widget.TextView[@text='USER MANUAL']") private WebElement userManualPage;

    @FindAll({
            @FindBy(xpath = "//android.widget.TextView[@text='FASTRACK SMART WEARABLES']"),
            @FindBy(xpath = "//android.widget.TextView[@text='LOGIN']")
    }) private WebElement aboutTheProductsPage;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'About the Products'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title"),
            @FindBy(id = "com.titan.smartworld:id/title")
    }) private WebElement aboutPageTitle;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == 'Our Brands'`][2]")
    @FindBy(xpath = "//android.widget.TextView[@text='Our Brands']") private WebElement aboutTheCompanyPage;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='ic_back_Img']/preceding-sibling::XCUIElementTypeStaticText") private WebElement pageTitles;

    public AboutPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getAppVersion() {
        return appVersion;
    }

    public WebElement getFirmwareVersion() {
        return firmwareVersion;
    }

    public WebElement getPrivacyPolicyOption() {
        return privacyPolicyOption;
    }

    public WebElement getUserManualOption() {
        return userManualOption;
    }

    public WebElement getAboutTheProductsOption() {
        return aboutTheProductsOption;
    }

    public WebElement getAboutTheCompanyOption() {
        return aboutTheCompanyOption;
    }

    public WebElement getTitanPrivacyPolicyPage() {
        return titanPrivacyPolicyPage;
    }

    public WebElement getUserManualPage() {
        return userManualPage;
    }

    public WebElement getAboutTheProductsPage() {
        return aboutTheProductsPage;
    }

    public WebElement getAboutPageTitle() {
        return aboutPageTitle;
    }

    public WebElement getAboutTheCompanyPage() {
        return aboutTheCompanyPage;
    }

    public WebElement getPageTitles() {
        return pageTitles;
    }

    public String getAppVersionFromappVersion(){
        return appVersion.getText();
    }

    public String getFirmwareVersionFromfirmwareVersion(){
        return firmwareVersion.getText();
    }

    public void clickOnPrivacyPolicyLink(){
        privacyPolicyOption.click();
    }
    public void clickOnUserManualOption(){
        userManualOption.click();
    }
    public void clickOnAboutTheProductsOption(){
        aboutTheProductsOption.click();
    }
    public void clickOnAboutTheCompanyOption(){
        aboutTheCompanyOption.click();
    }

    public void checkIfAllComponentsArePresent(){
        Assert.assertTrue(appVersion.isDisplayed());
        Assert.assertTrue(firmwareVersion.isDisplayed());
        Assert.assertTrue(privacyPolicyOption.isDisplayed());
        Assert.assertTrue(userManualOption.isDisplayed());
        Assert.assertTrue(aboutTheProductsOption.isDisplayed());
        Assert.assertTrue(aboutTheCompanyOption.isDisplayed());
    }

    public void checkIfPrivacyPolicyPageIsDisplayed(WebDriver driver){
        Assert.assertTrue(privacyPolicyOption.isDisplayed());
        privacyPolicyOption.click();
        WebDriverUtility.waitForElementToBeVisible(driver, titanPrivacyPolicyPage, 10);
        Assert.assertTrue(titanPrivacyPolicyPage.isDisplayed());
    }

    public void checkIfUserManualPageIsDisplayed(WebDriver driver){
        Assert.assertTrue(userManualOption.isDisplayed());
        userManualOption.click();
        WebDriverUtility.waitForElementToBeVisible(driver, userManualPage, 20);
        Assert.assertTrue(userManualPage.isDisplayed());
    }

    public void checkIfAboutTheProductsIsDisplayed(WebDriver driver){
        Assert.assertTrue(aboutTheProductsOption.isDisplayed());
        aboutTheProductsOption.click();
        WebDriverUtility.waitForElementToBeVisible(driver, aboutPageTitle, 20);
        Assert.assertEquals(aboutPageTitle.getText(),"About the Products");
    }

    public void checkIfAboutTheCompanyIsDisplayed(WebDriver driver){
        Assert.assertTrue(aboutTheCompanyOption.isDisplayed());
        aboutTheCompanyOption.click();
        WebDriverUtility.waitForElementToBeVisible(driver, aboutTheCompanyPage, 20);
        Assert.assertTrue(aboutTheCompanyPage.isDisplayed());
    }

    public void clickOnBackBtn(WebDriver driver){
        WebDriverUtility.waitForPageToLoad(driver, 20);
        backBtn.click();
    }
}