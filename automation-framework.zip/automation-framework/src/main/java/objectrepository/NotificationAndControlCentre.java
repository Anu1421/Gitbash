package objectrepository;

import genericutility.BaseClass;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NotificationAndControlCentre {
    @iOSXCUITFindBy(iOSNsPredicate = "label BEGINSWITH 'Bluetooth'")
    @FindBy(xpath = "//android.widget.LinearLayout[@content-desc='Vibrate On.']/following-sibling::android.widget.LinearLayout[1]") private WebElement toggleBTBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label BEGINSWITH 'Wi-Fi'")
    @FindAll({
            @FindBy(xpath = "//android.widget.LinearLayout[@content-desc='Vibrate On.']/preceding-sibling::android.widget.LinearLayout[1]"),
            @FindBy(xpath="//android.view.ViewGroup[contains(@content-desc, \"Wi-Fi\")]")
    }) private WebElement toggleWiFiBtn;
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Airplane Mode'")
    @FindBy(xpath = "//android.widget.LinearLayout[@content-desc='Vibrate On.']/following-sibling::android.widget.LinearLayout[3]") private WebElement toggleAeroplaneModeBtn;

    public NotificationAndControlCentre(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getToggleBTBtn() {
        return toggleBTBtn;
    }

    public WebElement getToggleWiFiBtn() {
        return toggleWiFiBtn;
    }

    public WebElement getToggleAeroplaneModeBtn() {
        return toggleAeroplaneModeBtn;
    }

    public void toggleBluetooth(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")) {
            //Show Notifications
            ((AndroidDriver) driver).openNotifications();
            //Turn off/on BT
            toggleBTBtn.click();
            //Hide Notifications
            ((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.BACK));
        } else if (OS.equalsIgnoreCase("IOS")) {
            //Show control center
            BaseClass.swipeDownToRevealControlCenter(driver);
            //Turn off/on BT
            toggleBTBtn.click();
            //Hide control center
            BaseClass.swipeUpToHomeScreen(driver);
        }
    }

    public void toggleFlightMode(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")) {
            //Show Notifications
            ((AndroidDriver) driver).openNotifications();
            //Turn off/on Flight Mode
            toggleAeroplaneModeBtn.click();
            //Hide Notifications
            ((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.BACK));
        } else if (OS.equalsIgnoreCase("IOS")) {
            //Show control center
            BaseClass.swipeDownToRevealControlCenter(driver);
            //Turn off/on Flight Mode
            toggleAeroplaneModeBtn.click();
            //Hide control center
            BaseClass.swipeUpToHomeScreen(driver);
        }
    }

    public void toggleWiFi(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")) {
            //Show Notifications
            ((AndroidDriver) driver).openNotifications();
            //Turn off/on Wi-Fi
            toggleWiFiBtn.click();
            //Hide Notifications
            ((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.BACK));
        } else if (OS.equalsIgnoreCase("IOS")) {
            //Show control center
            BaseClass.swipeDownToRevealControlCenter(driver);
            //Turn off/on Wi-Fi
            toggleWiFiBtn.click();
            //Hide control center
            BaseClass.swipeUpToHomeScreen(driver);
        }
    }

    public void checkIfWifiIsOff(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            ((AndroidDriver)driver).openNotifications();
            if (toggleWiFiBtn.getAttribute("content-desc").contains("Off")) {
                toggleWiFiBtn.click();
            }
            ((AndroidDriver)driver).pressKey(new KeyEvent(AndroidKey.BACK));

        }
        else if (OS.equalsIgnoreCase("IOS")) {
            BaseClass.swipeDownToRevealControlCenter(driver);
            if (toggleWiFiBtn.getAttribute("label").contains("Not Connected")){
                toggleWiFiBtn.click();
            } else if (toggleWiFiBtn.getAttribute("label").equals("Wi-Fi")) {
                toggleWiFiBtn.click();
            }
            BaseClass.swipeUpToHomeScreen(driver);
        }
    }
}