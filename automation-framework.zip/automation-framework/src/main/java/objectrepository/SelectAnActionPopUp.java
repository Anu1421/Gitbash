package objectrepository;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SelectAnActionPopUp {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic close'") private WebElement closeBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Select An Action'") private WebElement popUpTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Pick Image'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/pick_image"),
            @FindBy(id = "com.titan.smartworld:id/pick_image")
    }) private WebElement pickImageOption;

    @iOSXCUITFindBy(iOSNsPredicate = "value =='Launch Camera'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/launch_camera"),
            @FindBy(id = "com.titan.smartworld:id/launch_camera")
    }) private WebElement launchCameraOption;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Remove Image'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/delete_image"),
            @FindBy(id = "com.titan.smartworld:id/delete_image")
    }) private WebElement removeImageOption;

    public SelectAnActionPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getCloseBtn() {
        return closeBtn;
    }

    public WebElement getPopUpTitle() {
        return popUpTitle;
    }

    public WebElement getPickImageOption() {
        return pickImageOption;
    }

    public WebElement getLaunchCameraOption() {
        return launchCameraOption;
    }

    public WebElement getRemoveImageOption() {
        return removeImageOption;
    }

    public void clickOnPickImageOption(){
        pickImageOption.click();
    }

    public void clickOnLaunchCameraOption(){
        launchCameraOption.click();
    }

    public void clickOnRemoveImageOption(){
        removeImageOption.click();
    }
}