package objectrepository;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AlarmPopUp {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic close'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
            }) private WebElement closePopUpBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Alarm 1']/following-sibling::XCUIElementTypeOther") private WebElement alarm1Toggle;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Alarm 2']/following-sibling::XCUIElementTypeOther") private WebElement alarm2Toggle;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Alarm 3']/following-sibling::XCUIElementTypeOther") private WebElement alarm3Toggle;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'New Alarm'") private WebElement newAlarmBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic close']/following-sibling::XCUIElementTypeButton") private WebElement bottomText;

    public AlarmPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getAlarm1Toggle() {
        return alarm1Toggle;
    }

    public WebElement getAlarm2Toggle() {
        return alarm2Toggle;
    }

    public WebElement getAlarm3Toggle() {
        return alarm3Toggle;
    }

    public WebElement getNewAlarmBtn() {
        return newAlarmBtn;
    }

    public WebElement getBottomText() {
        return bottomText;
    }
}