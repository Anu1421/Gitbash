package objectrepository;

import io.appium.java_client.pagefactory.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ReportErrorPopUp {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic close'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closePopUpBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic close']/preceding-sibling::XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title_view"),
            @FindBy(id = "com.titan.smartworld:id/title_view")
    }) private WebElement popUpTitle;

    @iOSXCUITFindAll({
            @iOSXCUITBy(iOSNsPredicate = "value == 'Enter details'"),
            @iOSXCUITBy(xpath = "//XCUIElementTypeButton[@name='ic close']/following-sibling::XCUIElementTypeTextView")
    })
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/message_view"),
            @FindBy(id = "com.titan.smartworld:id/message_view")
    }) private WebElement errorMessageTxtEdit;

    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextView'") private WebElement enterErrorMessageTxtEdit;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'return'") private WebElement returnBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Send'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/save_button"),
            @FindBy(id = "com.titan.smartworld:id/save_button")
    }) private WebElement sendReportBtn;

    public ReportErrorPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getErrorMessageTxtEdit() {
        return errorMessageTxtEdit;
    }

    public WebElement getEnterErrorMessageTxtEdit() {
        return enterErrorMessageTxtEdit;
    }

    public WebElement getReturnBtn() {
        return returnBtn;
    }

    public WebElement getSendReportBtn() {
        return sendReportBtn;
    }

    public WebElement getPopUpTitle() {
        return popUpTitle;
    }

    public void sendErrorReport(String OS, String errorDetails){
        if (OS.equalsIgnoreCase("Android")) {
            errorMessageTxtEdit.sendKeys(errorDetails);
            sendReportBtn.click();
        } else if (OS.equalsIgnoreCase("IOS")) {
            errorMessageTxtEdit.click();
            enterErrorMessageTxtEdit.sendKeys(errorDetails);
            returnBtn.click();
            sendReportBtn.click();
        }
    }
}