package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class SedentaryAlertPopUp {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic close'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closePopUpBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value BEGINSWITH 'Start: '")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/start_hour"),
            @FindBy(id = "com.titan.smartworld:id/start_hour")
    }) private WebElement startHourSelection;

    @iOSXCUITFindBy(iOSNsPredicate = "value BEGINSWITH 'End: '")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/end_hour"),
            @FindBy(id = "com.titan.smartworld:id/end_hour")
    }) private WebElement endHourSelection;

    @iOSXCUITFindBy(iOSNsPredicate = "label ENDSWITH 'Minutes'")
    @FindBy(id = "com.titan.fastrack.reflex:id/frequency") private WebElement intervalDuration;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeSlider")
    @FindBy(id = "com.titan.fastrack.reflex:id/seek_bar") private WebElement intervalSlider;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Turn Off'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/turn_off_button"),
            @FindBy(id = "com.titan.smartworld:id/turn_off_button")
    }) private WebElement turnOffSedentaryAlertBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Update'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/update_button"),
            @FindBy(id = "com.titan.smartworld:id/update_button")
    }) private WebElement updateSedentaryAlertBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Turn On'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/okay_button"),
            @FindBy(id = "com.titan.smartworld:id/okay_button")
    }) private WebElement turnOnSedentaryAlertBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value BEGINSWITH 'Turn O'")
    @FindBy(xpath = "//android.widget.Button[1]") private WebElement turnOnOrTurnOffBtn;

    public SedentaryAlertPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getStartHourSelection() {
        return startHourSelection;
    }

    public WebElement getEndHourSelection() {
        return endHourSelection;
    }

    public WebElement getIntervalDuration() {
        return intervalDuration;
    }

    public WebElement getIntervalSlider() {
        return intervalSlider;
    }

    public WebElement getTurnOffSedentaryAlertBtn() {
        return turnOffSedentaryAlertBtn;
    }

    public WebElement getUpdateSedentaryAlertBtn() {
        return updateSedentaryAlertBtn;
    }

    public WebElement getTurnOnSedentaryAlertBtn() {
        return turnOnSedentaryAlertBtn;
    }

    public WebElement getTurnOnOrTurnOffBtn() {
        return turnOnOrTurnOffBtn;
    }

    public void clickOnTurnOffSedentaryAlert(){
        turnOffSedentaryAlertBtn.click();
    }

    public void checkIfSedentaryAlertIsTurnedOff(String OS){
        String btnStatus= null;
        if (OS.equalsIgnoreCase("Android")){
            btnStatus = turnOnOrTurnOffBtn.getText();
        } else if (OS.equalsIgnoreCase("IOS")){
            btnStatus = turnOnOrTurnOffBtn.getAttribute("name");
        }
        Assert.assertTrue(btnStatus.equals("Turn On"));
    }

    public void checkIfSedentaryAlertIsTurnedOn(){
        Assert.assertTrue(turnOnOrTurnOffBtn.getText().equals("Turn Off"));
    }

    public void turnOnSedentaryAlert(WebDriver driver, String OS){
        String buttonStatus = null;
        if (OS.equalsIgnoreCase("Android")){
            buttonStatus=turnOnOrTurnOffBtn.getText();
        } else if (OS.equalsIgnoreCase("IOS")) {
            buttonStatus=turnOnOrTurnOffBtn.getAttribute("name");
        }
        if (buttonStatus.equals("Turn On")){
            turnOnOrTurnOffBtn.click();
            SettingsPage settingsPage = new SettingsPage(driver);
            settingsPage.checkConfirmationToastMessageForChanges();
        }
        else {
            closePopUpBtn.click();
        }
    }

    public void turnOffSedentaryAlert(WebDriver driver, String OS){
        String buttonStatus = null;
        if (OS.equalsIgnoreCase("Android")){
            buttonStatus=turnOnOrTurnOffBtn.getText();
        } else if (OS.equalsIgnoreCase("IOS")) {
            buttonStatus=turnOnOrTurnOffBtn.getAttribute("name");
        }
        if (buttonStatus.equals("Turn Off")){
            turnOnOrTurnOffBtn.click();
            SettingsPage settingsPage = new SettingsPage(driver);
            settingsPage.checkConfirmationToastMessageForChanges();
        }
        else {
            closePopUpBtn.click();
        }
    }

    public String  moveTheSedentaryAlertIntervalSliderToSpecifiedDuration(String OS, String intervalDuration){
        if (OS.equalsIgnoreCase("Android")){
            intervalSlider.sendKeys(intervalDuration);
        } else if (OS.equalsIgnoreCase("IOS")) {
            if (intervalDuration.equalsIgnoreCase("30")){
                intervalSlider.sendKeys("0.2");
            } else if (intervalDuration.equalsIgnoreCase("60")) {
                intervalSlider.sendKeys("0.4");
            } else if (intervalDuration.equalsIgnoreCase("120")) {
                intervalSlider.sendKeys("0.8");
            } else if (intervalDuration.equalsIgnoreCase("180")) {
                intervalSlider.sendKeys("1");
            }
        }
        return intervalDuration;
    }

    public void checkIfProperIntervalDurationIsShownWhenSliderIsMovedToSpecificDuration(String OS, String sedentaryInterval){
        if (OS.equalsIgnoreCase("Android")){
            Assert.assertEquals(intervalDuration.getText(), "Every: "+sedentaryInterval+" Minutes");
        } else if (OS.equalsIgnoreCase("IOS")) {
            Assert.assertEquals(intervalDuration.getAttribute("name"), "Every: "+sedentaryInterval+" Minutes");
        }
    }
}