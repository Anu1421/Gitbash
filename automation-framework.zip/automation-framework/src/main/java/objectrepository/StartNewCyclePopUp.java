package objectrepository;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class StartNewCyclePopUp {

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Start New Cycle'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title_view"),
            @FindBy(id = "com.titan.smartworld:id/title_view")
    }) private WebElement popUpTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'close'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closePopUpBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Confirming that on clicking start it will start a new cycle'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/message_view"),
            @FindBy(id = "com.titan.smartworld:id/message_view")
    }) private WebElement popUpMessage;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Start'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/okay_button"),
            @FindBy(id = "com.titan.smartworld:id/okay_button")
    }) private WebElement startBtn;

    public StartNewCyclePopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getPopUpTitle() {
        return popUpTitle;
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getPopUpMessage() {
        return popUpMessage;
    }

    public WebElement getStartBtn() {
        return startBtn;
    }

    public void checkIfUserLandsInStartNewCyclePopUp(){
        Assert.assertTrue(popUpTitle.getText().equals("Start New Cycle"));
    }

    public void clickOnStartBtn(){
        startBtn.click();
    }
}