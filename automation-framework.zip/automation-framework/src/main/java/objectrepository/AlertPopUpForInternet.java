package objectrepository;

import genericutility.AndroidWebDriverUtility;
import genericutility.WebDriverUtility;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class AlertPopUpForInternet {

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'close'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closePopUpBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Looks like your phone is offline.Check the network connection and try again'")
    @FindBy(xpath = "//android.widget.TextView[@text='Looks like your phone is offline. Check the network connection and try again']")
    private WebElement alertMessage;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Ok'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/okay_button"),
            @FindBy(id = "com.titan.smartworld:id/okay_button")
    }) private WebElement okBtn;

    public AlertPopUpForInternet(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getAlertMessage() {
        return alertMessage;
    }

    public WebElement getOkBtn() {
        return okBtn;
    }

    public void checkAlertMessage(WebDriver driver, String OS){
//        WebDriverUtility.waitForElementToBeVisible(driver, alertMessage, 10);
        if (OS.equalsIgnoreCase("Android")) {
            Assert.assertEquals(alertMessage.getText(), "Looks like your phone is offline. Check the network connection and try again");
        } else if (OS.equalsIgnoreCase("IOS")) {
            Assert.assertEquals(alertMessage.getAttribute("name"), "Looks like your phone is offline.Check the network connection and try again");
        }
    }
}