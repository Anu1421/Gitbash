package objectrepository;

import genericutility.AndroidWebDriverUtility;
import genericutility.WebDriverUtility;
import genericutility.IOSWebDriverUtility;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class AutoHRPopUp {
    WebDriverUtility utility;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic close'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closePopUpBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Turn Off'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/turn_off_button"),
            @FindBy(id = "com.titan.smartworld:id/turn_off_button")
    }) private WebElement turnOffAutoHRBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Update'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/update_button"),
            @FindBy(id = "com.titan.smartworld:id/update_button")
    }) private WebElement updateAutoHRBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Turn On' AND type == 'XCUIElementTypeButton'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/okay_button"),
            @FindBy(id = "com.titan.smartworld:id/okay_button")
    }) private WebElement turnOnAutoHRBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic close']/following-sibling::XCUIElementTypeButton[1]")
    @FindBy(xpath = "//android.widget.Button[1]") private WebElement turnOnOrTurnOffBtn;

    public AutoHRPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getTurnOffAutoHRBtn() {
        return turnOffAutoHRBtn;
    }

    public WebElement getUpdateAutoHRBtn() {
        return updateAutoHRBtn;
    }

    public WebElement getTurnOnAutoHRBtn() {
        return turnOnAutoHRBtn;
    }

    public WebElement getTurnOnOrTurnOffBtn() {
        return turnOnOrTurnOffBtn;
    }

    public void turnOffAutoHRAlert(){
        turnOffAutoHRBtn.click();
    }

    public void turnOnAutoHr(){
        turnOnAutoHRBtn.click();
    }

    public void checkIfAutoHRIsTurnedOff(WebDriver driver, String OS){
        WebDriverUtility.waitForElementToBeVisible(driver, turnOnOrTurnOffBtn, 10);
        if (OS.equalsIgnoreCase("Android")){
            Assert.assertTrue(turnOnOrTurnOffBtn.getText().equals("Turn On"));
        } else if (OS.equalsIgnoreCase("IOS")) {
            Assert.assertTrue(turnOnOrTurnOffBtn.getAttribute("name").equals("Turn On"));
        }
    }

    public void checkIfAutoHRIsTurnedOn(WebDriver driver, String OS){
        WebDriverUtility.waitForElementToBeVisible(driver, turnOffAutoHRBtn, 10);
        if (OS.equalsIgnoreCase("Android")){
            Assert.assertTrue(turnOnOrTurnOffBtn.getText().equals("Turn Off"));
        } else if (OS.equalsIgnoreCase("IOS")) {
            Assert.assertTrue(turnOnOrTurnOffBtn.getAttribute("name").equals("Turn Off"));
        }
    }

    public void turnOnAutoHR(WebDriver driver){
        if (turnOnOrTurnOffBtn.getText().equals("Turn On")){
            turnOnOrTurnOffBtn.click();
            SettingsPage settingsPage=new SettingsPage(driver);
            settingsPage.checkConfirmationToastMessageForChanges();
        }
        else {
            closePopUpBtn.click();
        }
    }

    public void turnOffAutoHR(WebDriver driver){
        if (turnOnOrTurnOffBtn.getText().equals("Turn Off")){
            turnOnOrTurnOffBtn.click();
            SettingsPage settingsPage=new SettingsPage(driver);
            settingsPage.checkConfirmationToastMessageForChanges();
        }
        else {
            closePopUpBtn.click();
        }
    }
}