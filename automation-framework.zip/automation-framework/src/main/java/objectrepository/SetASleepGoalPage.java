package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class SetASleepGoalPage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'back'") private WebElement backBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Hrs']/preceding-sibling::XCUIElementTypeButton/XCUIElementTypeStaticText") private WebElement sleepGoalDuration;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypePickerWheel") private WebElement allSleepValues;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Save Changes'") private WebElement saveChangesBtn;

    public SetASleepGoalPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getSleepGoalDuration() {
        return sleepGoalDuration;
    }

    public WebElement getSaveChangesBtn() {
        return saveChangesBtn;
    }

    public void clickOnSleepDuration(){
        sleepGoalDuration.click();
    }

    public void swipeToDesiredSleepGoal(String sleepDuration){
        allSleepValues.sendKeys(sleepDuration);
    }

    public void clickOnSaveBtn(){
        saveChangesBtn.click();
    }

    public void clickOnBackBtn(){
        backBtn.click();
    }
}
