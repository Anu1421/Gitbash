package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HowTallAreYouPage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'back'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/height_input"),
            @FindBy(id = "com.titan.smartworld:id/height_input")
    }) private WebElement heightTextEdit;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeOther[2]/XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/system_type"),
            @FindBy(id = "com.titan.smartworld:id/system_type")
    }) private WebElement heightUnitSelection;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='CM']/following-sibling::XCUIElementTypeButton")
    @FindBy(xpath = "//android.widget.TextView[@text='FEET']") private WebElement heightInFeet;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='FEET']/following-sibling::XCUIElementTypeButton")
    @FindBy(xpath = "//android.widget.TextView[@text='CM']") private WebElement heightInCm;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Save Changes'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/continue_button"),
            @FindBy(id = "com.titan.smartworld:id/continue_button")
    }) private WebElement saveChangesBtn;

    public HowTallAreYouPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getHeightTextEdit() {
        return heightTextEdit;
    }

    public WebElement getHeightUnitSelection() {
        return heightUnitSelection;
    }

    public WebElement getHeightInFeet() {
        return heightInFeet;
    }

    public WebElement getHeightInCm() {
        return heightInCm;
    }

    public WebElement getSaveChangesBtn() {
        return saveChangesBtn;
    }
}