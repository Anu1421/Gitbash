package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class InstallOnWatchPopUp {
    @FindBy(xpath = "//android.widget.ImageButton[@content-desc='close']") private WebElement closePopUpBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/install_btn"),
            @FindBy(id = "com.titan.smartworld:id/install_btn")
    }) private WebElement installOnWatchBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Watch is not connected'")
    @FindBy(xpath = "//android.widget.Toast") private WebElement toastMessage;

    public InstallOnWatchPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getInstallOnWatchBtn() {
        return installOnWatchBtn;
    }

    public void clickOnClosePopUpBtn(){
        closePopUpBtn.click();
    }

    public void clickOnInstallOnWatchBtn(){
        installOnWatchBtn.click();
    }

    public void checkIfProperToastMessageIsDisplayedWhenWatchIsNotConnected(){
        Assert.assertEquals(toastMessage.getText(), "Watch is not connected");
    }
}
