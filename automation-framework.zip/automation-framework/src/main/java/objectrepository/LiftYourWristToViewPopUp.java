package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LiftYourWristToViewPopUp {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic close'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closePopUpBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Lifting your wrist will bring your display to life.']/following-sibling::XCUIElementTypeButton")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/okay_button"),
            @FindBy(id = "com.titan.smartworld:id/okay_button")
    }) private WebElement turnOnOrOffBtn;

    public LiftYourWristToViewPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getTurnOnOrOffBtn() {
        return turnOnOrOffBtn;
    }

    public void turnOffLiftYourWristToView(WebDriver driver){
        if (turnOnOrOffBtn.getText().equals("Turn Off")){
            turnOnOrOffBtn.click();
            SettingsPage settingsPage=new SettingsPage(driver);
            settingsPage.checkConfirmationToastMessageForChanges();
        } else if (turnOnOrOffBtn.getText().equals("Turn On")){
            closePopUpBtn.click();
        }
    }
}
