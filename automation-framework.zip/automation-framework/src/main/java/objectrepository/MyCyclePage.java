package objectrepository;

import genericutility.WebDriverUtility;
import genericutility.IOSWebDriverUtility;
import genericutility.JavaUtility;
import genericutility.AndroidWebDriverUtility;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class MyCyclePage {
    WebDriverUtility utility;
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic back Img'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'ic preiod'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_female_icon"),
            @FindBy(id = "com.titan.smartworld:id/iv_female_icon")
    }) private WebElement myCycleIcon;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'My Cycle'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title"),
            @FindBy(id = "com.titan.smartworld:id/title")
    }) private WebElement pageTitle;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic calendercommon']/preceding-sibling::XCUIElementTypeOther[1]/XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/date_text"),
            @FindBy(id = "com.titan.smartworld:id/date_text")
    }) private WebElement currentDate;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic calendercommon']/preceding-sibling::XCUIElementTypeOther[1]/XCUIElementTypeOther[1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/previous_icon"),
            @FindBy(id = "com.titan.smartworld:id/previous_icon")
    }) private WebElement previousBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic calendercommon']/preceding-sibling::XCUIElementTypeOther[1]/XCUIElementTypeOther[4]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/next_icon"),
            @FindBy(id = "com.titan.smartworld:id/next_icon")
    }) private WebElement nextBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic calendercommon'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/calendar"),
            @FindBy(id = "com.titan.smartworld:id/calendar")
    }) private WebElement calendarIcon;

    @iOSXCUITFindBy(iOSNsPredicate = "label BEGINSWITH 'DAY '")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/day_text"),
            @FindBy(id = "com.titan.smartworld:id/day_text")
    }) private WebElement dayOfPeriodText;

    @iOSXCUITFindBy(iOSNsPredicate = "label BEGINSWITH 'DAY '")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/state_text"),
            @FindBy(id = "com.titan.smartworld:id/state_text")
    }) private WebElement stateOfPeriodText;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'START'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/btn_start"),
            @FindBy(id = "com.titan.smartworld:id/btn_start")
    }) private WebElement startPeriodBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'EDIT'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/btn_edit"),
            @FindBy(id = "com.titan.smartworld:id/btn_edit")
    }) private WebElement editPeriodBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/right_arrow"),
            @FindBy(id = "com.titan.smartworld:id/right_arrow")
    }) private WebElement rightArrow;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/left_arrow"),
            @FindBy(id = "com.titan.smartworld:id/left_arrow")
    }) private WebElement leftArrow;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='ic_add']/following-sibling::XCUIElementTypeButton")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_plus"),
            @FindBy(id = "com.titan.smartworld:id/iv_plus")
    }) private WebElement addLogsBtnUnderGraph;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='ic_add']/following-sibling::XCUIElementTypeOther/XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_month_name"),
            @FindBy(id = "com.titan.smartworld:id/tv_month_name")
    }) private WebElement monthName;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Last Period']/preceding-sibling::XCUIElementTypeStaticText[2]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_last_period_date"),
            @FindBy(id = "com.titan.smartworld:id/tv_last_period_date")
    }) private WebElement lastPeriodDate;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Next Period']/preceding-sibling::XCUIElementTypeStaticText[2]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_days_left_count"),
            @FindBy(id = "com.titan.smartworld:id/tv_days_left_count")
    }) private WebElement daysLeftBeforeNextPeriod;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Avg. Period cycle']/preceding-sibling::XCUIElementTypeStaticText[2]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_average_period_cycle"),
            @FindBy(id = "com.titan.smartworld:id/tv_average_period_cycle")
    }) private WebElement avgPeriodCycle;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Avg. Cycle length']/preceding-sibling::XCUIElementTypeStaticText[2]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_average_cycle_length"),
            @FindBy(id = "com.titan.smartworld:id/tv_average_cycle_length")
    }) private WebElement avgPeriodCycleLength;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'My Logs'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_my_logs"),
            @FindBy(id = "com.titan.smartworld:id/tv_my_logs")
    }) private WebElement myLogsTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'No symptoms have been logged for today. Log using the + icon'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_no_log"),
            @FindBy(id = "com.titan.smartworld:id/tv_no_log")
    }) private WebElement messageWhenNoLogsAdded;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Add']/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeButton")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_add"),
            @FindBy(id = "com.titan.smartworld:id/tv_add")
    }) private WebElement addLogsBtnUnderMyLogs;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Bloating'")
    @FindBy(xpath = "//android.widget.TextView[@text='Bloating']") private WebElement bloatingSymptomInMyLogs;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Medication'")
    @FindBy(xpath = "//android.widget.TextView[@text='Medication']") private WebElement medicationsUnderMyLogs;

    public MyCyclePage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getMyCycleIcon() {
        return myCycleIcon;
    }

    public WebElement getPageTitle() {
        return pageTitle;
    }

    public WebElement getCurrentDate() {
        return currentDate;
    }

    public WebElement getPreviousBtn() {
        return previousBtn;
    }

    public WebElement getNextBtn() {
        return nextBtn;
    }

    public WebElement getCalendarIcon() {
        return calendarIcon;
    }

    public WebElement getDayOfPeriodText() {
        return dayOfPeriodText;
    }

    public WebElement getStateOfPeriodText() {
        return stateOfPeriodText;
    }

    public WebElement getStartPeriodBtn() {
        return startPeriodBtn;
    }

    public WebElement getEditPeriodBtn() {
        return editPeriodBtn;
    }

    public WebElement getRightArrow() {
        return rightArrow;
    }

    public WebElement getLeftArrow() {
        return leftArrow;
    }

    public WebElement getAddLogsBtnUnderGraph() {
        return addLogsBtnUnderGraph;
    }

    public WebElement getMonthName() {
        return monthName;
    }

    public WebElement getLastPeriodDate() {
        return lastPeriodDate;
    }

    public WebElement getDaysLeftBeforeNextPeriod() {
        return daysLeftBeforeNextPeriod;
    }

    public WebElement getAvgPeriodCycle() {
        return avgPeriodCycle;
    }

    public WebElement getAvgPeriodCycleLength() {
        return avgPeriodCycleLength;
    }

    public WebElement getMyLogsTitle() {
        return myLogsTitle;
    }

    public WebElement getMessageWhenNoLogsAdded() {
        return messageWhenNoLogsAdded;
    }

    public WebElement getBloatingSymptomInMyLogs() {
        return bloatingSymptomInMyLogs;
    }

    public WebElement getAddLogsBtnUnderMyLogs() {
        return addLogsBtnUnderMyLogs;
    }

    public void checkIfAllElementsArePresent(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            utility =new AndroidWebDriverUtility();
            Assert.assertTrue(currentDate.isDisplayed());
            Assert.assertTrue(calendarIcon.isDisplayed());
            Assert.assertTrue(rightArrow.isDisplayed());
            Assert.assertTrue(monthName.isDisplayed());
            Assert.assertTrue(lastPeriodDate.isDisplayed());
            Assert.assertTrue(daysLeftBeforeNextPeriod.isDisplayed());
            utility.swipeByElements(driver, lastPeriodDate, monthName, 2);
            Assert.assertTrue(myLogsTitle.isDisplayed());
            Assert.assertTrue(messageWhenNoLogsAdded.getText().equals("No symptoms have been logged for today. Log using the + icon"));
            Assert.assertTrue(addLogsBtnUnderMyLogs.isDisplayed());
        } else if (OS.equalsIgnoreCase("IOS")) {
            utility =new IOSWebDriverUtility();
            Assert.assertTrue(currentDate.isDisplayed());
            Assert.assertTrue(calendarIcon.isDisplayed());
            Assert.assertTrue(monthName.isDisplayed());
            Assert.assertTrue(lastPeriodDate.isDisplayed());
            Assert.assertTrue(daysLeftBeforeNextPeriod.isDisplayed());
            utility.swipeByElements(driver, lastPeriodDate, monthName, 2);
            Assert.assertTrue(myLogsTitle.isDisplayed());
            Assert.assertTrue(messageWhenNoLogsAdded.getAttribute("name").equals("No symptoms have been logged for today. Log using the + icon"));
            Assert.assertTrue(addLogsBtnUnderMyLogs.isDisplayed());
        }
    }

    public void checkIfStartBtnIsDisplayedAndIsClickable(){
        Assert.assertTrue(startPeriodBtn.isDisplayed());
        Assert.assertTrue(startPeriodBtn.isEnabled());
    }

    public void clickOnStartPeriodBtn(){
        startPeriodBtn.click();
    }

    public void checkIfDayOfPeriodIsResetToDayOne(WebDriver driver, String OS){
        WebDriverUtility.waitForElementToBeVisible(driver, dayOfPeriodText, 10);
        if (OS.equalsIgnoreCase("Android")){
            Assert.assertEquals(dayOfPeriodText.getText(),"Day 1");
        } else if (OS.equalsIgnoreCase("IOS")) {
            Assert.assertEquals(dayOfPeriodText.getAttribute("name"),"DAY 1");
        }
    }

    public void checkIfLastPeriodDateIsCurrentDate(){
        JavaUtility javaUtility=new JavaUtility();
        Assert.assertTrue(lastPeriodDate.getText().contains(javaUtility.getSystemDate()));
    }

    public void checkIfEditBtnIsDisplayedAndIsClickable(){
        Assert.assertTrue(editPeriodBtn.isDisplayed());
        Assert.assertTrue(editPeriodBtn.isEnabled());
    }

    public void clickOnEditPeriodBtn(){
        editPeriodBtn.click();
    }

    public void checkIfUserLandsInMyCyclePage(){
        Assert.assertTrue(pageTitle.getText().equals("My Cycle"));
    }

    public void swipeRightOnMyCyclePage(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            utility =new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            utility =new IOSWebDriverUtility();
        }
        WebDriverUtility.waitForElementToBeVisible(driver, startPeriodBtn, 10);
        utility.swipeScreen(driver, WebDriverUtility.Direction.LEFT);
    }

    public void checkIfUserCanViewBarGraphs(){
        Assert.assertTrue(avgPeriodCycle.isDisplayed());
    }

    public void clickOnNextBtn(){
        nextBtn.click();
    }
    public void clickOnPreviousBtn(){
        previousBtn.click();
    }

    public void clickOnNextBtnFiveTimes(){
        for (int i=0; i<=4;i++){
            nextBtn.click();
        }
    }

    public void clickOnPreviousBtnTenTimes(){
        for (int i=0; i<=9;i++){
            previousBtn.click();
        }
    }

    public void clickOnCalendarIcon(){
        calendarIcon.click();
    }

    public void clickOnAddLogsBtn(){
        addLogsBtnUnderGraph.click();
    }

    public void checkIfBloatingIsAddedAsSymptomUnderMySymptomsLogs(){
        Assert.assertTrue(bloatingSymptomInMyLogs.isDisplayed());
    }

    public void swipeDownToMySymptomsLogs(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            utility = new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            utility = new IOSWebDriverUtility();
        }
        utility.swipeByElements(driver, lastPeriodDate, monthName, 1);
    }

    public void checkIfMedicationsIsAddedAsSymptomUnderMySymptomsLogs(){
        Assert.assertTrue(medicationsUnderMyLogs.isDisplayed());
    }

    public int returnRemainingDaysForNextPeriodFromMyCyclePage(){
        String remainingDays=daysLeftBeforeNextPeriod.getText();
        JavaUtility javaUtility=new JavaUtility();
        return javaUtility.getOnlyNumberFromString(remainingDays);
    }

    public int returnCurrentDayOfPeriodFromMyCyclePage(){
        String currentDay=dayOfPeriodText.getText();
        JavaUtility javaUtility=new JavaUtility();
        return javaUtility.getOnlyNumberFromString(currentDay);
    }
}