package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TellUsYourNewMobileNumberPage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'back'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='back']/following-sibling::XCUIElementTypeTextField//XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/country_code_input"),
            @FindBy(id = "com.titan.smartworld:id/country_code_input")
    }) private WebElement countryCodeSelection;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='back']/following-sibling::XCUIElementTypeTextField")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/mobile_number_input"),
            @FindBy(id = "com.titan.smartworld:id/mobile_number_input")
    }) private WebElement phoneNumberTxtEdit;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Continue'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/continue_button"),
            @FindBy(id = "com.titan.smartworld:id/continue_button"),
    }) private WebElement continueBtn;

    public TellUsYourNewMobileNumberPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getCountryCodeSelection() {
        return countryCodeSelection;
    }

    public WebElement getPhoneNumberTxtEdit() {
        return phoneNumberTxtEdit;
    }

    public WebElement getContinueBtn() {
        return continueBtn;
    }
}
