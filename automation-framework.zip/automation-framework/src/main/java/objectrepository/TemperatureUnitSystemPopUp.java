package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TemperatureUnitSystemPopUp {

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title_view"),
            @FindBy(id = "com.titan.smartworld:id/title_view")
    }) private WebElement popUpTitle;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closePopUpBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/message_view"),
            @FindBy(id = "com.titan.smartworld:id/message_view")
    }) private WebElement popUpMessage;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/okay_button"),
            @FindBy(id = "com.titan.smartworld:id/okay_button")
    }) private WebElement unitToggleBtn;

    public TemperatureUnitSystemPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getPopUpTitle() {
        return popUpTitle;
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getPopUpMessage() {
        return popUpMessage;
    }

    public WebElement getUnitToggleBtn() {
        return unitToggleBtn;
    }

    public void clickOnChangeTemperatureUnitBtn(){
        unitToggleBtn.click();
    }
}