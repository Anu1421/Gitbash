package objectrepository;

import genericutility.AndroidWebDriverUtility;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;

public class FavouriteContactsPage {

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'back'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Favourite Contacts'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/textView3"),
            @FindBy(id = "com.titan.smartworld:id/textView3")
    }) private WebElement pageTitle;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Harivardan']/preceding-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.widget.TextView[@text='Harivardan']/following-sibling::android.widget.TextView[1]") private WebElement harivardanMobileNumber;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Anil Babai'")
    @FindBy(xpath = "//android.widget.TextView[@text='Anil Babai']") private WebElement anilBabaiContactName;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Fazal'")
    @FindBy(xpath = "//android.widget.TextView[@text='Fazal']") private WebElement fazalContactName;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Lavanya'")
    @FindBy(xpath = "//android.widget.TextView[@text='Lavanya']") private WebElement lavanyaContactName;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Pravin Bhai'")
    @FindBy(xpath = "//android.widget.TextView[@text='Pravin Bhai']") private WebElement pravinBhaiContactName;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_contact_name"),
            @FindBy(id = "com.titan.smartworld:id/tv_contact_name")
    }) private List<WebElement> contactName;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Harivardan']/following-sibling::XCUIElementTypeOther")
    @FindBy(xpath = "//androidx.recyclerview.widget.RecyclerView/android.widget.FrameLayout[1]/android.view.ViewGroup/android.widget.ImageView") private WebElement hamburgerIcon;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Delete'")
    @FindBy(xpath = "//android.widget.TextView[@text='Delete']") private WebElement deleteOption;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_delete_contacts_message"),
            @FindBy(id = "com.titan.smartworld:id/tv_delete_contacts_message")
    }) private WebElement deleteContactsMessage;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Add more'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/btn_add_more"),
            @FindBy(id = "com.titan.smartworld:id/btn_add_more")
    }) private WebElement addMoreContactsBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Save'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/btn_save"),
            @FindBy(id = "com.titan.smartworld:id/btn_save")
    }) private WebElement saveBtn;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTable/following-sibling::XCUIElementTypeOther//XCUIElementTypeStaticText)[1]")
    @FindBy(xpath = "//android.widget.Button[1]") private WebElement addMoreOrSaveBtn;

    public FavouriteContactsPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getPageTitle() {
        return pageTitle;
    }

    public WebElement getHarivardanMobileNumber() {
        return harivardanMobileNumber;
    }

    public WebElement getAnilBabaiContactName() {
        return anilBabaiContactName;
    }

    public WebElement getFazalContactName() {
        return fazalContactName;
    }

    public WebElement getLavanyaContactName() {
        return lavanyaContactName;
    }

    public WebElement getPravinBhaiContactName() {
        return pravinBhaiContactName;
    }

    public List<WebElement> getContactName() {
        return contactName;
    }

    public WebElement getHamburgerIcon() {
        return hamburgerIcon;
    }

    public WebElement getDeleteOption() {
        return deleteOption;
    }

    public WebElement getDeleteContactsMessage() {
        return deleteContactsMessage;
    }

    public WebElement getAddMoreContactsBtn() {
        return addMoreContactsBtn;
    }

    public WebElement getSaveBtn() {
        return saveBtn;
    }

    public WebElement getAddMoreOrSaveBtn() {
        return addMoreOrSaveBtn;
    }

    public void checkIfUserLandsInFavouriteContactsPage(){
        Assert.assertEquals(pageTitle.getText(), "Favourite Contacts");
    }

    public void deleteHarivardanNumberAndClickOnSave(WebDriver driver){
        AndroidWebDriverUtility webdriverUtility=new AndroidWebDriverUtility();
        webdriverUtility.swipeByElements(driver, hamburgerIcon, harivardanMobileNumber, 1000);
        deleteOption.click();
        saveBtn.click();
    }

    public void clickOnAddMoreBtn(){
        addMoreContactsBtn.click();
    }

    public void clickOnSaveBtn(){
        saveBtn.click();
    }

    public void checkIfContactsHaveBeenAdded(){
        Assert.assertTrue(anilBabaiContactName.isDisplayed());
        Assert.assertTrue(fazalContactName.isDisplayed());
        Assert.assertTrue(lavanyaContactName.isDisplayed());
        Assert.assertTrue(pravinBhaiContactName.isDisplayed());
    }

    public void checkIfMaxContactsAreAdded(){
        Assert.assertEquals(contactName.size(),8);
    }

    public void checkIfDeleteContactMessageIsDisplayed(){
        Assert.assertTrue(deleteContactsMessage.isDisplayed());
    }
}