package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class TemperaturePage {
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/icon"),
            @FindBy(id = "com.titan.smartworld:id/icon")
    }) private WebElement temperatureIcon;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title"),
            @FindBy(id = "com.titan.smartworld:id/title")
    }) private WebElement pageTitle;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/date_text"),
            @FindBy(id = "com.titan.smartworld:id/date_text")
    }) private WebElement currentDate;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/calendar"),
            @FindBy(id = "com.titan.smartworld:id/calendar")
    }) private WebElement calendarIcon;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/previous_icon"),
            @FindBy(id = "com.titan.smartworld:id/previous_icon")
    }) private WebElement previousBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/next_icon"),
            @FindBy(id = "com.titan.smartworld:id/next_icon")
    }) private WebElement nextBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/day"),
            @FindBy(id = "com.titan.smartworld:id/day")
    }) private WebElement dayBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/week"),
            @FindBy(id = "com.titan.smartworld:id/week")
    }) private WebElement weekBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/month"),
            @FindBy(id = "com.titan.smartworld:id/month")
    }) private WebElement monthBtn;

    @FindBy(xpath = "//android.widget.TextView[@text='Latest']/preceding-sibling::android.widget.TextView") private WebElement latestTemperature;

    @FindBy(xpath = "//android.widget.TextView[@text='Maximum']/preceding-sibling::android.widget.TextView") private WebElement maximumTemperature;

    @FindBy(xpath = "//android.widget.TextView[@text='Minimum']/preceding-sibling::android.widget.TextView") private WebElement minimumTemperature;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/type_text_view"),
            @FindBy(id = "com.titan.smartworld:id/type_text_view")
    }) private WebElement yAxisParameterInTemperatureGraph;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title_fat_burns"),
            @FindBy(id = "com.titan.smartworld:id/title_fat_burns")
    }) private WebElement temperatureCard;

    public TemperaturePage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getTemperatureIcon() {
        return temperatureIcon;
    }

    public WebElement getPageTitle() {
        return pageTitle;
    }

    public WebElement getCurrentDate() {
        return currentDate;
    }

    public WebElement getCalendarIcon() {
        return calendarIcon;
    }

    public WebElement getPreviousBtn() {
        return previousBtn;
    }

    public WebElement getNextBtn() {
        return nextBtn;
    }

    public WebElement getDayBtn() {
        return dayBtn;
    }

    public WebElement getWeekBtn() {
        return weekBtn;
    }

    public WebElement getMonthBtn() {
        return monthBtn;
    }

    public WebElement getLatestTemperature() {
        return latestTemperature;
    }

    public WebElement getMaximumTemperature() {
        return maximumTemperature;
    }

    public WebElement getMinimumTemperature() {
        return minimumTemperature;
    }

    public WebElement getyAxisParameterInTemperatureGraph() {
        return yAxisParameterInTemperatureGraph;
    }

    public WebElement getTemperatureCard() {
        return temperatureCard;
    }

    public void checkIfUserLandsInTemperatureScreen(){
        Assert.assertEquals(pageTitle.getText(), "Temperature");
    }

    public void clickOnDayBtn(){
        dayBtn.click();
    }
}