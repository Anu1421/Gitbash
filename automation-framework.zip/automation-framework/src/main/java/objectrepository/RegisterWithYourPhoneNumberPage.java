package objectrepository;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegisterWithYourPhoneNumberPage {
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/country_code_input"),
            @FindBy(id = "com.titan.smartworld:id/country_code_input")
    }) private WebElement countryCodeSelection;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/mobile_number_input"),
            @FindBy(id = "com.titan.smartworld:id/mobile_number_input")
    }) private WebElement phoneNumberTxtEdit;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/continue_button"),
            @FindBy(id = "com.titan.smartworld:id/continue_button")
    }) private WebElement submitBtn;

    public RegisterWithYourPhoneNumberPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement countryCodeSelection() {
        return countryCodeSelection;
    }

    public WebElement getPhoneNumberTxtEdit() {
        return phoneNumberTxtEdit;
    }

    public WebElement getSubmitBtn() {
        return submitBtn;
    }

    public void loginToApplication(AndroidDriver driver, String mobileNumber){
        countryCodeSelection.click();
        CountryCodePage countryCodePage=new CountryCodePage(driver);
        countryCodePage.selectDesiredCountry("India");
        phoneNumberTxtEdit.sendKeys(mobileNumber);
        submitBtn.click();
    }
}