package objectrepository;

import genericutility.AndroidWebDriverUtility;
import genericutility.WebDriverUtility;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class MusicPage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic back'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'music_head'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/icon"),
            @FindBy(id = "com.titan.smartworld:id/icon")
    }) private WebElement musicPageIcon;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Music'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/textView3"),
            @FindBy(id = "com.titan.smartworld:id/textView3")
    }) private WebElement pageTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "value == '0'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/autoplay"),
            @FindBy(id = "com.titan.smartworld:id/autoplay")
    }) private WebElement autoPlayMusicToggle;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'All'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/all"),
            @FindBy(id = "com.titan.smartworld:id/all")
    }) private WebElement allMusicTab;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'My Playlist'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/my_playlist"),
            @FindBy(id = "com.titan.smartworld:id/my_playlist")
    }) private WebElement myPlaylistTab;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='01']/following-sibling::XCUIElementTypeOther//XCUIElementTypeButton[@name='play song']")
    @FindBy(id = "(//android.widget.ImageView[@content-desc=\"Play\"])[1]") private WebElement playBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='01']/following-sibling::XCUIElementTypeOther//XCUIElementTypeButton[2]")
    @FindBy(id = "(//android.widget.ImageView[@content-desc=\"My Playlist\"])[1]") private WebElement addToMyPlaylistBtn;

    public MusicPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getMusicPageIcon() {
        return musicPageIcon;
    }

    public WebElement getPageTitle() {
        return pageTitle;
    }

    public WebElement getAutoPlayMusicToggle() {
        return autoPlayMusicToggle;
    }

    public WebElement getAllMusicTab() {
        return allMusicTab;
    }

    public WebElement getMyPlaylistTab() {
        return myPlaylistTab;
    }

    public WebElement getPlayBtn() {
        return playBtn;
    }

    public WebElement getAddToMyPlaylistBtn() {
        return addToMyPlaylistBtn;
    }

    public void checkIfUserLandsInMusicPage(WebDriver driver){
        WebDriverUtility.waitForElementToBeVisible(driver, musicPageIcon, 10);
        Assert.assertTrue(pageTitle.getText().equals("Music"));
    }
}