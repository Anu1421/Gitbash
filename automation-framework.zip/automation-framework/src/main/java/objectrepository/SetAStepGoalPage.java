package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class SetAStepGoalPage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'back'") private WebElement backBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Steps']/preceding-sibling::XCUIElementTypeButton/XCUIElementTypeStaticText") private WebElement stepGoalCount;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypePickerWheel") private WebElement allStepValues;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Save Changes'") private WebElement saveChangesBtn;

    public SetAStepGoalPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getStepGoalCount() {
        return stepGoalCount;
    }

    public WebElement getSaveChangesBtn() {
        return saveChangesBtn;
    }

    public void clickOnStepsCount(){
        stepGoalCount.click();
    }

    public void swipeToDesiredStepGoal(String stepCount){
        allStepValues.sendKeys(stepCount);
    }

    public void clickOnSaveBtn(){
        saveChangesBtn.click();
    }

    public void clickOnBackBtn(){
        backBtn.click();
    }
}
