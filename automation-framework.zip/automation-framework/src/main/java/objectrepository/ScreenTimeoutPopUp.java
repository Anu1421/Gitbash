package objectrepository;//package objectrepository;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class ScreenTimeoutPopUp {
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic close']/following-sibling::XCUIElementTypeStaticText[@name='Screen Timeout']")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title_view"),
            @FindBy(id = "com.titan.smartworld:id/title_view")
    }) private WebElement popUpTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic close'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closeBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label BEGINSWITH 'Every: '")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/frequency"),
            @FindBy(id = "com.titan.smartworld:id/frequency")
    }) private WebElement timeoutInterval;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Save'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/okay_button"),
            @FindBy(id = "com.titan.smartworld:id/okay_button")
    }) private WebElement saveBtn;

    public ScreenTimeoutPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getPopUpTitle() {
        return popUpTitle;
    }

    public WebElement getCloseBtn() {
        return closeBtn;
    }

    public WebElement getTimeoutInterval() {
        return timeoutInterval;
    }

    public WebElement getSaveBtn() {
        return saveBtn;
    }

    public void clickOnSaveBtn(){
        saveBtn.click();
    }

    public void checkIfScreenTimeoutPopUpIsDisplayed(){
        Assert.assertTrue(popUpTitle.getText().equals("Screen Timeout"));
    }
}
