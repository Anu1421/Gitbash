package objectrepository;

import genericutility.AndroidWebDriverUtility;
import genericutility.WebDriverUtility;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;

public class EnterOtpPage {
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/pin_1"),
            @FindBy(id = "com.titan.smartworld:id/pin_1")
    }) private WebElement otpFirstDigit;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/pin_2"),
            @FindBy(id = "com.titan.smartworld:id/pin_2")
    }) private WebElement otpSecondDigit;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/pin_3"),
            @FindBy(id = "com.titan.smartworld:id/pin_3")
    }) private WebElement otpThirdDigit;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/pin_4"),
            @FindBy(id = "com.titan.smartworld:id/pin_4")
    }) private WebElement otpForthDigit;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/continue_button"),
            @FindBy(id = "com.titan.smartworld:id/continue_button")
    }) private WebElement continueBtn;

    public EnterOtpPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getOtpFirstDigit() {
        return otpFirstDigit;
    }

    public WebElement getOtpSecondDigit() {
        return otpSecondDigit;
    }

    public WebElement getOtpThirdDigit() {
        return otpThirdDigit;
    }

    public WebElement getOtpForthDigit() {
        return otpForthDigit;
    }

    public WebElement getContinueBtn() {
        return continueBtn;
    }

    public void enterOtp() throws Throwable {
        ArrayList otpDigitByDigit = WebDriverUtility.getOtpDigitByDigit();
        otpFirstDigit.sendKeys(otpDigitByDigit.get(0).toString());
        otpSecondDigit.sendKeys(otpDigitByDigit.get(1).toString());
        otpThirdDigit.sendKeys(otpDigitByDigit.get(2).toString());
        otpForthDigit.sendKeys(otpDigitByDigit.get(3).toString());
        continueBtn.click();
    }
}
