package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SelectYourWatchPage {
    @FindBy(xpath = "//android.widget.ImageView[@content-desc='Reflex Vox2']") private WebElement reflexVox2selection;

    @FindBy(xpath = "//android.widget.ImageView[@content-desc='Reflex Play']") private WebElement reflexPlayselection;

    public SelectYourWatchPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getReflexVox2selection() {
        return reflexVox2selection;
    }

    public WebElement getReflexPlayselection() {
        return reflexPlayselection;
    }

    public void selectDesiredWatch(){
        reflexPlayselection.click();
    }
}
