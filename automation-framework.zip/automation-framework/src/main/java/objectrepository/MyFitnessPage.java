package objectrepository;//package objectrepository;

import genericutility.AndroidWebDriverUtility;
import genericutility.WebDriverUtility;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class MyFitnessPage {
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'ic_back'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'My Fitness'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title"),
            @FindBy(id = "com.titan.smartworld:id/title")
    }) private WebElement myFitnessPageTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "//XCUIElementTypeButton[@name='ic calendercommon']/preceding-sibling::XCUIElementTypeOther[1]/XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/date_text"),
            @FindBy(id = "com.titan.smartworld:id/date_text")
    }) private WebElement dateText;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'ic calendercommon'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/calendar"),
            @FindBy(id = "com.titan.smartworld:id/calendar")
    }) private WebElement calendarIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic calendercommon']/preceding-sibling::XCUIElementTypeOther[1]/XCUIElementTypeOther[1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/previous_icon"),
            @FindBy(id = "com.titan.smartworld:id/previous_icon")
    }) private WebElement previousBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic calendercommon']/preceding-sibling::XCUIElementTypeOther[1]/XCUIElementTypeOther[4]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/next_icon"),
            @FindBy(id = "com.titan.smartworld:id/next_icon")
    }) private WebElement nextBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Day'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/day"),
            @FindBy(id = "com.titan.smartworld:id/day")
    }) private WebElement dayBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Week'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/week"),
            @FindBy(id = "com.titan.smartworld:id/week")
    }) private WebElement weekBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Month'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/month"),
            @FindBy(id = "com.titan.smartworld:id/month")
    }) private WebElement monthBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='  Steps ']/preceding-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.widget.TextView[@text='Steps']/../android.widget.TextView[1]") private WebElement stepsCount;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Distance']/preceding-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.widget.TextView[@text='Distance']/../android.widget.TextView[1]") private WebElement distanceCount;

    @iOSXCUITFindBy(iOSNsPredicate = "label ENDSWITH ' Cal'")
    @FindBy(xpath = "//android.widget.TextView[@text='Calories']/../android.widget.TextView[1]") private WebElement caloriesCount;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Attention!'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title_attention"),
            @FindBy(id = "com.titan.smartworld:id/title_attention")
    }) private WebElement attentionMessage;

    public MyFitnessPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getDateText() {
        return dateText;
    }

    public WebElement getCalendarIcon() {
        return calendarIcon;
    }

    public WebElement getPreviousBtn() {
        return previousBtn;
    }

    public WebElement getNextBtn() {
        return nextBtn;
    }

    public WebElement getDayBtn() {
        return dayBtn;
    }

    public WebElement getWeekBtn() {
        return weekBtn;
    }

    public WebElement getMonthBtn() {
        return monthBtn;
    }

    public WebElement getMyFitnessPageTitle() {
        return myFitnessPageTitle;
    }

    public WebElement getStepsCount() {
        return stepsCount;
    }

    public WebElement getDistanceCount() {
        return distanceCount;
    }

    public WebElement getCaloriesCount() {
        return caloriesCount;
    }

    public WebElement getAttentionMessage() {
        return attentionMessage;
    }

    public void checkIfStepsDistAndCaloriesAreDisplayed(){
        Assert.assertTrue(stepsCount.isDisplayed());
        Assert.assertTrue(distanceCount.isDisplayed());
        Assert.assertTrue(caloriesCount.isDisplayed());
    }

    public void clickOnWeekTab(){
        weekBtn.click();
    }

    public void clickOnMonthTab(){
        monthBtn.click();
    }

    public void checkIfAttentionMessageIsDisplayed(WebDriver driver){
        AndroidWebDriverUtility webdriverUtility=new AndroidWebDriverUtility();
        webdriverUtility.swipeScreen(driver, WebDriverUtility.Direction.UP);
        Assert.assertTrue(attentionMessage.isDisplayed());
    }

    public void clickOnPreviousDayTillRegistrationDate(String OS){
        String date = null;
        while(dateText.isDisplayed()) {
            if (OS.equalsIgnoreCase("Android")){
                date=dateText.getText();
            } else if (OS.equalsIgnoreCase("IOS")) {
                date=dateText.getAttribute("name");
            }
            if (date.equals("16 Aug")) {
                break;
            } else {
                System.out.println("Hello123"+date);
                previousBtn.click();
            }
        }
    }

    public void clickOnPreviousBtn(){
        previousBtn.click();
    }

    public void clickOnBackBtn(){
        backBtn.click();
    }
}