package objectrepository;

import genericutility.AndroidWebDriverUtility;
import genericutility.WebDriverUtility;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ArticlePage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic back Img'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic back Img']/following-sibling::XCUIElementTypeOther/XCUIElementTypeImage[1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/likeIcon"),
            @FindBy(id = "com.titan.smartworld:id/likeIcon")
    }) private WebElement likeBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic back Img']/following-sibling::XCUIElementTypeOther/XCUIElementTypeImage[2]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/shareIcon"),
            @FindBy(id = "com.titan.smartworld:id/shareIcon")
    }) private WebElement shareBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic back Img']/following-sibling::XCUIElementTypeOther/XCUIElementTypeImage[3]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/bookmarkIcon"),
            @FindBy(id = "com.titan.smartworld:id/bookmarkIcon")
    }) private WebElement bookmarkBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='article']/XCUIElementTypeOther[1]/XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.view.View[@resource-id='post-391']/android.view.View/android.widget.TextView") private WebElement articleTitle;

    public ArticlePage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }
    
    public WebElement getLikeBtn() {
        return likeBtn;
    }

    public WebElement getShareBtn() {
        return shareBtn;
    }

    public WebElement getBookmarkBtn() {
        return bookmarkBtn;
    }

    public WebElement getArticleTitle() {
        return articleTitle;
    }

    public String returnArticleTitle(WebDriver driver){
        WebDriverUtility.waitForElementToBeVisible(driver, articleTitle, 10);
        return articleTitle.getText();
    }
}