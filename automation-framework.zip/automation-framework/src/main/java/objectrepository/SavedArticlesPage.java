package objectrepository;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class SavedArticlesPage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic back Img'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'ic_articleIcon'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/icon"),
            @FindBy(id = "com.titan.smartworld:id/icon")
    }) private WebElement savedArticlesIcon;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Articles'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/textView3"),
            @FindBy(id = "com.titan.smartworld:id/textView3")
    }) private WebElement savedArticlesPageTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'All'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/all"),
            @FindBy(id = "com.titan.smartworld:id/all")
    }) private WebElement allSavedArticlesTab;

    @iOSXCUITFindBy(iOSNsPredicate = "value == '  This Week  '")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/thisWeek"),
            @FindBy(id = "com.titan.smartworld:id/thisWeek")
    }) private WebElement thisWeekArticlesTab;

    @iOSXCUITFindBy(iOSNsPredicate = "value == '  This Month  '")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/thisMonth"),
            @FindBy(id = "com.titan.smartworld:id/thisMonth")
    }) private WebElement thisMonthArticlesTab;

    public SavedArticlesPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getSavedArticlesIcon() {
        return savedArticlesIcon;
    }

    public WebElement getSavedArticlesPageTitle() {
        return savedArticlesPageTitle;
    }

    public WebElement getAllSavedArticlesTab() {
        return allSavedArticlesTab;
    }

    public WebElement getThisWeekArticlesTab() {
        return thisWeekArticlesTab;
    }

    public WebElement getThisMonthArticlesTab() {
        return thisMonthArticlesTab;
    }

    public void checkIfUserLandsInArticlesPage(){
        Assert.assertTrue(savedArticlesPageTitle.getText().equals("Articles"));
    }

    public void clickOnBackBtn(){
        backBtn.click();
    }
}