package objectrepository;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class SleepScorePopUp {
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='close']/preceding-sibling::XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title_view"),
            @FindBy(id = "com.titan.smartworld:id/title_view")
    }) private WebElement popUpTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'close'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closeBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'A score calculated from the quality and duration of your sleep.'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/message_view"),
            @FindBy(id = "com.titan.smartworld:id/message_view")
    }) private WebElement messageText;

    public SleepScorePopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getPopUpTitle() {
        return popUpTitle;
    }

    public WebElement getCloseBtn() {
        return closeBtn;
    }

    public WebElement getMessageText() {
        return messageText;
    }

    public void clickOnClosePopUpBtn(){
        closeBtn.click();
    }

    public void checkIfProperSleepScoreMessageIsDisplayed(){
        Assert.assertTrue(messageText.getText().equals("A score calculated from the quality and duration of your sleep."));
    }
}
