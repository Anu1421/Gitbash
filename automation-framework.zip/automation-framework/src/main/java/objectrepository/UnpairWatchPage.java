package objectrepository;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class UnpairWatchPage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Unpaired successfully'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/paired_successfully"),
            @FindBy(id = "com.titan.smartworld:id/paired_successfully")
    }) private WebElement watchUnpairedConfirmationMsg;

    public UnpairWatchPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getWatchUnpairedConfirmationMsg() {
        return watchUnpairedConfirmationMsg;
    }

    public void watchUnpairedConfirmation(){
        Assert.assertEquals(watchUnpairedConfirmationMsg.getText(), " Unpaired successfully");
    }
}