package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.poi.ss.formula.functions.WeekNum;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MultiSportPage {
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/ivCalender"),
            @FindBy(id = "com.titan.smartworld:id/ivCalender")
    }) private WebElement calendarIcon;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/all"),
            @FindBy(id = "com.titan.smartworld:id/all")
    }) private WebElement allMultiSportTab;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/thisWeek"),
            @FindBy(id = "com.titan.smartworld:id/thisWeek")
    }) private WebElement thisWeekMultisportTab;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/thisMonth"),
            @FindBy(id = "com.titan.smartworld:id/thisMonth")
    }) private WebElement thisMonthMultisportTab;

    public MultiSportPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getCalendarIcon() {
        return calendarIcon;
    }

    public WebElement getAllMultiSportTab() {
        return allMultiSportTab;
    }

    public WebElement getThisWeekMultisportTab() {
        return thisWeekMultisportTab;
    }

    public WebElement getThisMonthMultisportTab() {
        return thisMonthMultisportTab;
    }
}