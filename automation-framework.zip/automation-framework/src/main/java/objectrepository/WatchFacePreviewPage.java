package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class WatchFacePreviewPage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic back Img'")
    @FindBy(xpath = "//android.widget.ImageView[@content-desc='back button']") private WebElement backBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Preview']/preceding-sibling::XCUIElementTypeImage")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/icon"),
            @FindBy(id = "com.titan.smartworld:id/icon")
    }) private WebElement previewPageIcon;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Preview'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title"),
            @FindBy(id = "com.titan.smartworld:id/title")
    }) private WebElement pageTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Install on Watch'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/install_btn"),
            @FindBy(id = "com.titan.smartworld:id/install_btn")
    }) private WebElement installOnWatchBtn;

    public WatchFacePreviewPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getPreviewPageIcon() {
        return previewPageIcon;
    }

    public WebElement getPageTitle() {
        return pageTitle;
    }

    public WebElement getInstallOnWatchBtn() {
        return installOnWatchBtn;
    }

    public void clickOnBackBtn(){
        backBtn.click();
    }

    public void clickOnInstallOnWatchBtn(){
        installOnWatchBtn.click();
    }
}
