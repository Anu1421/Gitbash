package objectrepository;

import genericutility.*;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;

public class SettingsPage {
    WebDriverUtility webdriverUtility;
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic Edit Icon']/preceding-sibling::XCUIElementTypeImage")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/profile_picture"),
            @FindBy(id = "com.titan.smartworld:id/profile_picture")
    }) private WebElement profilePictureImg;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic Edit Icon']/following-sibling::XCUIElementTypeStaticText[1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/user_name"),
            @FindBy(id = "com.titan.smartworld:id/user_name")
    }) private WebElement userName;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic Edit Icon']/following-sibling::XCUIElementTypeStaticText[2]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/location"),
            @FindBy(id = "com.titan.smartworld:id/location")
    }) private WebElement userLocation;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic Edit Icon'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/edit_button"),
            @FindBy(id = "com.titan.smartworld:id/edit_button")
    }) private WebElement editProfileBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/notification_background"),
            @FindBy(id = "com.titan.smartworld:id/notification_background")
    }) private WebElement notificationIcon;

    @iOSXCUITFindBy(iOSNsPredicate = "value ENDSWITH 'Notifications'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/turn_on_notification"),
            @FindBy(id = "com.titan.smartworld:id/turn_on_notification")
    }) private WebElement turnOnOrOffNotifications;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'All Apps'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/all_apps"),
            @FindBy(id = "com.titan.smartworld:id/all_apps")
    }) private WebElement allAppsLink;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Settings'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/settings_label"),
            @FindBy(id = "com.titan.smartworld:id/settings_label")
    }) private WebElement settingsPageLabel;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Goals' AND type == 'XCUIElementTypeOther'")
    @FindBy(xpath = "//android.widget.TextView[@text='Goals']") private WebElement goalsOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Step Goal'")
    @FindBy(xpath = "//android.widget.TextView[@text='Step Goal']") private WebElement stepGoalOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Sleep Goal'")
    @FindBy(xpath = "//android.widget.TextView[@text='Sleep Goal']") private WebElement sleepGoalOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Multisport Goal'")
    @FindBy(xpath = "//android.widget.TextView[@text='Multi Sport Goal']") private WebElement multiSportGoalOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Health Data' AND type == 'XCUIElementTypeOther'")
    @FindBy(xpath = "//android.widget.TextView[@text='Health']") private WebElement healthOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Auto Heart Rate'")
    @FindBy(xpath = "//android.widget.TextView[@text='Auto HR']") private WebElement autoHrOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Apple Health'")
    @FindBy(xpath = "//android.widget.TextView[@text='Google fit']") private WebElement googleFitOrAppleHealthOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Sedentary Alert'")
    @FindBy(xpath = "//android.widget.TextView[@text='Sedentary Alert']") private WebElement sedentaryAlertOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'My Cycle Reminders'")
    @FindBy(xpath = "//android.widget.TextView[@text='My Cycle Reminders']") private WebElement myCycleRemindersOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name BEGINSWITH 'Hydration'")
    @FindBy(xpath = "//android.widget.TextView[@text='Hydration Reminder']") private WebElement hydrationReminderOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'High Heart Rate Alert'")
    @FindBy(xpath = "//android.widget.TextView[@text='High HR Alert']") private WebElement highHrAlertOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'My Watch' AND type == 'XCUIElementTypeOther'")
    @FindBy(xpath = "//android.widget.TextView[@text='My Watch']") private WebElement myWatchOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Find your Watch'")
    @FindBy(xpath = "//android.widget.TextView[@text='Find your Watch']") private WebElement findYourWatchOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Unit System'")
    @FindBy(xpath = "//android.widget.TextView[@text='Unit System']") private WebElement unitSystemOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Lift to view'")
    @FindBy(xpath = "//android.widget.TextView[@text='Lift to view']") private WebElement liftToViewOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Screen Timeout'")
    @FindBy(xpath = "//android.widget.TextView[@text='Screen Timeout']") private WebElement screenTimeoutOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Favourite Contacts'")
    @FindBy(xpath = "//android.widget.TextView[@text='Favourite Contacts']") private WebElement favouriteContactsOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Unpair'")
    @FindBy(xpath = "//android.widget.TextView[@text='Unpair']") private WebElement unpairOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Alarm'")
    @FindBy(xpath = "//android.widget.TextView[@text='Alarm']") private WebElement alarmOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'DND'")
    @FindBy(xpath = "//android.widget.TextView[@text='DND']") private WebElement dNDOption;

    @FindBy(xpath = "//android.widget.TextView[@text='Auto Temperature']") private WebElement autoTemperatureOption;

    @FindBy(xpath = "//android.widget.TextView[@text='Temperature Unit System']") private WebElement temperatureUnitSystemOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Weather'")
    @FindBy(xpath = "//android.widget.TextView[@text='Weather']") private WebElement weatherOption;

    @FindBy(xpath = "//android.widget.TextView[@text='Music']") private WebElement musicOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Bluetooth Calling'")
    @FindBy(xpath = "//android.widget.TextView[@text='Bluetooth Calling']") private WebElement bluetoothCallingOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Update Watch'")
    @FindBy(xpath = "//android.widget.TextView[@text='Update Watch']") private WebElement updateWatchOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'General' AND type == 'XCUIElementTypeOther'")
    @FindBy(xpath = "//android.widget.TextView[@text='General']") private WebElement generalOption;

    @FindBy(xpath = "//android.widget.TextView[@text='Battery Optimization']") private WebElement batteryOptimizationOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Report Error'")
    @FindBy(xpath = "//android.widget.TextView[@text='Report Error']") private WebElement reportErrorOption;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'About' AND type == 'XCUIElementTypeOther'")
    @FindBy(xpath = "//android.widget.TextView[@text='About']") private WebElement aboutOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Changes saved successfully'")
    @FindBy(xpath = "//android.widget.Toast") private WebElement successfulToastMessage;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Report sent successfully'") private WebElement reportSentToastMessage;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='settings']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeOther[1]//XCUIElementTypeCell[1]")
    @FindBy(xpath = "//android.widget.FrameLayout[@content-desc='Home']") private WebElement dashboardBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='settings']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeOther[1]//XCUIElementTypeCell[2]")
    @FindBy(xpath = "//android.widget.FrameLayout[@content-desc='Rewards']") private WebElement rewardsBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='settings']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeOther[1]//XCUIElementTypeCell[3]")
    @FindBy(xpath = "//android.widget.FrameLayout[@content-desc='Community']") private WebElement communityBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='settings']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeOther[1]//XCUIElementTypeCell[4]")
    @FindBy(xpath = "//android.widget.FrameLayout[@content-desc='Watch faces']") private WebElement watchFacesBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='settings']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeOther[1]//XCUIElementTypeCell[5]")
    @FindBy(xpath = "//android.widget.FrameLayout[@content-desc='Settings']") private WebElement settingsBtn;

    public SettingsPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getProfilePictureImg() {
        return profilePictureImg;
    }

    public WebElement getUserName() {
        return userName;
    }

    public WebElement getUserLocation() {
        return userLocation;
    }

    public WebElement getEditProfileBtn() {
        return editProfileBtn;
    }

    public WebElement getNotificationIcon() {
        return notificationIcon;
    }

    public WebElement getTurnOnOrOffNotifications() {
        return turnOnOrOffNotifications;
    }

    public WebElement getAllAppsLink() {
        return allAppsLink;
    }

    public WebElement getSettingsPageLabel() {
        return settingsPageLabel;
    }

    public WebElement getGoalsOption() {
        return goalsOption;
    }

    public WebElement getStepGoalOption() {
        return stepGoalOption;
    }

    public WebElement getSleepGoalOption() {
        return sleepGoalOption;
    }

    public WebElement getMultiSportGoalOption() {
        return multiSportGoalOption;
    }

    public WebElement getHealthOption() {
        return healthOption;
    }

    public WebElement getAutoHrOption() {
        return autoHrOption;
    }

    public WebElement getGoogleFitOrAppleHealthOption() {
        return googleFitOrAppleHealthOption;
    }

    public WebElement getSedentaryAlertOption() {
        return sedentaryAlertOption;
    }

    public WebElement getMyCycleRemindersOption() {
        return myCycleRemindersOption;
    }

    public WebElement getHydrationReminderOption() {
        return hydrationReminderOption;
    }

    public WebElement getHighHrAlertOption() {
        return highHrAlertOption;
    }

    public WebElement getMyWatchOption() {
        return myWatchOption;
    }

    public WebElement getFindYourWatchOption() {
        return findYourWatchOption;
    }

    public WebElement getUnitSystemOption() {
        return unitSystemOption;
    }

    public WebElement getLiftToViewOption() {
        return liftToViewOption;
    }

    public WebElement getAutoTemperatureOption() {
        return autoTemperatureOption;
    }

    public WebElement getTemperatureUnitSystemOption() {
        return temperatureUnitSystemOption;
    }

    public WebElement getScreenTimeoutOption() {
        return screenTimeoutOption;
    }

    public WebElement getFavouriteContactsOption() {
        return favouriteContactsOption;
    }

    public WebElement getUnpairOption() {
        return unpairOption;
    }

    public WebElement getAlarmOption() {
        return alarmOption;
    }

    public WebElement getDNDOption() {
        return dNDOption;
    }

    public WebElement getWeatherOption() {
        return weatherOption;
    }

    public WebElement getMusicOption() {
        return musicOption;
    }

    public WebElement getBluetoothCallingOption() {
        return bluetoothCallingOption;
    }

    public WebElement getUpdateWatchOption() {
        return updateWatchOption;
    }

    public WebElement getGeneralOption() {
        return generalOption;
    }

    public WebElement getBatteryOptimizationOption() {
        return batteryOptimizationOption;
    }

    public WebElement getReportErrorOption() {
        return reportErrorOption;
    }

    public WebElement getAboutOption() {
        return aboutOption;
    }

    public WebElement getSuccessfulToastMessage() {
        return successfulToastMessage;
    }

    public WebElement getdNDOption() {
        return dNDOption;
    }

    public WebElement getReportSentToastMessage() {
        return reportSentToastMessage;
    }

    public WebElement getDashboardBtn() {
        return dashboardBtn;
    }

    public WebElement getRewardsBtn() {
        return rewardsBtn;
    }

    public WebElement getCommunityBtn() {
        return communityBtn;
    }

    public WebElement getWatchFacesBtn() {
        return watchFacesBtn;
    }

    public WebElement getSettingsBtn() {
        return settingsBtn;
    }

    public void clickOnHealthOption(){
        healthOption.click();
    }
    public void clickOnHighHRAlertOption(){
        highHrAlertOption.click();
    }
    public void clickOnEditProfile(){
        editProfileBtn.click();
    }

    public void checkForElements(WebDriver driver, String OS){
        SoftAssert softAssert=new SoftAssert();
        if (OS.equalsIgnoreCase("Android")) {
            webdriverUtility = new AndroidWebDriverUtility();
            softAssert.assertTrue(profilePictureImg.isDisplayed(), "Profile Image is displayed");
            softAssert.assertTrue(userName.isDisplayed(), "Username is displayed");
            softAssert.assertTrue(userLocation.isDisplayed(), "User Location is displayed");
            softAssert.assertTrue(turnOnOrOffNotifications.isDisplayed(), "Notification options are displayed");
            if (BaseClass.features.contains("Goals")) {
                softAssert.assertTrue(goalsOption.isDisplayed(), "Goals option is displayed");
                goalsOption.click();
                softAssert.assertTrue(stepGoalOption.isDisplayed(), "Step Goal option is displayed");
                softAssert.assertTrue(sleepGoalOption.isDisplayed(), "Sleep Goal option is displayed");
                softAssert.assertTrue(multiSportGoalOption.isDisplayed(), "Multi Sport Goal option is displayed");
                goalsOption.click();
            }
            if (BaseClass.features.contains("Health")) {
                softAssert.assertTrue(healthOption.isDisplayed(), "Health option is displayed");
            }
            if (BaseClass.features.contains("autoHR")) {
                healthOption.click();
                softAssert.assertTrue(autoHrOption.isDisplayed(), "Auto HR option is displayed");
            }
            if (BaseClass.features.contains("googleFit")) {
                softAssert.assertTrue(googleFitOrAppleHealthOption.isDisplayed(), "Google Fit option is displayed");
            }
            if (BaseClass.features.contains("sedentaryAlert")) {
                softAssert.assertTrue(sedentaryAlertOption.isDisplayed(), "Sedentary Alert option is displayed");
                webdriverUtility.swipeByElements(driver, sedentaryAlertOption, goalsOption, 2);
            }
            if (BaseClass.features.contains("myCycleReminders")) {
                if (profilePictureImg.getAttribute("content-desc").equalsIgnoreCase("Male")){
                    Reporter.log("Since Gender is Male, My Cycle Reminder is unavailable", true);
                } else if (profilePictureImg.getAttribute("content-desc").equalsIgnoreCase("Female")) {
                    softAssert.assertTrue(myCycleRemindersOption.isDisplayed(), "My Cycle Reminders option is displayed");
                }
            }
            if (BaseClass.features.contains("hydrationReminder")) {
                softAssert.assertTrue(hydrationReminderOption.isDisplayed(), "Hydration option is displayed");
            }
            if (BaseClass.features.contains("highHRAlert")) {
                softAssert.assertTrue(highHrAlertOption.isDisplayed(), "High HR Alert option is displayed");
                webdriverUtility.swipeByElements(driver, sedentaryAlertOption, myWatchOption, 2);
                healthOption.click();
            }
            if (BaseClass.features.contains("MyWatch")) {
                softAssert.assertTrue(myWatchOption.isDisplayed(), "My Watch option is displayed");
            }
            if (BaseClass.features.contains("findYourWatch")) {
                myWatchOption.click();
                softAssert.assertTrue(findYourWatchOption.isDisplayed(), "Find Your Watch option is displayed");
            }
            if (BaseClass.features.contains("unitSystem")) {
                softAssert.assertTrue(unitSystemOption.isDisplayed(), "Unit System option is displayed");
            }
            if (BaseClass.features.contains("liftToView")) {
                webdriverUtility.swipeByElements(driver, unitSystemOption, settingsPageLabel, 2);
                softAssert.assertTrue(liftToViewOption.isDisplayed(), "Lift to view option is displayed");
            }
            if (BaseClass.features.contains("screenTimeout")) {
                softAssert.assertTrue(screenTimeoutOption.isDisplayed(), "Screen Timeout option is displayed");
            }
            if (BaseClass.features.contains("favouriteContacts")) {
                softAssert.assertTrue(favouriteContactsOption.isDisplayed(), "Favourite Contacts option is displayed");
            }
            if (BaseClass.features.contains("unpair")) {
                softAssert.assertTrue(unpairOption.isDisplayed(), "Unpair option is displayed");
            }
            if (BaseClass.features.contains("Alarm")) {
                softAssert.assertTrue(alarmOption.isDisplayed(), "Alarm option is displayed");
                webdriverUtility.swipeByElements(driver, alarmOption, settingsPageLabel, 2);
            }
            if (BaseClass.features.contains("DND")) {
                softAssert.assertTrue(dNDOption.isDisplayed(), "DND option is displayed");
            }
            if (BaseClass.features.contains("weather")) {
                softAssert.assertTrue(weatherOption.isDisplayed(), "Weather option is displayed");
            }
            if (BaseClass.features.contains("music")) {
                softAssert.assertTrue(musicOption.isDisplayed(), "Music option is displayed");
            }
            if (BaseClass.features.contains("bluetoothCalling")) {
                softAssert.assertTrue(bluetoothCallingOption.isDisplayed(), "Bluetooth Calling option is displayed");
            }
            if (BaseClass.features.contains("updateWatch")) {
                softAssert.assertTrue(updateWatchOption.isDisplayed(), "Update Watch option is displayed");
            }
            if (BaseClass.features.contains("General")) {
                softAssert.assertTrue(generalOption.isDisplayed(), "general option is displayed");
            }
            if (BaseClass.features.contains("BatteryOptimization")) {
                generalOption.click();
                webdriverUtility.swipeByElements(driver, generalOption, settingsPageLabel, 2);
                softAssert.assertTrue(batteryOptimizationOption.isDisplayed(), "Battery Optimization option is displayed");
            }
            if (BaseClass.features.contains("reportError")) {
                softAssert.assertTrue(reportErrorOption.isDisplayed(), "Report Error option is displayed");
            }
            if (BaseClass.features.contains("About")) {
                softAssert.assertTrue(aboutOption.isDisplayed(), "About option is displayed");
            }
        } else if (OS.equalsIgnoreCase("IOS")) {
            softAssert.assertTrue(profilePictureImg.isDisplayed(), "Profile Image is displayed");
            softAssert.assertTrue(userName.isDisplayed(), "Username is displayed");
            softAssert.assertTrue(userLocation.isDisplayed(), "User Location is displayed");
            softAssert.assertTrue(turnOnOrOffNotifications.isDisplayed(), "Notification options are displayed");
            if (BaseClass.features.contains("Goals")) {
                softAssert.assertTrue(goalsOption.isDisplayed(), "Goals option is displayed");
                goalsOption.click();
                softAssert.assertTrue(stepGoalOption.isDisplayed(), "Step Goal option is displayed");
                softAssert.assertTrue(sleepGoalOption.isDisplayed(), "Sleep Goal option is displayed");
                softAssert.assertTrue(multiSportGoalOption.isDisplayed(), "Multi Sport Goal option is displayed");
                goalsOption.click();
            }
            if (BaseClass.features.contains("Health")) {
                softAssert.assertTrue(healthOption.isDisplayed(), "Health option is displayed");
            }
            if (BaseClass.features.contains("autoHR")) {
                healthOption.click();
                softAssert.assertTrue(autoHrOption.isDisplayed(), "Auto HR option is displayed");
            }
            if (BaseClass.features.contains("appleHealth")) {
                softAssert.assertTrue(googleFitOrAppleHealthOption.isDisplayed(), "Apple Health option is displayed");
            }
            if (BaseClass.features.contains("sedentaryAlert")) {
                softAssert.assertTrue(sedentaryAlertOption.isDisplayed(), "Sedentary Alert option is displayed");
            }
            if (BaseClass.features.contains("myCycleReminders")) {
                softAssert.assertTrue(myCycleRemindersOption.isDisplayed(), "My Cycle Reminders option is displayed");
            }
            if (BaseClass.features.contains("hydrationReminder")) {
                softAssert.assertTrue(hydrationReminderOption.isDisplayed(), "Hydration option is displayed");
            }
            if (BaseClass.features.contains("highHRAlert")) {
                softAssert.assertTrue(highHrAlertOption.isDisplayed(), "High HR Alert option is displayed");
                healthOption.click();
            }
            if (BaseClass.features.contains("MyWatch")) {
                softAssert.assertTrue(myWatchOption.isDisplayed(), "My Watch option is displayed");
            }
            if (BaseClass.features.contains("findYourWatch")) {
                myWatchOption.click();
                softAssert.assertTrue(findYourWatchOption.isDisplayed(), "Find Your Watch option is displayed");
            }
            if (BaseClass.features.contains("unitSystem")) {
                softAssert.assertTrue(unitSystemOption.isDisplayed(), "Unit System option is displayed");
            }
            if (BaseClass.features.contains("liftToView")) {
                softAssert.assertTrue(liftToViewOption.isDisplayed(), "Lift to view option is displayed");
            }
            if (BaseClass.features.contains("screenTimeout")) {
                softAssert.assertTrue(screenTimeoutOption.isDisplayed(), "Screen Timeout option is displayed");
            }
            if (BaseClass.features.contains("favouriteContacts")) {
                softAssert.assertTrue(favouriteContactsOption.isDisplayed(), "Favourite Contacts option is displayed");
            }
            if (BaseClass.features.contains("unpair")) {
                softAssert.assertTrue(unpairOption.isDisplayed(), "Unpair option is displayed");
            }
            if (BaseClass.features.contains("Alarm")) {
                softAssert.assertTrue(alarmOption.isDisplayed(), "Alarm option is displayed");
            }
            if (BaseClass.features.contains("DND")) {
                softAssert.assertTrue(dNDOption.isDisplayed(), "DND option is displayed");
            }
            if (BaseClass.features.contains("weather")) {
                softAssert.assertTrue(weatherOption.isDisplayed(), "Weather option is displayed");
            }
            if (BaseClass.features.contains("bluetoothCalling")) {
                softAssert.assertTrue(bluetoothCallingOption.isDisplayed(), "Bluetooth Calling option is displayed");
            }
            if (BaseClass.features.contains("updateWatch")) {
                softAssert.assertTrue(updateWatchOption.isDisplayed(), "Update Watch option is displayed");
                myWatchOption.click();
            }
            if (BaseClass.features.contains("General")) {
                softAssert.assertTrue(generalOption.isDisplayed(), "general option is displayed");
            }
            if (BaseClass.features.contains("reportError")) {
                generalOption.click();
                softAssert.assertTrue(reportErrorOption.isDisplayed(), "Report Error option is displayed");
            }
            if (BaseClass.features.contains("About")) {
                softAssert.assertTrue(aboutOption.isDisplayed(), "About option is displayed");
            }
        }
    }

    public void clickOnMyWatchOptionAndClickOnUnpairOption(WebDriver driver, String OS){
        myWatchOption.click();
        if (OS.equalsIgnoreCase("Android")) {
            webdriverUtility = new AndroidWebDriverUtility();
            webdriverUtility.swipeByElements(driver, unitSystemOption, settingsPageLabel, 2);
        } else if (OS.equalsIgnoreCase("IOS")) {
            webdriverUtility = new IOSWebDriverUtility();
            webdriverUtility.swipeByElements(driver, unitSystemOption, settingsPageLabel, 2);
        }
        unpairOption.click();
    }

    public void clickOnGoalsOptionAndThenStepGoalOption(){
        goalsOption.click();
        stepGoalOption.click();
    }

    public void clickOnGoalsOptionAndThenSleepGoalOption(){
        goalsOption.click();
        sleepGoalOption.click();
    }

    public void clickOnGoalsOptionAndThenMultiSportGoalOption(){
        goalsOption.click();
        multiSportGoalOption.click();
    }

    public void clickOnMyWatchOptionAndThenUnitSystemOption(){
        myWatchOption.click();
        unitSystemOption.click();
    }

    public void clickOnMyWatchOptionAndClickOnLiftToViewOption(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")) {
            myWatchOption.click();
            webdriverUtility = new AndroidWebDriverUtility();
            webdriverUtility.swipeByElements(driver, unitSystemOption, healthOption, 2);
            liftToViewOption.click();
        } else if (OS.equalsIgnoreCase("IOS")) {
            myWatchOption.click();
            liftToViewOption.click();
        }
    }

    public void clickOnHeathOption(){
        healthOption.click();
    }

    public void clickOnSedentaryAlertOption(){
        sedentaryAlertOption.click();
    }

    public void clickOnHealthAndClickOnSedentaryAlertOption(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            webdriverUtility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            webdriverUtility=new IOSWebDriverUtility();
        }
        healthOption.click();
        webdriverUtility.swipeByElements(driver, autoHrOption, goalsOption, 2);
        sedentaryAlertOption.click();
    }

    public void clickOnMyWatchAndClickOnFindYourWatch(){
        myWatchOption.click();
        findYourWatchOption.click();
    }

    public void clickOnMyWatchOptionAndClickOnAlarmOption(WebDriver driver, String OS){
        myWatchOption.click();
        if (OS.equalsIgnoreCase("Android")) {
            webdriverUtility = new AndroidWebDriverUtility();
            webdriverUtility.swipeByElements(driver, unitSystemOption, settingsPageLabel, 2);
        } if (OS.equalsIgnoreCase("IOS")){
            webdriverUtility=new IOSWebDriverUtility();
            webdriverUtility.swipeByElements(driver, unitSystemOption, settingsPageLabel, 2);
        }
        alarmOption.click();
    }

    public void clickOnAboutOption(){
        aboutOption.click();
    }

    public void clickOnGeneralOptionAndThenClickOnReportErrorOption(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            webdriverUtility=new AndroidWebDriverUtility();
            generalOption.click();
            webdriverUtility.swipeByElements(driver, generalOption, healthOption, 2);
            reportErrorOption.click();
        } else if (OS.equalsIgnoreCase("IOS")) {
            generalOption.click();
            reportErrorOption.click();
        }
    }

    public void checkConfirmationToastMessageForChanges(){
        Assert.assertEquals(successfulToastMessage.getText(), "Changes saved successfully");
    }

    public void checkConfirmationToastMessageForErrorReport(){
        Assert.assertEquals(reportSentToastMessage.getText(), "Report sent successfully");
    }

    public void checkIfErrorReportHasBeenSentSuccessfully(WebDriver driver){
        try {
            WebDriverUtility.waitForElementToBeVisible(driver, successfulToastMessage, 10);
        } catch (Exception e){
            e.printStackTrace();
        }
        Assert.assertEquals(successfulToastMessage.getText(), "Report sent successfully");
    }

    public void clickOnAutoHRAlertOption(){
        autoHrOption.click();
    }

    public void checkIfSettingsPageIsDisplayed(){
        Assert.assertTrue(settingsPageLabel.isDisplayed());
    }

    public void clickOnGoalOption(){
        goalsOption.click();
    }

    public void clickOnStepGoalOption(){
        stepGoalOption.click();
    }

    public void clickOnSleepGoalOption(){
        sleepGoalOption.click();
    }

    public void clickOnMultiSportGoalOption(){
        multiSportGoalOption.click();
    }

    public void clickOnMyWatchOptionAndThenClickOnFavouriteContactsOption(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")) {
            webdriverUtility = new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")){
            webdriverUtility=new IOSWebDriverUtility();
        }
        WebDriverUtility.waitForElementToBeVisible(driver, myWatchOption, 10);
        myWatchOption.click();
        webdriverUtility.swipeByElements(driver, unitSystemOption, healthOption, 2);
        favouriteContactsOption.click();
    }

    public void checkIfContactsSyncedSuccessfully(WebDriver driver) {
        try {
            WebDriverUtility.waitForElementToBeVisible(driver, successfulToastMessage, 10);
        } catch (Exception e){
            e.printStackTrace();
        }
        Assert.assertEquals(successfulToastMessage.getText(), "Favourite contacts synced successfully");
    }

    public void clickOnMyWatchOptionAndThenClickOnScreenTimeoutOption(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            webdriverUtility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            webdriverUtility=new IOSWebDriverUtility();
        }
        myWatchOption.click();
        webdriverUtility.swipeByElements(driver, unitSystemOption, healthOption, 2);
        screenTimeoutOption.click();
    }

    public void clickOnMyWatchOptionAndThenClickOnBluetoothCallingOption(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            webdriverUtility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            webdriverUtility=new IOSWebDriverUtility();
        }
        myWatchOption.click();
        webdriverUtility.swipeByElements(driver, unitSystemOption, goalsOption, 2);
        webdriverUtility.swipeByElements(driver, unpairOption, settingsPageLabel, 2);
        bluetoothCallingOption.click();
    }

    public void clickOnDashboardBtn(){
        dashboardBtn.click();
    }

    public String returnTheGenderOfTheUser(){
        return profilePictureImg.getAttribute("content-desc");
    }

    public void clickOnMyWatchOptionAndThenClickOnUpdateWatchOption(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            webdriverUtility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            webdriverUtility=new IOSWebDriverUtility();
        }
        myWatchOption.click();
        webdriverUtility.swipeByElements(driver, unitSystemOption, goalsOption, 2);
        webdriverUtility.swipeByElements(driver, unpairOption, settingsPageLabel, 2);
        updateWatchOption.click();
    }

    public void clickOnMyWatchOptionAndClickOnAutoTemperatureOption(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            webdriverUtility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            webdriverUtility=new IOSWebDriverUtility();
        }
        myWatchOption.click();
        webdriverUtility.swipeByElements(driver, unitSystemOption, settingsPageLabel, 2);
        autoTemperatureOption.click();
    }

    public void clickOnMyWatchOptionAndClickOnTemperatureUnitSystemOption(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            webdriverUtility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            webdriverUtility=new IOSWebDriverUtility();
        }
        myWatchOption.click();
        webdriverUtility.swipeByElements(driver, unitSystemOption, notificationIcon, 2);
        temperatureUnitSystemOption.click();
    }
}