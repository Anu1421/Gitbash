package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class FirmwareUpdatePage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Firmware Update'")
    @FindAll({
            @FindBy(id="com.titan.fastrack.reflex:id/no_update_title")

    })private WebElement pageTitle;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Firmware Update']/following-sibling::XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id="com.titan.fastrack.reflex:id/no_update_text")
    })private WebElement updateMessage;
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Firmware Update']/following-sibling::XCUIElementTypeOther/XCUIElementTypeButton")
    @FindAll({
            @FindBy(id="com.titan.fastrack.reflex:id/no_update_ok_button")
    }) private WebElement okOrUpdateBtn;

    public FirmwareUpdatePage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getPageTitle() {
        return pageTitle;
    }

    public WebElement getUpdateMessage() {
        return updateMessage;
    }

    public WebElement getOkOrUpdateBtn() {
        return okOrUpdateBtn;
    }

    public void checkIfUserLandsInFirmwareUpdatePage(String OS){
        if (OS.equalsIgnoreCase("Android")){
            Assert.assertEquals(pageTitle.getText(), "Firmware Update");
        } else if (OS.equalsIgnoreCase("IOS")) {
            Assert.assertEquals(pageTitle.getAttribute("name"), "Firmware Update");
        }
    }

    public void checkIfNoUpdateFoundMessageIsDisplayed(String OS){
        if (OS.equalsIgnoreCase("Android")){
            Assert.assertEquals(updateMessage.getText(), "Your watch has no firmware update available.");
        } else if (OS.equalsIgnoreCase("IOS")) {
            Assert.assertEquals(updateMessage.getAttribute("name"), "No update found");
        }
    }
}