package objectrepository;

import genericutility.AndroidWebDriverUtility;
import genericutility.WebDriverUtility;
import genericutility.IOSWebDriverUtility;
import io.appium.java_client.pagefactory.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

public class MultiSportTimelinePage {

    WebDriverUtility utility;
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic back Img'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Multi Sport'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/textView3"),
            @FindBy(id = "com.titan.smartworld:id/textView3")
    }) private WebElement multiSportPageTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'ic_calendercommon'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/ivCalender"),
            @FindBy(id = "com.titan.smartworld:id/ivCalender")
    }) private WebElement calendarIcon;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'All'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/all"),
            @FindBy(id = "com.titan.smartworld:id/all")
    }) private WebElement allMultiSportTab;

    @iOSXCUITFindBy(iOSNsPredicate = "value == '  This Week  '")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/thisWeek"),
            @FindBy(id = "com.titan.smartworld:id/thisWeek")
    }) private WebElement thisWeekMultisportTab;

    @iOSXCUITFindBy(iOSNsPredicate = "value == '  This Month  '")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/thisMonth"),
            @FindBy(id = "com.titan.smartworld:id/thisMonth")
    }) private WebElement thisMonthMultisportTab;

        @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[starts-with(@name,'Activit')]/preceding-sibling::XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(xpath = "//android.widget.TextView[@text='Activities']/../android.widget.TextView[1]"),
            @FindBy(xpath = "//android.widget.TextView[@text='Activity']/../android.widget.TextView[1]")
    }) private WebElement activitiesCount;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Calories']/preceding-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.widget.TextView[@text='Calories']/../android.widget.TextView[1]") private WebElement caloriesCount;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Steps']/preceding-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.widget.TextView[@text='Steps']/../android.widget.TextView[1]") private WebElement stepsCount;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Steps']/ancestor::XCUIElementTypeCell/following-sibling::XCUIElementTypeCell[1]//XCUIElementTypeStaticText[1]")
    @FindAll({
            @FindBy(xpath = "//android.widget.TextView[@text='m']/preceding-sibling::android.widget.TextView"),
            @FindBy(xpath = "//android.widget.TextView[@text='km']/preceding-sibling::android.widget.TextView"),
            @FindBy(xpath = "//android.widget.TextView[@text='mi']/preceding-sibling::android.widget.TextView")
    }) private WebElement distanceCount;

    @FindBy(xpath = "//android.view.ViewGroup[@resource-id='com.titan.fastrack.reflex:id/clTotalDistance']/android.widget.TextView[2]") private WebElement unitOfDistance;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Active Time']/preceding-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.widget.TextView[@text='Active Time']/../android.widget.TextView[1]") private WebElement activeTime;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='ic_calendercommon']//following-sibling::XCUIElementTypeTable/XCUIElementTypeCell[1]//XCUIElementTypeTable//XCUIElementTypeStaticText[2]")
    @FindBy(id = "com.titan.fastrack.reflex:id/tvActivityName") private WebElement firstActivity;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Morning')]") private List<WebElement> morningMultiSports;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Afternoon')]") private List<WebElement> afternoonMultiSports;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Evening')]") private List<WebElement> eveningMultiSports;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Night')]") private List<WebElement> nightMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Running'") private List<WebElement> allRunningMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Walking'") private List<WebElement> allWalkingMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Cycling'") private List<WebElement> allCyclingMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Skipping'") private List<WebElement> allSkippingMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Climbing'") private List<WebElement> allClimbingMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Football'") private List<WebElement> allFootballMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Basketball'") private List<WebElement> allBasketballMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Badminton'") private List<WebElement> allBadmintonMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Cricket'") private List<WebElement> allCricketMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Dancing'") private List<WebElement> allDancingMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Workout'") private List<WebElement> allWorkoutMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Yoga'") private List<WebElement> allYogaMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Golf'") private List<WebElement> allGolfMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Rugby'") private List<WebElement> allRugbyMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Tennis'") private List<WebElement> allTennisMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Water Sports'") private List<WebElement> allWaterSportsMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Softball'") private List<WebElement> allSoftballMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Skiing'") private List<WebElement> allSkiingMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Free Training'") private List<WebElement> allFreeTrainingMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Rafting'") private List<WebElement> allRaftingMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Hiking'") private List<WebElement> allHikingMultiSports;

    @iOSXCUITFindBy(iOSNsPredicate = "name ENDSWITH 'Spinning'") private List<WebElement> allSpinningMultiSports;

    public MultiSportTimelinePage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getMultiSportPageTitle() {
        return multiSportPageTitle;
    }

    public WebElement getCalendarIcon() {
        return calendarIcon;
    }

    public WebElement getAllMultiSportTab() {
        return allMultiSportTab;
    }

    public WebElement getThisWeekMultisportTab() {
        return thisWeekMultisportTab;
    }

    public WebElement getThisMonthMultisportTab() {
        return thisMonthMultisportTab;
    }

    public WebElement getActivitiesCount() {
        return activitiesCount;
    }

    public WebElement getCaloriesCount() {
        return caloriesCount;
    }

    public WebElement getStepsCount() {
        return stepsCount;
    }

    public WebElement getDistanceCount() {
        return distanceCount;
    }

    public WebElement getUnitOfDistance() {
        return unitOfDistance;
    }

    public WebElement getActiveTime() {
        return activeTime;
    }

    public WebElement getFirstActivity() {
        return firstActivity;
    }

    public List<WebElement> getMorningMultiSports() {
        return morningMultiSports;
    }

    public List<WebElement> getAfternoonMultiSports() {
        return afternoonMultiSports;
    }

    public List<WebElement> getEveningMultiSports() {
        return eveningMultiSports;
    }

    public List<WebElement> getNightMultiSports() {
        return nightMultiSports;
    }

    public List<WebElement> getAllRunningMultiSports() {
        return allRunningMultiSports;
    }

    public List<WebElement> getAllWalkingMultiSports() {
        return allWalkingMultiSports;
    }

    public List<WebElement> getAllCyclingMultiSports() {
        return allCyclingMultiSports;
    }

    public List<WebElement> getAllSkippingMultiSports() {
        return allSkippingMultiSports;
    }

    public List<WebElement> getAllClimbingMultiSports() {
        return allClimbingMultiSports;
    }

    public List<WebElement> getAllFootballMultiSports() {
        return allFootballMultiSports;
    }

    public List<WebElement> getAllBasketballMultiSports() {
        return allBasketballMultiSports;
    }

    public List<WebElement> getAllBadmintonMultiSports() {
        return allBadmintonMultiSports;
    }

    public List<WebElement> getAllCricketMultiSports() {
        return allCricketMultiSports;
    }

    public List<WebElement> getAllDancingMultiSports() {
        return allDancingMultiSports;
    }

    public List<WebElement> getAllWorkoutMultiSports() {
        return allWorkoutMultiSports;
    }

    public List<WebElement> getAllYogaMultiSports() {
        return allYogaMultiSports;
    }

    public List<WebElement> getAllGolfMultiSports() {
        return allGolfMultiSports;
    }

    public List<WebElement> getAllRugbyMultiSports() {
        return allRugbyMultiSports;
    }

    public List<WebElement> getAllTennisMultiSports() {
        return allTennisMultiSports;
    }

    public List<WebElement> getAllWaterSportsMultiSports() {
        return allWaterSportsMultiSports;
    }

    public List<WebElement> getAllSoftballMultiSports() {
        return allSoftballMultiSports;
    }

    public List<WebElement> getAllSkiingMultiSports() {
        return allSkiingMultiSports;
    }

    public List<WebElement> getAllFreeTrainingMultiSports() {
        return allFreeTrainingMultiSports;
    }

    public List<WebElement> getAllRaftingMultiSports() {
        return allRaftingMultiSports;
    }

    public List<WebElement> getAllHikingMultiSports() {
        return allHikingMultiSports;
    }

    public List<WebElement> getAllSpinningMultiSports() {
        return allSpinningMultiSports;
    }

    public void checkIfCalStepsDistAndActiveTimeAreDisplayed(WebDriver driver){
        WebDriverUtility.waitForElementToBeVisible(driver, activitiesCount, 10);
        Assert.assertTrue(activitiesCount.isDisplayed());
        Assert.assertTrue(caloriesCount.isDisplayed());
        Assert.assertTrue(stepsCount.isDisplayed());
        Assert.assertTrue(distanceCount.isDisplayed());
        Assert.assertTrue(activeTime.isDisplayed());
    }

    public void clickOnBackBtn(){
        backBtn.click();
    }

    public void checkIfUserLandsInMultiSportSummaryScreen(){
        Assert.assertTrue(multiSportPageTitle.isDisplayed());
    }

    public void clickOnThisWeekTab(){
        thisWeekMultisportTab.click();
    }

    public void clickOnThisMonthTab(){
        thisMonthMultisportTab.click();
    }

    public void clickOnFirstActivity(){
        firstActivity.click();
    }

    public int fetchTheCountOfAllMultiSportsPerformed(){
        ArrayList<WebElement> allSports=new ArrayList<>();
        allSports.addAll(morningMultiSports);
        allSports.addAll(afternoonMultiSports);
        allSports.addAll(eveningMultiSports);
        allSports.addAll(nightMultiSports);
        int size = allSports.size();
        return size;
    }

    public void clickOnFirstRunningMultiSport(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            utility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            utility=new IOSWebDriverUtility();
        }
        utility.scrollToElement(driver, "down", "iOSNsPredicate", "name ENDSWITH 'Running'");
        allRunningMultiSports.get(0).click();
    }

    public void clickOnFirstWalkingMultiSport(){
        allWalkingMultiSports.get(0).click();
    }

    public void clickOnFirstSkippingMultiSport(){
        allSkippingMultiSports.get(0).click();
    }

    public void clickOnFirstHikingActivity(){
        allHikingMultiSports.get(0).click();
    }

    public void clickOnFirstBasketballActivity(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            utility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            utility=new IOSWebDriverUtility();
        }
        utility.scrollToElement(driver, "down", "iOSNsPredicate", "name ENDSWITH 'Basketball'");
        allBasketballMultiSports.get(0).click();
    }

    public void clickOnFirstFootballActivity(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            utility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            utility=new IOSWebDriverUtility();
        }
        utility.scrollToElement(driver, "down", "iOSNsPredicate", "name ENDSWITH 'Football'");
        allFootballMultiSports.get(0).click();
    }

    public void clickOnFirstCricketActivity(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            utility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            utility=new IOSWebDriverUtility();
        }
        utility.scrollToElement(driver, "down", "iOSNsPredicate", "name ENDSWITH 'Cricket'");
        allCricketMultiSports.get(0).click();
    }

    public void clickOnFirstYogaActivity(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            utility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            utility=new IOSWebDriverUtility();
        }
        utility.scrollToElement(driver, "down", "iOSNsPredicate", "name ENDSWITH 'Yoga'");
        allYogaMultiSports.get(0).click();
    }

    public void clickOnFirstCyclingActivity(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            utility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            utility=new IOSWebDriverUtility();
        }
        utility.scrollToElement(driver, "down", "iOSNsPredicate", "name ENDSWITH 'Cycling'");
        allCyclingMultiSports.get(0).click();
    }

    public void clickOnFirstSpinningActivity(){
        allSpinningMultiSports.get(0).click();
    }

    public void clickOnFirstDancingActivity(){
        allDancingMultiSports.get(0).click();
    }

    public void clickOnFirstRugbyActivity(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            utility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            utility=new IOSWebDriverUtility();
        }
        utility.scrollToElement(driver, "down", "iOSNsPredicate", "name ENDSWITH 'Rugby'");
        allRugbyMultiSports.get(0).click();
    }

    public void clickOnFirstFreeTrainingActivity(){
        allFreeTrainingMultiSports.get(0).click();
    }

    public String fetchTheUnitOfDistance(){
        return unitOfDistance.getText();
    }
}