package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UpdateWatchFirmwarePage {
    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Firmware Update'") private WebElement pageTitle;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Firmware Update']/following-sibling::XCUIElementTypeStaticText") private WebElement updateMessage;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'OK'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/up_to_date_ok_button"),
            @FindBy(id = "com.titan.smartworld:id/up_to_date_ok_button")
    }) private WebElement okBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Retry'") private WebElement retryBtn;

    public UpdateWatchFirmwarePage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getPageTitle() {
        return pageTitle;
    }

    public WebElement getUpdateMessage() {
        return updateMessage;
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getOkBtn() {
        return okBtn;
    }

    public WebElement getRetryBtn() {
        return retryBtn;
    }

    public void clickOnOkButton(){
        okBtn.click();
    }
}