package objectrepository;

import genericutility.AndroidWebDriverUtility;
import genericutility.WebDriverUtility;
import genericutility.IOSWebDriverUtility;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class AddSymptomsLogPopUp {
    WebDriverUtility utility;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='close']/preceding-sibling::XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title_view"),
            @FindBy(id = "com.titan.smartworld:id/title_view")
    }) private WebElement popUpTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'close'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closePopUpBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Symptoms'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_symptoms"),
            @FindBy(id = "com.titan.smartworld:id/tv_symptoms")
    }) private WebElement symptomsSection;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Period Flow'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_period_flow"),
            @FindBy(id = "com.titan.smartworld:id/tv_period_flow")
    }) private WebElement periodFlowSection;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Light Flow'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_light_flow"),
            @FindBy(id = "com.titan.smartworld:id/iv_light_flow")
    }) private WebElement lightFlowOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Medium Flow'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_medium_flow"),
            @FindBy(id = "com.titan.smartworld:id/iv_medium_flow")
    }) private WebElement mediumFlowOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Heavy Flow'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_heavy_flow"),
            @FindBy(id = "com.titan.smartworld:id/iv_heavy_flow")
    }) private WebElement heavyFlowOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Physical Signs'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_physical_sign"),
            @FindBy(id = "com.titan.smartworld:id/tv_physical_sign")
    }) private WebElement physicalSignsSection;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Bloating'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_bloating"),
            @FindBy(id = "com.titan.smartworld:id/iv_bloating")
    }) private WebElement bloatingPhysicalSignOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Tender Breasts'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_tender_breast"),
            @FindBy(id = "com.titan.smartworld:id/iv_tender_breast")
    }) private WebElement tenderBreastPhysicalSignOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Abdominal Cramps'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_abdominal_cramps"),
            @FindBy(id = "com.titan.smartworld:id/iv_abdominal_cramps")
    }) private WebElement abdominalCrampsPhysicalSignOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Diarrhoea'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_diarrhoea"),
            @FindBy(id = "com.titan.smartworld:id/iv_diarrhoea")
    }) private WebElement diarrhoeaPhysicalSignOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Acne'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_acne"),
            @FindBy(id = "com.titan.smartworld:id/iv_acne")
    }) private WebElement acnePhysicalSignOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Head Aches'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_headaches"),
            @FindBy(id = "com.titan.smartworld:id/iv_headaches")
    }) private WebElement headAchesPhysicalSignOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Constipation'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_constipation"),
            @FindBy(id = "com.titan.smartworld:id/iv_constipation")
    }) private WebElement constipationPhysicalSignOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Back Pain'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_backpain"),
            @FindBy(id = "com.titan.smartworld:id/iv_backpain")
    }) private WebElement backPainPhysicalSignOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Leg Cramps'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_legcramps"),
            @FindBy(id = "com.titan.smartworld:id/iv_legcramps")
    }) private WebElement legCrampsPhysicalSignOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Tiredness'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_tiredness"),
            @FindBy(id = "com.titan.smartworld:id/iv_tiredness")
    }) private WebElement tirednessPhysicalSignOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Mood'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_mood"),
            @FindBy(id = "com.titan.smartworld:id/tv_mood")
    }) private WebElement moodSection;

    @iOSXCUITFindBy(iOSNsPredicate = "label BEGINSWITH 'ic happy'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_mood1"),
            @FindBy(id = "com.titan.smartworld:id/iv_mood1")
    }) private WebElement mood1;

    @iOSXCUITFindBy(iOSNsPredicate = "label BEGINSWITH 'ic relaxed'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_mood2"),
            @FindBy(id = "com.titan.smartworld:id/iv_mood2")
    }) private WebElement mood2;

    @iOSXCUITFindBy(iOSNsPredicate = "label BEGINSWITH 'ic angry'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_mood3"),
            @FindBy(id = "com.titan.smartworld:id/iv_mood3")
    }) private WebElement mood3;

    @iOSXCUITFindBy(iOSNsPredicate = "label BEGINSWITH 'ic neutral'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_mood4"),
            @FindBy(id = "com.titan.smartworld:id/iv_mood4")
    }) private WebElement mood4;

    @iOSXCUITFindBy(iOSNsPredicate = "label BEGINSWITH 'ic sad'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_mood5"),
            @FindBy(id = "com.titan.smartworld:id/iv_mood5")
    }) private WebElement mood5;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Sexual Activity'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_sexual_activity"),
            @FindBy(id = "com.titan.smartworld:id/tv_sexual_activity")
    }) private WebElement sexualActivitySection;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Protected sex'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_protected_sex"),
            @FindBy(id = "com.titan.smartworld:id/iv_protected_sex")
    }) private WebElement protectedSexOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Unprotected Sex'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_unprotected_sex"),
            @FindBy(id = "com.titan.smartworld:id/iv_unprotected_sex")
    }) private WebElement unprotectedSexOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Cervical discharge'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_cervical_discharge"),
            @FindBy(id = "com.titan.smartworld:id/tv_cervical_discharge")
    }) private WebElement cervicalDischargeSection;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Watery'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_watery"),
            @FindBy(id = "com.titan.smartworld:id/iv_watery")
    }) private WebElement wateryCervicalDischarge;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Creamy'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_creamy"),
            @FindBy(id = "com.titan.smartworld:id/iv_creamy")
    }) private WebElement creamyCervicalDischarge;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Sticky'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_sticky"),
            @FindBy(id = "com.titan.smartworld:id/iv_sticky")
    }) private WebElement stickyCervicalDischarge;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Dry'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_dry"),
            @FindBy(id = "com.titan.smartworld:id/iv_dry")
    }) private WebElement dryCervicalDischarge;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Egg white'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_egg_white"),
            @FindBy(id = "com.titan.smartworld:id/iv_egg_white")
    }) private WebElement eggWhiteCervicalDischarge;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Other'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/iv_other"),
            @FindBy(id = "com.titan.smartworld:id/iv_other")
    }) private WebElement otherCervicalDischarge;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Medications'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_medication"),
            @FindBy(id = "com.titan.smartworld:id/tv_medication")
    }) private WebElement medicationSection;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Medications']/parent::XCUIElementTypeCell/following-sibling::XCUIElementTypeCell/XCUIElementTypeTextView")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/et_medication"),
            @FindBy(id = "com.titan.smartworld:id/et_medication")
    }) private WebElement medicationTextField;

    @iOSXCUITFindBy(iOSNsPredicate = "label ENDSWITH '/120  '")
    @FindBy(xpath = "//android.widget.TextView[@text='/120']") private WebElement maxCharactersCountInMedicationTextField;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Save'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/btn_save"),
            @FindBy(id = "com.titan.smartworld:id/btn_save")
    }) private WebElement saveBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'return'") private WebElement returnBtn;

    public AddSymptomsLogPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getPopUpTitle() {
        return popUpTitle;
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getSymptomsSection() {
        return symptomsSection;
    }

    public WebElement getPeriodFlowSection() {
        return periodFlowSection;
    }

    public WebElement getLightFlowOption() {
        return lightFlowOption;
    }

    public WebElement getMediumFlowOption() {
        return mediumFlowOption;
    }

    public WebElement getHeavyFlowOption() {
        return heavyFlowOption;
    }

    public WebElement getPhysicalSignsSection() {
        return physicalSignsSection;
    }

    public WebElement getBloatingPhysicalSignOption() {
        return bloatingPhysicalSignOption;
    }

    public WebElement getTenderBreastPhysicalSignOption() {
        return tenderBreastPhysicalSignOption;
    }

    public WebElement getAbdominalCrampsPhysicalSignOption() {
        return abdominalCrampsPhysicalSignOption;
    }

    public WebElement getDiarrhoeaPhysicalSignOption() {
        return diarrhoeaPhysicalSignOption;
    }

    public WebElement getAcnePhysicalSignOption() {
        return acnePhysicalSignOption;
    }

    public WebElement getHeadAchesPhysicalSignOption() {
        return headAchesPhysicalSignOption;
    }

    public WebElement getConstipationPhysicalSignOption() {
        return constipationPhysicalSignOption;
    }

    public WebElement getBackPainPhysicalSignOption() {
        return backPainPhysicalSignOption;
    }

    public WebElement getLegCrampsPhysicalSignOption() {
        return legCrampsPhysicalSignOption;
    }

    public WebElement getTirednessPhysicalSignOption() {
        return tirednessPhysicalSignOption;
    }

    public WebElement getMoodSection() {
        return moodSection;
    }

    public WebElement getMood1() {
        return mood1;
    }

    public WebElement getMood2() {
        return mood2;
    }

    public WebElement getMood3() {
        return mood3;
    }

    public WebElement getMood4() {
        return mood4;
    }

    public WebElement getMood5() {
        return mood5;
    }

    public WebElement getSexualActivitySection() {
        return sexualActivitySection;
    }

    public WebElement getProtectedSexOption() {
        return protectedSexOption;
    }

    public WebElement getUnprotectedSexOption() {
        return unprotectedSexOption;
    }

    public WebElement getCervicalDischargeSection() {
        return cervicalDischargeSection;
    }

    public WebElement getWateryCervicalDischarge() {
        return wateryCervicalDischarge;
    }

    public WebElement getCreamyCervicalDischarge() {
        return creamyCervicalDischarge;
    }

    public WebElement getStickyCervicalDischarge() {
        return stickyCervicalDischarge;
    }

    public WebElement getDryCervicalDischarge() {
        return dryCervicalDischarge;
    }

    public WebElement getEggWhiteCervicalDischarge() {
        return eggWhiteCervicalDischarge;
    }

    public WebElement getOtherCervicalDischarge() {
        return otherCervicalDischarge;
    }

    public WebElement getMedicationSection() {
        return medicationSection;
    }

    public WebElement getMedicationTextField() {
        return medicationTextField;
    }

    public WebElement getMaxCharactersCountInMedicationTextField() {
        return maxCharactersCountInMedicationTextField;
    }

    public WebElement getSaveBtn() {
        return saveBtn;
    }

    public WebElement getReturnBtn() {
        return returnBtn;
    }

    public void checkIfUserLandsInAddSymptomsLogPopUp(){
        Assert.assertTrue(popUpTitle.getText().contains("Add log"));
    }

    public void checkIfAllSectionsAreDisplayed(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            utility =new AndroidWebDriverUtility();
            Assert.assertTrue(symptomsSection.isDisplayed());
            Assert.assertTrue(physicalSignsSection.isDisplayed());
            utility.swipeByElements(driver, constipationPhysicalSignOption, lightFlowOption, 2);
            Assert.assertTrue(moodSection.isDisplayed());
            Assert.assertTrue(sexualActivitySection.isDisplayed());
            Assert.assertTrue(cervicalDischargeSection.isDisplayed());
            utility.swipeByElements(driver, cervicalDischargeSection, moodSection, 2);
            Assert.assertTrue(medicationSection.isDisplayed());
            Assert.assertTrue(maxCharactersCountInMedicationTextField.getText().equals("/120"));
            Assert.assertTrue(saveBtn.isDisplayed());
        } else if (OS.equalsIgnoreCase("IOS")) {
            utility =new IOSWebDriverUtility();
            Assert.assertTrue(symptomsSection.isDisplayed());
            Assert.assertTrue(physicalSignsSection.isDisplayed());
            utility.swipeScreen(driver, WebDriverUtility.Direction.UP);
//            Assert.assertTrue(moodSection.isDisplayed());
            Assert.assertTrue(sexualActivitySection.isDisplayed());
            Assert.assertTrue(cervicalDischargeSection.isDisplayed());
            Assert.assertTrue(medicationSection.isDisplayed());
            utility.swipeScreen(driver, WebDriverUtility.Direction.UP);
            Assert.assertTrue(maxCharactersCountInMedicationTextField.getAttribute("name").contains("/120"));
            Assert.assertTrue(saveBtn.isDisplayed());
        }
    }

    public void clickOnClosePopUpBtn(){
        closePopUpBtn.click();
    }

    public void clickOnSaveBtn(){
        saveBtn.click();
    }

    public void selectBloatingAsSymptom(){
        bloatingPhysicalSignOption.click();
    }

    public void swipeDownToMedicationsSection(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            utility =new AndroidWebDriverUtility();
            utility.swipeByElements(driver, symptomsSection, constipationPhysicalSignOption, 1);
        } else if (OS.equalsIgnoreCase("IOS")) {
            utility =new IOSWebDriverUtility();
            utility.swipe(driver, "down", 10, medicationSection);
        }
    }

    public void enterCharactersInMedicationsTextFieldAndClickOnSaveBtn(String medications){
        medicationTextField.click();
        medicationTextField.sendKeys(medications);
        returnBtn.click();
        saveBtn.click();
    }

    public int fetchTheCountOfCharactersEnteredInTheMedicationTextField(){
        return medicationTextField.getText().length();
    }

    public void enterCharactersInMedicationsTextField(String medications){
        medicationTextField.click();
        medicationTextField.clear();
        medicationTextField.sendKeys(medications);
    }
}