package objectrepository;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CountryCodePage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'back'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Country Code'") private WebElement pageTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "value == ' Search'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/search_bar"),
            @FindBy(id = "com.titan.smartworld:id/search_bar")
    }) private WebElement searchTextEdit;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'India'")
    @FindBy(xpath = "//android.widget.TextView[@text='India']") private WebElement selectIndia;

    public CountryCodePage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getPageTitle() {
        return pageTitle;
    }

    public WebElement getSearchTextEdit() {
        return searchTextEdit;
    }

    public WebElement getSelectIndia() {
        return selectIndia;
    }

    public void selectDesiredCountry(String countryName){
        searchTextEdit.sendKeys(countryName);
        selectIndia.click();
    }
}
