package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UnpairWatchPopUp {
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic close']/preceding-sibling::XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title_view"),
            @FindBy(id = "com.titan.smartworld:id/title_view")
    }) private WebElement popUpTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic close'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closePopUpBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'OK'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/allow_button"),
            @FindBy(id = "com.titan.smartworld:id/allow_button")
    }) private WebElement unpairWatchBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Cancel'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/deny_button"),
            @FindBy(id = "com.titan.smartworld:id/deny_button")
    }) private WebElement cancelUnpairWatchBtn;

    public UnpairWatchPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getUnpairWatchBtn() {
        return unpairWatchBtn;
    }

    public WebElement getCancelUnpairWatchBtn() {
        return cancelUnpairWatchBtn;
    }

    public WebElement getPopUpTitle() {
        return popUpTitle;
    }

    public void unpairWatchFromDevice(){
        unpairWatchBtn.click();
    }

    public void closeUnpairPopUp(){
        closePopUpBtn.click();
    }
}