package objectrepository;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DailyTasksPage {

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic back'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    })
    @FindBy(id = "com.titan.smartworld:id/back_button") private WebElement backBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'common_dailytask'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/icon"),
            @FindBy(id = "com.titan.smartworld:id/icon")
    }) private WebElement dailyTaskIcon;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Daily Tasks'")
    @FindBy(xpath = "//android.widget.TextView[@text='Daily Tasks']") private WebElement dailyTaskPageTitle;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic calendercommon']/preceding-sibling::XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/date_text"),
            @FindBy(id = "com.titan.smartworld:id/date_text")
    }) private WebElement dateText;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'path_8080'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/previous_icon"),
            @FindBy(id = "com.titan.smartworld:id/previous_icon")
    }) private WebElement previousDayBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'path_8081'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/next_icon"),
            @FindBy(id = "com.titan.smartworld:id/next_icon")
    }) private WebElement nextDayBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic calendercommon'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/calendar"),
            @FindBy(id = "com.titan.smartworld:id/calendar")
    }) private WebElement calendarIcon;

    public DailyTasksPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getDailyTaskIcon() {
        return dailyTaskIcon;
    }

    public WebElement getDailyTaskPageTitle() {
        return dailyTaskPageTitle;
    }

    public WebElement getDateText() {
        return dateText;
    }

    public WebElement getPreviousDayBtn() {
        return previousDayBtn;
    }

    public WebElement getNextDayBtn() {
        return nextDayBtn;
    }

    public WebElement getCalendarIcon() {
        return calendarIcon;
    }
}
