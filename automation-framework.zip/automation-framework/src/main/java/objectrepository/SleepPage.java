package objectrepository;

import com.fasterxml.jackson.databind.ser.Serializers;
import genericutility.BaseClass;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.omg.CORBA.PUBLIC_MEMBER;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class SleepPage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic back Img'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'ic_sleepCommon'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/icon"),
            @FindBy(id = "com.titan.smartworld:id/icon")
    }) private WebElement sleepIcon;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Sleep'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title"),
            @FindBy(id = "com.titan.smartworld:id/title")
    }) private WebElement pageTitle;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic calendercommon']/preceding-sibling::XCUIElementTypeOther[1]/XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/date_text"),
            @FindBy(id = "com.titan.smartworld:id/date_text")
    }) private WebElement currentDate;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic calendercommon'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/calendar"),
            @FindBy(id = "com.titan.smartworld:id/calendar")
    }) private WebElement calendarIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic calendercommon']/preceding-sibling::XCUIElementTypeOther[1]/XCUIElementTypeOther[1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/previous_icon"),
            @FindBy(id = "com.titan.smartworld:id/previous_icon")
    }) private WebElement previousBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic calendercommon']/preceding-sibling::XCUIElementTypeOther[1]/XCUIElementTypeOther[2]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/next_icon"),
            @FindBy(id = "com.titan.smartworld:id/next_icon")
    }) private WebElement nextBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Day'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/day"),
            @FindBy(id = "com.titan.smartworld:id/day")
    }) private WebElement dayBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Week'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/week"),
            @FindBy(id = "com.titan.smartworld:id/week")
    }) private WebElement weekBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Month'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/month"),
            @FindBy(id = "com.titan.smartworld:id/month")
    }) private WebElement monthBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Total Sleep']/preceding-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.widget.TextView[@text='Daily\n" +
            "Goal']/../android.widget.TextView[1]") private WebElement totalSleepDuration;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Avg Sleep']/preceding-sibling::XCUIElementTypeStaticText") private WebElement avgSleepDuration;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Daily Goal']/preceding-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.widget.TextView[@text='Total\n" +
            "Sleep']/../android.widget.TextView[1]") private WebElement dailySleepGoal;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Week Goal']/preceding-sibling::XCUIElementTypeStaticText") private WebElement weekSleepGoal;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Month Goal']/preceding-sibling::XCUIElementTypeStaticText") private WebElement monthSleepGoal;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Sleep Debt']/preceding-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.widget.TextView[@text='Sleep\n" +
            "Debt']/../android.widget.TextView[1]") private WebElement sleepDebt;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Sleep Debt']/following-sibling::XCUIElementTypeButton")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/sleep_debt_info"),
            @FindBy(id = "com.titan.smartworld:id/sleep_debt_info")
    }) private WebElement sleepDebtInfo;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Sleep Score']/preceding-sibling::XCUIElementTypeStaticText[1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/sleep_score_tv"),
            @FindBy(id = "com.titan.smartworld:id/sleep_score_tv")
    }) private WebElement sleepScore;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Avg. Sleep Score']/preceding-sibling::XCUIElementTypeStaticText[1]") private WebElement avgSleepScore;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Sleep Score']/preceding-sibling::XCUIElementTypeButton[1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/sleep_score_info"),
            @FindBy(id = "com.titan.smartworld:id/sleep_score_info")
    }) private WebElement sleepScoreInfo;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Deep Sleep']/preceding-sibling::XCUIElementTypeStaticText[1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/deep_sleep_value"),
            @FindBy(id = "com.titan.smartworld:id/deep_sleep_value")
    }) private WebElement deepSleepDuration;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Light Sleep']/preceding-sibling::XCUIElementTypeStaticText[1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/light_sleep_value"),
            @FindBy(id = "com.titan.smartworld:id/light_sleep_value")
    }) private WebElement lightSleepDuration;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Awake']/preceding-sibling::XCUIElementTypeStaticText[1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/awake_sleep_value"),
            @FindBy(id = "com.titan.smartworld:id/awake_sleep_value")
    }) private WebElement awakeDuration;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/rem_sleep_value"),
            @FindBy(id = "com.titan.smartworld:id/rem_sleep_value")
    }) private WebElement remSleepDuration;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/sleep_score_tv"),
            @FindBy(id = "com.titan.smartworld:id/sleep_score_tv")
    }) private WebElement sleepScoreValue;

    public SleepPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getSleepIcon() {
        return sleepIcon;
    }

    public WebElement getPageTitle() {
        return pageTitle;
    }

    public WebElement getCurrentDate() {
        return currentDate;
    }

    public WebElement getCalendarIcon() {
        return calendarIcon;
    }

    public WebElement getPreviousBtn() {
        return previousBtn;
    }

    public WebElement getNextBtn() {
        return nextBtn;
    }

    public WebElement getDayBtn() {
        return dayBtn;
    }

    public WebElement getWeekBtn() {
        return weekBtn;
    }

    public WebElement getMonthBtn() {
        return monthBtn;
    }

    public WebElement getTotalSleepDuration() {
        return totalSleepDuration;
    }

    public WebElement getAvgSleepDuration() {
        return avgSleepDuration;
    }

    public WebElement getDailySleepGoal() {
        return dailySleepGoal;
    }

    public WebElement getWeekSleepGoal() {
        return weekSleepGoal;
    }

    public WebElement getMonthSleepGoal() {
        return monthSleepGoal;
    }

    public WebElement getSleepDebt() {
        return sleepDebt;
    }

    public WebElement getSleepDebtInfo() {
        return sleepDebtInfo;
    }

    public WebElement getSleepScore() {
        return sleepScore;
    }

    public WebElement getAvgSleepScore() {
        return avgSleepScore;
    }

    public WebElement getSleepScoreInfo() {
        return sleepScoreInfo;
    }

    public WebElement getDeepSleepDuration() {
        return deepSleepDuration;
    }

    public WebElement getLightSleepDuration() {
        return lightSleepDuration;
    }

    public WebElement getAwakeDuration() {
        return awakeDuration;
    }

    public WebElement getRemSleepDuration() {
        return remSleepDuration;
    }

    public WebElement getSleepScoreValue() {
        return sleepScoreValue;
    }

    public void checkIfAllElementsInSleepPageAreDisplayed(){
        Assert.assertTrue(sleepIcon.isDisplayed());
        Assert.assertTrue(pageTitle.getText().equals("Sleep"));
        Assert.assertTrue(totalSleepDuration.isDisplayed());
        Assert.assertTrue(dailySleepGoal.isDisplayed());
        Assert.assertTrue(sleepDebt.isDisplayed());
        Assert.assertTrue(deepSleepDuration.isDisplayed());
        Assert.assertTrue(lightSleepDuration.isDisplayed());
        Assert.assertTrue(awakeDuration.isDisplayed());
        if (BaseClass.features.contains("REMSleep")) {
            Assert.assertTrue(remSleepDuration.isDisplayed());
        }
        Assert.assertTrue(sleepScore.isDisplayed());
    }

    public void clickOnSleepDebtInfoIcon(){
        sleepDebtInfo.click();
    }

    public void clickOnSleepScoreInfoIcon(){
        sleepScoreInfo.click();
    }

    public void clickOnPreviousBtn(){
        previousBtn.click();
    }

    public void checkIfUserLandsInPreviousDay(){
        Assert.assertTrue(currentDate.getText().equals("Yesterday"));
    }

    public void clickOnWeekTab(){
        weekBtn.click();
    }

    public void clickOnMonthTab(){
        monthBtn.click();
    }

    public void checkIfSleepScoreIsDisplayed(){
        Assert.assertTrue(sleepScore.isDisplayed());
    }

    public void checkIfSleepDebtIsDisplayed(){
        Assert.assertTrue(sleepDebt.isDisplayed());
    }

    public void checkIfUserLandsInSleepScreen(){
        Assert.assertTrue(pageTitle.getText().equals("Sleep"));
    }

    public void clickOnBackBtn(){
        backBtn.click();
    }

    public void clickOnCalendarIcon(){
        calendarIcon.click();
    }

    public void checkIfUserLandsInSelectedDateSleepPage(String date){
        Assert.assertEquals(currentDate.getText(), date);
    }

    public void checkIfSleepDebtInfoIconIsDisplayed(){
        Assert.assertTrue(sleepDebtInfo.isDisplayed());
    }

    public void checkIfSleepScoreInfoIconIsDisplayed(){
        Assert.assertTrue(sleepScoreInfo.isDisplayed());
    }

    public String fetchCurrentDateOrWeekOrMonth(){
        return currentDate.getText();
    }

    public void checkIfAvgSleepScoreIsDisplayed(){
        Assert.assertTrue(avgSleepScore.isDisplayed());
    }
}