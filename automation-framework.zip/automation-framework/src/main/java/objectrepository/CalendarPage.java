package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class CalendarPage {
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Button' AND type == 'XCUIElementTypeButton'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @FindBy(xpath = "//androidx.recyclerview.widget.RecyclerView[1]/android.widget.TextView") private WebElement yearText;

    @iOSXCUITFindBy(iOSNsPredicate = "label == '2022'")
    @FindBy(xpath = "//android.widget.TextView[@text='2022']") private WebElement year2022;

    @iOSXCUITFindBy(iOSNsPredicate = "label == '2023'")
    @FindBy(xpath = "//android.widget.TextView[@text='2023']") private WebElement year2023;

    @FindBy(xpath = "//androidx.recyclerview.widget.RecyclerView[2]/android.widget.TextView") private WebElement monthText;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'December'")
    @FindBy(xpath = "//android.widget.TextView[@text='December']") private WebElement decemberMonth;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'February'")
    @FindBy(xpath = "//android.widget.TextView[@text='February']") private WebElement februaryMonth;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'January'")
    @FindBy(xpath = "//android.widget.TextView[@text='January']") private WebElement januaryMonth;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'April'")
    @FindBy(xpath = "//android.widget.TextView[@text='April']") private WebElement aprilMonth;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Dec'")
    @FindBy(xpath = "//android.widget.TextView[@text='Dec']") private WebElement decemberInMonthView;

    @iOSXCUITFindBy(iOSNsPredicate = "label == '3'")
    @FindBy(xpath = "//android.widget.TextView[@text='3']") private WebElement date3;

    @iOSXCUITFindBy(iOSNsPredicate = "label == '5'")
    @FindBy(xpath = "//android.widget.TextView[@text='5']") private WebElement date5;
    @iOSXCUITFindBy(iOSNsPredicate = "label == '16'")
    @FindBy(xpath = "//android.widget.TextView[@text='16']") private WebElement date16;

    @iOSXCUITFindBy(iOSNsPredicate = "label == '18'")
    @FindBy(xpath = "//android.widget.TextView[@text='18']") private WebElement date18;

    @iOSXCUITFindBy(iOSNsPredicate = "label == '22'")
    @FindBy(xpath = "//android.widget.TextView[@text='22']") private WebElement date22;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'OK' AND type == 'XCUIElementTypeButton'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/okay_button"),
            @FindBy(id = "com.titan.smartworld:id/okay_button")
    }) private WebElement okBtn;

    public CalendarPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getYearText() {
        return yearText;
    }

    public WebElement getYear2022() {
        return year2022;
    }

    public WebElement getYear2023() {
        return year2023;
    }

    public WebElement getMonthText() {
        return monthText;
    }

    public WebElement getDecemberMonth() {
        return decemberMonth;
    }

    public WebElement getJanuaryMonth() {
        return januaryMonth;
    }

    public WebElement getAprilMonth() {
        return aprilMonth;
    }

    public WebElement getDecemberInMonthView() {
        return decemberInMonthView;
    }

    public WebElement getDate3() {
        return date3;
    }

    public WebElement getDate5() {
        return date5;
    }

    public WebElement getDate18() {
        return date18;
    }

    public WebElement getDate22() {
        return date22;
    }

    public WebElement getOkBtn() {
        return okBtn;
    }

    public void clickOnBackBtn(){
        backBtn.click();
    }

    public void clickOnYear2022MonthDecemberAndDate22AndOkBtn(){
        year2022.click();
        decemberMonth.click();
        date22.click();
        okBtn.click();
    }
    public void clickOnYear2023MonthFebruaryAndDate16ndOkBtn(){
        year2023.click();
        februaryMonth.click();
        date16.click();
        okBtn.click();
    }

    public void clickOn2022YearAndDecemberMonth(){
        year2022.click();
        decemberInMonthView.click();
        okBtn.click();
    }

    public void clickOnYear2022(){
        year2022.click();
    }

    public void clickOnYear2022MonthDecemberAndDate18AndOkBtn(){
        year2022.click();
        decemberMonth.click();
        date18.click();
        okBtn.click();
    }

    public void clickOnYear2022MonthDecemberAndOkBtn(){
        year2022.click();
        decemberInMonthView.click();
        okBtn.click();
    }

    public void clickOnYear2023MonthJanuaryAndDate5AndOkBtn(){
        year2023.click();
        februaryMonth.click();
        date18.click();
        okBtn.click();
    }

    public void checkIfUserLandsInCalendarPage(){
        Assert.assertTrue(year2023.isDisplayed());
    }

    public void clickOn3rdApril2023(){
        year2023.click();
        aprilMonth.click();
        date3.click();
        okBtn.click();
    }
}