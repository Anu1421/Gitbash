package objectrepository;

import genericutility.WebDriverUtility;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class AlertPopUpForWatch {

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'close'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closePopUpBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Make sure your watch is connected and try again in a bit.'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/message_view"),
            @FindBy(id = "com.titan.smartworld:id/message_view")
    }) private WebElement alertMessage;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Ok'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/okay_button"),
            @FindBy(id = "com.titan.smartworld:id/okay_button")
    }) private WebElement okBtn;

    public AlertPopUpForWatch(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getAlertMessage() {
        return alertMessage;
    }

    public WebElement getOkBtn() {
        return okBtn;
    }

    public void checkAlertMessage(WebDriver driver, String OS){
        WebDriverUtility.waitForElementToBeVisible(driver, alertMessage, 10);
        if (OS.equalsIgnoreCase("Android")) {
            //Watch is reconnecting automatically and Also the error pop up is not displayed
            //Assert.assertEquals(alertMessage.getText(), "Make sure your watch is connected and try again in a bit.");
        } else if (OS.equalsIgnoreCase("IOS")) {
            Assert.assertEquals(alertMessage.getAttribute("name"), "Make sure your watch is connected and try again in a bit.");
        }
    }

    public void clickOnOkButton(){
        okBtn.click();
    }
}