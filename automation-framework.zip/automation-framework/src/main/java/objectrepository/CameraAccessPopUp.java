package objectrepository;

import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CameraAccessPopUp {
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closePopUpBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/allow_button"),
            @FindBy(id = "com.titan.smartworld:id/allow_button")
    }) private WebElement allowBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/deny_button"),
            @FindBy(id = "com.titan.smartworld:id/deny_button")
    }) private WebElement denyBtn;

    public CameraAccessPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getAllowBtn() {
        return allowBtn;
    }

    public WebElement getDenyBtn() {
        return denyBtn;
    }

    public void allowCameraAccess(){
        allowBtn.click();
    }
}
