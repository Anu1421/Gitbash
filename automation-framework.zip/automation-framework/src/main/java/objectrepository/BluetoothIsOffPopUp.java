package objectrepository;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class BluetoothIsOffPopUp {
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closePopUpBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Bluetooth is off'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title_view"),
            @FindBy(id = "com.titan.smartworld:id/title_view")
    }) private WebElement popUpTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Deny'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/deny_button"),
            @FindBy(id = "com.titan.smartworld:id/deny_button")
    }) private WebElement denyBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Allow'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/allow_button"),
            @FindBy(id = "com.titan.smartworld:id/allow_button")
    }) private WebElement allowBtn;

    public BluetoothIsOffPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getDenyBtn() {
        return denyBtn;
    }

    public WebElement getAllowBtn() {
        return allowBtn;
    }

    public void clickOnClosePopUpBtn(){
        denyBtn.click();
    }

    public void checkIfBluetoothIsOffPopUpIsDisplayed(){
        Assert.assertEquals(popUpTitle.getText(), "Bluetooth is off");
    }
}