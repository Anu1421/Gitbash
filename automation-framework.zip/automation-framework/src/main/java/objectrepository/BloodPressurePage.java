package objectrepository;

import genericutility.AndroidWebDriverUtility;
import genericutility.WebDriverUtility;
import genericutility.IOSWebDriverUtility;
import genericutility.JavaUtility;
import io.appium.java_client.pagefactory.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

public class BloodPressurePage {

    WebDriverUtility webDriverUtility;
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic back Img'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'ic_BP_Select'")
    @FindBy(id = "com.titan.fastrack.reflex:id/icon") private WebElement pageIcon;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == 'Blood Pressure'`][1]")
    @FindBy(id = "com.titan.fastrack.reflex:id/title") private WebElement pageTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic calendercommon'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/calendar"),
            @FindBy(id = "com.titan.smartworld:id/calendar")
    }) private WebElement calendarIcon;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Blood Pressure']/following-sibling::XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton)[1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/previous_icon"),
            @FindBy(id = "com.titan.smartworld:id/previous_icon")
    }) private WebElement previousBtn;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Blood Pressure']/following-sibling::XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton)[2]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/next_icon"),
            @FindBy(id = "com.titan.smartworld:id/next_icon")
    }) private WebElement nextBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Blood Pressure']/following-sibling::XCUIElementTypeOther[2]/XCUIElementTypeStaticText")
    @FindBy(id = "com.titan.fastrack.reflex:id/date_text") private WebElement currentDate;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Day'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/day"),
            @FindBy(id = "com.titan.smartworld:id/day")
    }) private WebElement dayBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Week'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/week"),
            @FindBy(id = "com.titan.smartworld:id/week")
    }) private WebElement weekBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Month'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/month"),
            @FindBy(id = "com.titan.smartworld:id/month")
    }) private WebElement monthBtn;

    @iOSXCUITFindAll({
            @iOSXCUITBy(xpath = "//XCUIElementTypeStaticText[@name='Latest']/preceding-sibling::XCUIElementTypeStaticText"),
            @iOSXCUITBy(xpath = "//XCUIElementTypeStaticText[@name='Average']/preceding-sibling::XCUIElementTypeStaticText")
    })
    @FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/android.widget.LinearLayout/android.view.ViewGroup/android.view.ViewGroup[1]/android.widget.TextView[1]") private WebElement averageOrLatestBloodPressure;

    @iOSXCUITFindBy(iOSNsPredicate = "label == '  mmHg'")
    @FindBy(id = "com.titan.fastrack.reflex:id/type_text_view") private WebElement graphYAxisUnit;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='01st - 07th']/preceding-sibling::XCUIElementTypeStaticText") private WebElement firstWeekValueInMonthView;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='1W']/preceding-sibling::XCUIElementTypeOther[5]") private WebElement firstWeekSpindleLegInMonthView;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='08th - 14th']/preceding-sibling::XCUIElementTypeStaticText") private WebElement secondWeekValueInMonthView;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='1W']/preceding-sibling::XCUIElementTypeOther[4]") private WebElement secondWeekSpindleLegInMonthView;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='15th - 21st']/preceding-sibling::XCUIElementTypeStaticText") private WebElement thirdWeekValueInMonthView;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='1W']/preceding-sibling::XCUIElementTypeOther[3]") private WebElement thirdWeekSpindleLegInMonthView;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='22nd - 28th']/preceding-sibling::XCUIElementTypeStaticText") private WebElement forthWeekValueInMonthView;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='1W']/preceding-sibling::XCUIElementTypeOther[2]") private WebElement forthWeekSpindleLegInMonthView;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'29th')]/preceding-sibling::XCUIElementTypeStaticText") private WebElement fifthWeekValueInMonthView;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='1W']/preceding-sibling::XCUIElementTypeOther[1]") private WebElement fifthWeekSpindleLegInMonthView;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Mon'") private WebElement graphXAxisValueMon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Mon']/following-sibling::XCUIElementTypeStaticText[1]") private WebElement graphXAxisValueTue;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Mon']/following-sibling::XCUIElementTypeStaticText[2]") private WebElement graphXAxisValueWed;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Mon']/following-sibling::XCUIElementTypeStaticText[3]") private WebElement graphXAxisValueThu;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Mon']/following-sibling::XCUIElementTypeStaticText[4]") private WebElement graphXAxisValueFri;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Mon']/following-sibling::XCUIElementTypeStaticText[5]") private WebElement graphXAxisValueSat;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Mon']/following-sibling::XCUIElementTypeStaticText[6]") private WebElement graphXAxisValueSun;

    @iOSXCUITFindBy(iOSNsPredicate = "label == '1W'") private WebElement graphXAxisValue1W;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='1W']/following-sibling::XCUIElementTypeStaticText[1]") private WebElement graphXAxisValue2W;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='1W']/following-sibling::XCUIElementTypeStaticText[2]") private WebElement graphXAxisValue3W;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='1W']/following-sibling::XCUIElementTypeStaticText[3]") private WebElement graphXAxisValue4W;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='1W']/following-sibling::XCUIElementTypeStaticText[4]") private WebElement graphXAxisValue5W;

    @iOSXCUITFindBy(iOSNsPredicate = "label ENDSWITH 'W'") private List<WebElement> noOfWeeks;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Readings'")
    @FindBy(id = "com.titan.fastrack.reflex:id/tv_readings") private WebElement readingsSection;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTable//XCUIElementTypeStaticText[contains(@name, 'mmHg')]")
    @FindBy(id = "com.titan.fastrack.reflex:id/tv_bp_reading") private List<WebElement> allReadings;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTable/XCUIElementTypeCell[1]//XCUIElementTypeStaticText[contains(@name, 'mmHg')]")
    @FindBy(id = "com.titan.fastrack.reflex:id/tv_bp_reading") private WebElement latestBloodPressureValueInReadingsSection;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeCollectionView//XCUIElementTypeStaticText[@name='Blood Pressure']")
    @FindBy(id = "com.titan.fastrack.reflex:id/title_fat_burns") private WebElement bloodPressureTile;
    public BloodPressurePage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getPageIcon() {
        return pageIcon;
    }

    public WebElement getPageTitle() {
        return pageTitle;
    }

    public WebElement getCalendarIcon() {
        return calendarIcon;
    }

    public WebElement getPreviousBtn() {
        return previousBtn;
    }

    public WebElement getNextBtn() {
        return nextBtn;
    }

    public WebElement getCurrentDate() {
        return currentDate;
    }

    public WebElement getDayBtn() {
        return dayBtn;
    }

    public WebElement getWeekBtn() {
        return weekBtn;
    }

    public WebElement getMonthBtn() {
        return monthBtn;
    }

    public WebElement getAverageOrLatestBloodPressure() {
        return averageOrLatestBloodPressure;
    }

    public WebElement getGraphYAxisUnit() {
        return graphYAxisUnit;
    }

    public WebElement getFirstWeekValueInMonthView() {
        return firstWeekValueInMonthView;
    }

    public WebElement getFirstWeekSpindleLegInMonthView() {
        return firstWeekSpindleLegInMonthView;
    }

    public WebElement getSecondWeekValueInMonthView() {
        return secondWeekValueInMonthView;
    }

    public WebElement getSecondWeekSpindleLegInMonthView() {
        return secondWeekSpindleLegInMonthView;
    }

    public WebElement getThirdWeekValueInMonthView() {
        return thirdWeekValueInMonthView;
    }

    public WebElement getThirdWeekSpindleLegInMonthView() {
        return thirdWeekSpindleLegInMonthView;
    }

    public WebElement getForthWeekValueInMonthView() {
        return forthWeekValueInMonthView;
    }

    public WebElement getForthWeekSpindleLegInMonthView() {
        return forthWeekSpindleLegInMonthView;
    }

    public WebElement getFifthWeekValueInMonthView() {
        return fifthWeekValueInMonthView;
    }

    public WebElement getFifthWeekSpindleLegInMonthView() {
        return fifthWeekSpindleLegInMonthView;
    }

    public WebElement getGraphXAxisValueMon() {
        return graphXAxisValueMon;
    }

    public WebElement getGraphXAxisValueTue() {
        return graphXAxisValueTue;
    }

    public WebElement getGraphXAxisValueWed() {
        return graphXAxisValueWed;
    }

    public WebElement getGraphXAxisValueThu() {
        return graphXAxisValueThu;
    }

    public WebElement getGraphXAxisValueFri() {
        return graphXAxisValueFri;
    }

    public WebElement getGraphXAxisValueSat() {
        return graphXAxisValueSat;
    }

    public WebElement getGraphXAxisValueSun() {
        return graphXAxisValueSun;
    }

    public WebElement getGraphXAxisValue1W() {
        return graphXAxisValue1W;
    }

    public WebElement getGraphXAxisValue2W() {
        return graphXAxisValue2W;
    }

    public WebElement getGraphXAxisValue3W() {
        return graphXAxisValue3W;
    }

    public WebElement getGraphXAxisValue4W() {
        return graphXAxisValue4W;
    }

    public WebElement getGraphXAxisValue5W() {
        return graphXAxisValue5W;
    }

    public List<WebElement> getNoOfWeeks() {
        return noOfWeeks;
    }

    public WebElement getReadingsSection() {
        return readingsSection;
    }

    public List<WebElement> getAllReadings() {
        return allReadings;
    }

    public WebElement getLatestBloodPressureValueInReadingsSection() {
        return latestBloodPressureValueInReadingsSection;
    }

    public WebElement getBloodPressureTile() {
        return bloodPressureTile;
    }

    public void checkIfUserLandsInBloodPressureSummaryPage(String OS){
        if (OS.equalsIgnoreCase("Android")){
            Assert.assertEquals(pageTitle.getText(), "Blood Pressure");
        } else if (OS.equalsIgnoreCase("IOS")) {
            Assert.assertEquals(pageTitle.getAttribute("name"), "Blood Pressure");
        }
    }

    public void checkIfUserLandsInDayViewOfBloodPressureSummaryPage(String OS){
        if (OS.equalsIgnoreCase("Android")){
            Assert.assertEquals(currentDate.getText(), "Today");
        } else if (OS.equalsIgnoreCase("IOS")) {
            Assert.assertEquals(currentDate.getAttribute("name"), "Today");
        }
    }

    public String fetchTheLatestBPValueFromTheReadingsSection(String OS){
        String bpValueInReadingsSection=null;
        if (OS.equalsIgnoreCase("Android")){
            bpValueInReadingsSection= latestBloodPressureValueInReadingsSection.getText();
        } else if (OS.equalsIgnoreCase("IOS")) {
            bpValueInReadingsSection= latestBloodPressureValueInReadingsSection.getAttribute("name");
        }
        return bpValueInReadingsSection;
    }

    public void checkIfUserLandsInSelectedDaysOfBloodPressureSummaryPage(String OS, String date){
        if (OS.equalsIgnoreCase("Android")){
            Assert.assertEquals(currentDate.getText(), date);
        } else if (OS.equalsIgnoreCase("IOS")) {
            Assert.assertEquals(currentDate.getAttribute("name"), date);
        }
    }

    public void clickOnPreviousBtn(){
        previousBtn.click();
    }

    public void clickOnWeekTab(){
        weekBtn.click();
    }

    public void clickOnMonthTab(){
        monthBtn.click();
    }

    public void checkIfBloodPressureDataIsDisplayed(){
        Assert.assertTrue(averageOrLatestBloodPressure.isDisplayed(), "BloodPressure data is displayed");
    }

    public void checkIfMonToSunIsDisplayedAsValuesInXAxis(String OS){
        if (OS.equalsIgnoreCase("Android")){

        } else if (OS.equalsIgnoreCase("IOS")) {
            Assert.assertEquals(graphXAxisValueMon.getAttribute("name"), "Mon");
            Assert.assertEquals(graphXAxisValueTue.getAttribute("name"), "Tue");
            Assert.assertEquals(graphXAxisValueWed.getAttribute("name"), "Wed");
            Assert.assertEquals(graphXAxisValueThu.getAttribute("name"), "Thu");
            Assert.assertEquals(graphXAxisValueFri.getAttribute("name"), "Fri");
            Assert.assertEquals(graphXAxisValueSat.getAttribute("name"), "Sat");
            Assert.assertEquals(graphXAxisValueSun.getAttribute("name"), "Sun");
        }
    }

    public void checkIfAllWeekValuesAreDisplayedInXAxis(String OS){
        if (OS.equalsIgnoreCase("Android")){

        } else if (OS.equalsIgnoreCase("IOS")) {
            Assert.assertEquals(graphXAxisValue1W.getAttribute("name"), "1W");
            Assert.assertEquals(graphXAxisValue2W.getAttribute("name"), "2W");
            Assert.assertEquals(graphXAxisValue3W.getAttribute("name"), "3W");
            Assert.assertEquals(graphXAxisValue4W.getAttribute("name"), "4W");
            Assert.assertEquals(graphXAxisValue5W.getAttribute("name"), "5W");
        }
    }

    public void clickOnCalendarIcon(){
        calendarIcon.click();
    }

    public void checkIfBloodPressureInformationTileIsDisplayedAtTheBottomOfTheScreen(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            webDriverUtility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            webDriverUtility=new IOSWebDriverUtility();
        }
        webDriverUtility.swipeByElements(driver, readingsSection, pageTitle, 2);
        Assert.assertTrue(bloodPressureTile.isDisplayed());
        webDriverUtility.swipeByElements(driver, readingsSection, bloodPressureTile, 2);
    }

    public void clickOnBackBtn(){
        backBtn.click();
    }

    public void checkIfProperUnitOfBPIsDisplayedAtYAxisOfGraph(String OS){
        String bpUnit=null;
        if (OS.equalsIgnoreCase("Android")){
            bpUnit = graphYAxisUnit.getText();
        } else if (OS.equalsIgnoreCase("IOS")) {
            bpUnit = graphYAxisUnit.getAttribute("name");
        }
        Assert.assertEquals(bpUnit, "mmHg");
    }

    public ArrayList<String> fetchAllBPReadings() {
        String val = null;
        ArrayList<String> arr=new ArrayList<>();
        for (WebElement ele : allReadings
        ) {
            val = ele.getAttribute("name");
            arr.add(val);
        }
        return arr;
    }

    public String fetchTheBPValue(String OS){
        String avgValue = null;
        if (OS.equalsIgnoreCase("Android")){
            avgValue=averageOrLatestBloodPressure.getText();
        } else if (OS.equalsIgnoreCase("IOS")) {
            avgValue=averageOrLatestBloodPressure.getAttribute("name");
        }
        return avgValue;
    }

    public String getTheAverageOfAllValuesUnderReadingsSection(){
        float systolicValue = 0;
        float diastolicValue = 0;
        ArrayList<String> arrayList=fetchAllBPReadings();
        for (String val: arrayList
        ) {
            systolicValue = Integer.parseInt(val.split("[/, ]")[0])+systolicValue;
            diastolicValue = Integer.parseInt(val.split("[/, ]")[1])+diastolicValue;
        }
        float numberOfReadings = arrayList.size();
        float avgSystolicValue=systolicValue/numberOfReadings;
        float avgDiastolicValue=diastolicValue/numberOfReadings;
        Math.round(avgDiastolicValue);
        Math.round(avgSystolicValue);
        String avg=avgSystolicValue+"/"+avgDiastolicValue+" mmHg";
        return avg;
    }

    public void checkIfBPValuesAndTimeIsDisplayedInSpindle(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            webDriverUtility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            webDriverUtility=new IOSWebDriverUtility();
        }
        if (new JavaUtility().fetchOnlyMonthInMonFormat().equalsIgnoreCase("Feb")){
            Assert.assertTrue(firstWeekValueInMonthView.isDisplayed());
            webDriverUtility.swipeByElements(driver, firstWeekSpindleLegInMonthView, secondWeekSpindleLegInMonthView, 2);
            Assert.assertTrue(secondWeekValueInMonthView.isDisplayed());
            webDriverUtility.swipeByElements(driver, secondWeekSpindleLegInMonthView, thirdWeekSpindleLegInMonthView, 2);
            Assert.assertTrue(thirdWeekValueInMonthView.isDisplayed());
            webDriverUtility.swipeByElements(driver, thirdWeekSpindleLegInMonthView, forthWeekSpindleLegInMonthView, 2);
            Assert.assertTrue(forthWeekValueInMonthView.isDisplayed());
        } else {
            Assert.assertTrue(firstWeekValueInMonthView.isDisplayed());
            webDriverUtility.swipeByElements(driver, firstWeekSpindleLegInMonthView, secondWeekSpindleLegInMonthView, 2);
            Assert.assertTrue(secondWeekValueInMonthView.isDisplayed());
            webDriverUtility.swipeByElements(driver, secondWeekSpindleLegInMonthView, thirdWeekSpindleLegInMonthView, 2);
            Assert.assertTrue(thirdWeekValueInMonthView.isDisplayed());
            webDriverUtility.swipeByElements(driver, thirdWeekSpindleLegInMonthView, forthWeekSpindleLegInMonthView, 2);
            Assert.assertTrue(forthWeekValueInMonthView.isDisplayed());
            webDriverUtility.swipeByElements(driver, forthWeekSpindleLegInMonthView, fifthWeekSpindleLegInMonthView, 2);
            Assert.assertTrue(fifthWeekValueInMonthView.isDisplayed());
        }
    }

    public String getTheAverageOfAllValuesInSpindleInMonthView(WebDriver driver, String OS){
        int systolicValue = 0;
        int diastolicValue = 0;
        if (OS.equalsIgnoreCase("Android")){
            webDriverUtility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            webDriverUtility=new IOSWebDriverUtility();
        }
        ArrayList<String> arrayList=new ArrayList<>();
        if (new JavaUtility().fetchOnlyMonthInMonFormat().equalsIgnoreCase("Feb")){
            arrayList.add(firstWeekValueInMonthView.getAttribute("name"));
            webDriverUtility.swipeByElements(driver, firstWeekSpindleLegInMonthView, secondWeekSpindleLegInMonthView, 2);
            arrayList.add(secondWeekValueInMonthView.getAttribute("name"));
            webDriverUtility.swipeByElements(driver, secondWeekSpindleLegInMonthView, thirdWeekSpindleLegInMonthView, 2);
            arrayList.add(thirdWeekValueInMonthView.getAttribute("name"));
            webDriverUtility.swipeByElements(driver, thirdWeekSpindleLegInMonthView, forthWeekSpindleLegInMonthView, 2);
            arrayList.add(forthWeekValueInMonthView.getAttribute("name"));
        } else {
            if (firstWeekValueInMonthView.getAttribute("name").contains("/")) {
                arrayList.add(firstWeekValueInMonthView.getAttribute("name"));
            }
            webDriverUtility.swipeByElements(driver, firstWeekSpindleLegInMonthView, secondWeekSpindleLegInMonthView, 2);
            if (secondWeekValueInMonthView.getAttribute("name").contains("/")) {
                arrayList.add(secondWeekValueInMonthView.getAttribute("name"));
            }
            webDriverUtility.swipeByElements(driver, secondWeekSpindleLegInMonthView, thirdWeekSpindleLegInMonthView, 2);
            if (thirdWeekValueInMonthView.getAttribute("name").contains("/")) {
                arrayList.add(thirdWeekValueInMonthView.getAttribute("name"));
            }
            webDriverUtility.swipeByElements(driver, thirdWeekSpindleLegInMonthView, forthWeekSpindleLegInMonthView, 2);
            if (forthWeekValueInMonthView.getAttribute("name").contains("/")) {
                arrayList.add(forthWeekValueInMonthView.getAttribute("name"));
            }
            webDriverUtility.swipeByElements(driver, forthWeekSpindleLegInMonthView, fifthWeekSpindleLegInMonthView, 2);
            if (fifthWeekValueInMonthView.getAttribute("name").contains("/")) {
                arrayList.add(fifthWeekValueInMonthView.getAttribute("name"));
            }
        }
        System.out.println(arrayList);
        for (String val: arrayList
        ) {
            systolicValue = Integer.parseInt(val.split("[/, ,-]")[0])+systolicValue;
            diastolicValue = Integer.parseInt(val.split("[/, ,-]")[1])+diastolicValue;
        }
        int numberOfReadings = arrayList.size();
        int avgSystolicValue=systolicValue/numberOfReadings;
        int avgDiastolicValue=diastolicValue/numberOfReadings;
        String avg=avgSystolicValue+"/"+avgDiastolicValue+" mmHg";
        return avg;
    }

    public void swipeToReadingsSection(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            webDriverUtility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            webDriverUtility=new IOSWebDriverUtility();
        }
        webDriverUtility.swipeByElements(driver, readingsSection, dayBtn, 2);
    }
}
