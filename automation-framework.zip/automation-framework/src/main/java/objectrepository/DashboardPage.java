package objectrepository;

import genericutility.WebDriverUtility;
import genericutility.IOSWebDriverUtility;
import genericutility.JavaUtility;
import genericutility.AndroidWebDriverUtility;
import io.appium.java_client.pagefactory.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class DashboardPage {
    WebDriverUtility webDriverUtility;

    @iOSXCUITFindAll({
            @iOSXCUITBy(iOSNsPredicate = "name == 'titanlogo'"),
            @iOSXCUITBy(xpath = "//XCUIElementTypeApplication[@name='Titan Smart World']//XCUIElementTypeButton/following-sibling::XCUIElementTypeImage"),
            @iOSXCUITBy(xpath = "//XCUIElementTypeApplication[@name='Fastrack Reflex World']//XCUIElementTypeButton/following-sibling::XCUIElementTypeImage")
    })
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/app_icon"),
            @FindBy(id = "com.titan.fastrack.reflex:id/app_icon")
    })
    private WebElement logo;

    @iOSXCUITFindBy(iOSNsPredicate = "label  BEGINSWITH 'paired'")
    @FindAll({
            @FindBy(xpath = "//android.widget.TextView[@text='Paired']"),
            @FindBy(xpath = "//android.widget.ImageView[@content-desc='CONNECTED']"),
    }) private WebElement watchStatusPaired;

    @iOSXCUITFindBy(iOSNsPredicate = "label  BEGINSWITH 'unpaired'")
    @FindAll({
            @FindBy(xpath = "//android.widget.TextView[@text='Unpaired']"),
            @FindBy(xpath = "//android.widget.ImageView[@content-desc='DISCONNECTED']")
    }) private WebElement watchStatusUnpaired;

    @iOSXCUITFindBy(iOSNsPredicate = "label CONTAINS 'paired'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/connection_button"),
            @FindBy(id = "com.titan.smartworld:id/connection_button")
    }) private WebElement watchConnectionStatusIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='sportIcon']/../../..")
    @FindAll({
            @FindBy(xpath = "//android.view.ViewGroup[@resource-id='com.titan.fastrack.reflex:id/sleep_data']/.."),
            @FindBy(xpath = "//android.view.ViewGroup[@resource-id='com.titan.smartworld:id/sleep_data']/..")
    }) private WebElement progressCircleGroup;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='sportIcon']/..")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/progress_bar_steps"),
            @FindBy(id = "com.titan.fastrack.reflex:id/progress_bar_steps")
    }) private WebElement stepsProgressBar;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'sportIcon'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/steps_summary_icon"),
            @FindBy(id = "com.titan.smartworld:id/steps_summary_icon")
    }) private WebElement stepsIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='sportIcon']/following-sibling::XCUIElementTypeStaticText[1]")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/steps_achieved"),
            @FindBy(id = "com.titan.fastrack.reflex:id/steps_achieved")
    }) private WebElement stepsAchievedTxt;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='sportIcon']/following-sibling::XCUIElementTypeStaticText[2]")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/steps_target"),
            @FindBy(id = "com.titan.fastrack.reflex:id/steps_target")
    }) private WebElement stepsTargetTxt;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='sleepMiniIcon']/..")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/progress_bar_sleep"),
            @FindBy(id = "com.titan.fastrack.reflex:id/progress_bar_sleep")
    }) private WebElement sleepProgressBar;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'sleepMiniIcon'")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/sleep_summary_icon"),
            @FindBy(id = "com.titan.fastrack.reflex:id/sleep_summary_icon")
    }) private WebElement sleepIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='sleepMiniIcon']/following-sibling::XCUIElementTypeStaticText[1]")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/sleep_achieved"),
            @FindBy(id = "com.titan.fastrack.reflex:id/sleep_achieved")
    }) private WebElement sleepAchievedTxt;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='sleepMiniIcon']/following-sibling::XCUIElementTypeStaticText[2]")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/sleep_target"),
            @FindBy(id = "com.titan.fastrack.reflex:id/sleep_target")
    }) private WebElement sleepTargetTxt;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='activeIcon']/..")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/progress_bar_multisport"),
            @FindBy(id = "com.titan.fastrack.reflex:id/progress_bar_multisport")
    }) private WebElement multiSportProgressBar;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'activeIcon'")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/multisport_img"),
            @FindBy(id = "com.titan.fastrack.reflex:id/multisport_img")
    }) private WebElement multiSportIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='activeIcon']/following-sibling::XCUIElementTypeStaticText[1]")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/multisport_achieved"),
            @FindBy(id = "com.titan.fastrack.reflex:id/multisport_achieved")
    }) private WebElement multiSportAchievedTxt;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='activeIcon']/following-sibling::XCUIElementTypeStaticText[2]")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/multisport_target"),
            @FindBy(id = "com.titan.fastrack.reflex:id/multisport_target")
    }) private WebElement multiSportTargetTxt;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='activeIcon']/../../following-sibling::XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/sync_time"),
            @FindBy(id = "com.titan.fastrack.reflex:id/sync_time")
    }) private WebElement syncTime;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Last synced few seconds ago'") private WebElement secondsAgoSyncTime;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Active Tasks'")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/activeTaskTv"),
            @FindBy(id = "com.titan.fastrack.reflex:id/activeTaskTv")
    }) private WebElement activeTaskSection;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Active Tasks']/following-sibling::XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/totalPointsTv"),
            @FindBy(id = "com.titan.fastrack.reflex:id/totalPointsTv")
    }) private WebElement totalZetaPointCount;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Active Tasks']/following-sibling::XCUIElementTypeCollectionView")
    @FindAll({
            @FindBy(xpath = "//android.widget.TextView[@resource-id='com.titan.fastrack.reflex:id/activeTaskTv']/.."),
            @FindBy(xpath = "//android.widget.TextView[@resource-id='com.titan.smartworld:id/activeTaskTv']/..")
    }) private WebElement activeTaskGroup;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Active Tasks']/following-sibling::XCUIElementTypeCollectionView/descendant::XCUIElementTypeOther)[2]")
    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='task'])[1]/..") private WebElement firstActiveTask;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Active Tasks']/following-sibling::XCUIElementTypeCollectionView/descendant::XCUIElementTypeImage)[1]")
    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='task'])[1]") private WebElement firstActiveTaskIcon;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='task'])[1]/following-sibling::android.widget.TextView[3]") private WebElement firstActiveTaskProgPer;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Active Tasks']/following-sibling::XCUIElementTypeCollectionView/descendant::XCUIElementTypeStaticText)[2]")
    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='task'])[1]/following-sibling::android.widget.TextView[4]") private WebElement firstActiveTaskZetaPts;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Active Tasks']/following-sibling::XCUIElementTypeCollectionView/descendant::XCUIElementTypeOther)[4]")
    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='task'])[2]/..") private WebElement secondActiveTask;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Active Tasks']/following-sibling::XCUIElementTypeCollectionView/descendant::XCUIElementTypeImage)[3]")
    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='task'])[2]") private WebElement secondActiveTaskIcon;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='task'])[2]/following-sibling::android.widget.TextView[3]") private WebElement secondActiveTaskProgPer;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Active Tasks']/following-sibling::XCUIElementTypeCollectionView/descendant::XCUIElementTypeStaticText)[5]")
    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='task'])[2]/following-sibling::android.widget.TextView[4]") private WebElement secondActiveTaskZetaPts;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Step Goal')]/preceding-sibling::XCUIElementTypeImage")
    @FindBy(xpath = "//android.widget.ImageView[@content-desc='Step Goal']") private WebElement stepGoalActiveTaskIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Step Goal')]/following-sibling::XCUIElementTypeStaticText[contains(@name,'%')]")
    @FindBy(xpath = "//android.widget.TextView[@content-desc='Step Goal']") private WebElement stepGoalActiveTaskPercentage;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Step Goal')]/following-sibling::XCUIElementTypeStaticText[contains(@name,'Z')]")
    @FindBy(xpath = "//android.widget.ImageView[@content-desc='Step Goal']/following-sibling::android.widget.TextView[4]") private WebElement stepGoalActiveTaskZetaPoints;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Calories')]/preceding-sibling::XCUIElementTypeImage")
    @FindBy(xpath = "//android.widget.ImageView[@content-desc='Calories']") private WebElement caloriesActiveTaskIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Calories')]/following-sibling::XCUIElementTypeStaticText[contains(@name,'%')]")
    @FindBy(xpath = "//android.widget.TextView[@content-desc='Calories']") private WebElement caloriesActiveTaskPercentage;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Calories')]/following-sibling::XCUIElementTypeStaticText[contains(@name,'Z')]")
    @FindBy(xpath = "//android.widget.ImageView[@content-desc='Calories']/following-sibling::android.widget.TextView[4]") private WebElement caloriesActiveTaskZetaPoints;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'My Health'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/my_health"),
            @FindBy(id = "com.titan.smartworld:id/my_health")
        }) private WebElement myHealthSection;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Edit'")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/edit_button"),
            @FindBy(id = "com.titan.fastrack.reflex:id/edit_button")
    }) private WebElement editMyHealthOptionsBtn;

    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/my_health_cards"),
            @FindBy(id = "com.titan.fastrack.reflex:id/my_health_cards")
    }) private WebElement allHealthCards;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='My Health']/../../following-sibling::XCUIElementTypeCell[1]//XCUIElementTypeOther)[2]")
    @FindBy(xpath = "(//android.widget.ImageView[@content-desc=\"tile type\"])[1]/..") private WebElement firstHealthCard;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='My Health']/../../following-sibling::XCUIElementTypeCell[1]") private WebElement fullFirstHealthCard;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='My Health']/../../following-sibling::XCUIElementTypeCell[2]//XCUIElementTypeOther)[2]")
    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='tile type'])[2]/..") private WebElement secondHealthCard;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='My Health']/../../following-sibling::XCUIElementTypeCell[2]") private WebElement fullSecondHealthCard;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='My Health']/../../following-sibling::XCUIElementTypeCell[3]//XCUIElementTypeOther)[2]")
    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='tile type'])[3]/..") private WebElement thirdHealthCard;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='My Health']/../../following-sibling::XCUIElementTypeCell[3]") private WebElement fullThirdHealthCard;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='My Health']/../../following-sibling::XCUIElementTypeCell[4]//XCUIElementTypeOther)[2]")
    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='tile type'])[4]/..") private WebElement fourthHealthCard;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='My Health']/../../following-sibling::XCUIElementTypeCell[4]") private WebElement fullFourthHealthCard;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='tile type'])[5]/..") private WebElement fifthHealthCard;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'hr')]/preceding-sibling::XCUIElementTypeImage")
    @FindAll({
            @FindBy(xpath = "//android.widget.ImageView[@content-desc='SLEEP']"),
            @FindBy(xpath = "(//android.widget.ImageView[@content-desc='tile type'])[1]"),
            @FindBy(xpath = "//android.view.ViewGroup[1]/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ImageView")
    }) private WebElement sleepHealthCard;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'%')]/preceding-sibling::XCUIElementTypeImage")
    @FindAll({
            @FindBy(xpath = "//android.widget.TextView[contains(@text,'%')]/preceding-sibling::android.widget.TextView[@resource-id='com.titan.fastrack.reflex:id/tile_record_time']"),
            @FindBy(xpath = "//android.view.ViewGroup[2]/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ImageView")
    }) private WebElement bloodOxygenHealthCard;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'bpm')]/preceding-sibling::XCUIElementTypeImage")
    @FindBy(xpath = "//android.widget.TextView[contains(@text,'bpm')]")
     private WebElement heartRateHealthCard;

    @iOSXCUITFindBy(iOSNsPredicate = "label ENDSWITH 'bpm'")
    @FindBy(xpath = "//android.widget.TextView[contains(@text, 'bpm')]") private WebElement heartRateInBpm;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'bpm')]/preceding-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.widget.TextView[contains(@text, 'bpm')]/preceding-sibling::android.widget.TextView") private WebElement heartRateLastSyncedTime;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'pm -')]/preceding-sibling::XCUIElementTypeImage")
    @FindAll({
            @FindBy(xpath = "(//android.widget.ImageView[@content-desc='tile type'])[4]"),
            @FindBy(xpath = "//android.view.ViewGroup[4]/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ImageView")
    }) private WebElement multiSportHealthCard;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Day')]/preceding-sibling::XCUIElementTypeImage")
    @FindAll({
            @FindBy(xpath = "(//android.widget.ImageView[@content-desc='tile type'])[5]"),
            @FindBy(xpath = "//android.view.ViewGroup[5]/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ImageView")
    }) private WebElement myCycleHealthCard;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'mmHg')]/preceding-sibling::XCUIElementTypeImage")
    @FindBy(xpath = "//android.widget.TextView[contains(@text, 'mmHg')]") private WebElement bloodPressureHealthCard;

    @iOSXCUITFindBy(iOSNsPredicate = "label ENDSWITH 'mmHg'")
    @FindBy(xpath = "//android.widget.TextView[contains(@text, 'mmHg')]") private WebElement bloodPressureValueUnderMyHealthOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label BEGINSWITH 'Next Period'")
    @FindBy(xpath = "//android.widget.TextView[contains(@text, 'Next')]") private WebElement remainingDaysForNextPeriod;

    @iOSXCUITFindBy(iOSNsPredicate = "label BEGINSWITH 'Day'")
    @FindBy(xpath = "//android.widget.TextView[contains(@text, 'Day')][1]") private WebElement currentDayOfPeriod;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[contains(@name,'Day')]/following-sibling::XCUIElementTypeStaticText)[2]")
    @FindBy(xpath = "//android.widget.TextView[contains(@text, 'Day')][1]/following-sibling::android.widget.TextView") private WebElement periodStage;

    @FindAll({
            @FindBy(xpath = "//android.widget.TextView[contains(@text, '℃')]/parent::android.view.ViewGroup"),
            @FindBy(xpath = "//android.widget.TextView[contains(@text, '℉')]/parent::android.view.ViewGroup")
    }) private WebElement temperatureHealthCard;

    @FindAll({
            @FindBy(xpath = "//android.widget.TextView[contains(@text, '℃')]"),
            @FindBy(xpath = "//android.widget.TextView[contains(@text, '℉')]")
    }) private WebElement recentTemperatureInHealthCard;

    @FindAll({
            @FindBy(xpath = "//android.widget.TextView[contains(@text, '℃')]/parent::android.view.ViewGroup/preceding-sibling::android.widget.ImageView"),
            @FindBy(xpath = "//android.widget.TextView[contains(@text, '℉')]/parent::android.view.ViewGroup/preceding-sibling::android.widget.ImageView")
    }) private WebElement temperatureIconInHealthCard;

    @FindAll({
            @FindBy(xpath = "//android.widget.TextView[contains(@text, '℃')]/preceding-sibling::android.widget.TextView"),
            @FindBy(xpath = "//android.widget.TextView[contains(@text, '℉')]/preceding-sibling::android.widget.TextView")
    }) private WebElement temperatureLastMeasuredDateOrTimeInHealthCard;


    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Articles for you'")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/latestAdditionsTV"),
            @FindBy(id = "com.titan.fastrack.reflex:id/latestAdditionsTV")
    })
    private WebElement articlesSection;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'View all'")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/viewAllTV"),
            @FindBy(id = "com.titan.fastrack.reflex:id/viewAllTV")
    }) private WebElement viewAllSavedArticlesLink;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Articles for you']/following-sibling::XCUIElementTypeCollectionView//XCUIElementTypeImage)[1]")

    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/titleIv"),
            @FindBy(id = "com.titan.fastrack.reflex:id/titleIv")
    }) private WebElement articleImage;

    @FindBy(xpath = "//android.widget.ImageView[@content-desc='image']/following-sibling::android.widget.TextView[1]") private WebElement newOrPopularIcon;

    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/newTv"),
            @FindBy(id="com.titan.fastrack.reflex:id/newTv")
    }) private WebElement newArticleText;

    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/quotationTv"),
            @FindBy(id="com.titan.fastrack.reflex:id/quotationTv")
    }) private WebElement articleReadTickIcon;

    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/popularTV"),
            @FindBy(id="com.titan.fastrack.reflex:id/popularTV")
    }) private WebElement popularArticleTag;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Articles for you']/following-sibling::XCUIElementTypeCollectionView//XCUIElementTypeImage)[2]")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/favIconIv"),
            @FindBy(id = "com.titan.fastrack.reflex:id/favIconIv")
    }) private WebElement likeArticleIcon;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Articles for you']/following-sibling::XCUIElementTypeCollectionView//XCUIElementTypeImage)[3]")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/shareIconIv"),
            @FindBy(id = "com.titan.fastrack.reflex:id/shareIconIv")
    }) private WebElement shareArticleIcon;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Articles for you']/following-sibling::XCUIElementTypeCollectionView//XCUIElementTypeImage)[4]")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/bookmarkIconIv"),
            @FindBy(id = "com.titan.fastrack.reflex:id/bookmarkIconIv")
    }) private WebElement saveArticleIcon;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Articles for you']/following-sibling::XCUIElementTypeCollectionView//XCUIElementTypeStaticText)[1]")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/titleTv"),
            @FindBy(id = "com.titan.fastrack.reflex:id/titleTv")
    }) private WebElement articleTitle;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='bottom nav icon'])[1]") private WebElement healthTab;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='bottom nav icon'])[2]") private WebElement multiSportTab;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='bottom nav icon'])[3]") private WebElement myFitnessTab;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='bottom nav icon'])[4]") private WebElement sleepTab;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Music for you'")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/music_for_you"),
            @FindBy(id = "com.titan.fastrack.reflex:id/music_for_you")
    })
     private WebElement musicSection;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'play song'")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/music_play_text"),
            @FindBy(id = "com.titan.fastrack.reflex:id/music_play_text")
    }) private WebElement playMusicBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[3]//XCUIElementTypeCell[1]")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/homeFragment"),
            @FindBy(id = "com.titan.fastrack.reflex:id/homeFragment")
    }) private WebElement homeBtnIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[3]//XCUIElementTypeCell[2]")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/rewards"),
            @FindBy(id = "com.titan.fastrack.reflex:id/rewards")
    }) private WebElement rewardsBtnIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[3]//XCUIElementTypeCell[3]")
    @FindAll({
            @FindBy(id = "com.titan.smartworld:id/community"),
            @FindBy(id = "com.titan.fastrack.reflex:id/community")
    }) private WebElement communityBtnIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[3]//XCUIElementTypeCell[4]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/watchFaces"),
            @FindBy(id = "com.titan.smartworld:id/watchFaces")
    })
    private WebElement watchFacesBtnIcon;


    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[3]//XCUIElementTypeCell[5]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/settings"),
            @FindBy(id = "com.titan.smartworld:id/settings")
    }) private WebElement settingsTab;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Close'") private WebElement closeArticlePopUp;

    public DashboardPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getLogo() {
        return logo;
    }

    public WebElement getWatchStatusPaired() {
        return watchStatusPaired;
    }

    public WebElement getWatchStatusUnpaired() {
        return watchStatusUnpaired;
    }

    public WebElement getWatchConnectionStatusIcon() {
        return watchConnectionStatusIcon;
    }

    public WebElement getProgressCircleGroup() {
        return progressCircleGroup;
    }

    public WebElement getHealthTab() {
        return healthTab;
    }

    public WebElement getMultiSportTab() {
        return multiSportTab;
    }

    public WebElement getMyFitnessTab() {
        return myFitnessTab;
    }

    public WebElement getSleepTab() {
        return sleepTab;
    }

    public WebElement getSettingsTab() {
        return settingsTab;
    }

    public WebElement getStepsIcon() {
        return stepsIcon;
    }

    public WebElement getStepsAchievedTxt() {
        return stepsAchievedTxt;
    }

    public WebElement getStepsTargetTxt() {
        return stepsTargetTxt;
    }

    public WebElement getSleepIcon() {
        return sleepIcon;
    }

    public WebElement getSleepAchievedTxt() {
        return sleepAchievedTxt;
    }

    public WebElement getSleepTargetTxt() {
        return sleepTargetTxt;
    }

    public WebElement getMultiSportIcon() {
        return multiSportIcon;
    }

    public WebElement getMultiSportAchievedTxt() {
        return multiSportAchievedTxt;
    }

    public WebElement getMultiSportTargetTxt() {
        return multiSportTargetTxt;
    }

    public WebElement getSyncTime() {
        return syncTime;
    }

    public WebElement getSecondsAgoSyncTime() {
        return secondsAgoSyncTime;
    }

    public WebElement getTotalZetaPointCount() {
        return totalZetaPointCount;
    }

    public WebElement getActiveTaskGroup() {
        return activeTaskGroup;
    }

    public WebElement getFirstActiveTask() {
        return firstActiveTask;
    }

    public WebElement getFirstActiveTaskIcon() {
        return firstActiveTaskIcon;
    }

    public WebElement getFirstActiveTaskProgPer() {
        return firstActiveTaskProgPer;
    }

    public WebElement getFirstActiveTaskZetaPts() {
        return firstActiveTaskZetaPts;
    }

    public WebElement getSecondActiveTask() {
        return secondActiveTask;
    }

    public WebElement getSecondActiveTaskIcon() {
        return secondActiveTaskIcon;
    }

    public WebElement getSecondActiveTaskProgPer() {
        return secondActiveTaskProgPer;
    }

    public WebElement getSecondActiveTaskZetaPts() {
        return secondActiveTaskZetaPts;
    }

    public WebElement getStepGoalActiveTaskIcon() {
        return stepGoalActiveTaskIcon;
    }

    public WebElement getStepGoalActiveTaskPercentage() {
        return stepGoalActiveTaskPercentage;
    }

    public WebElement getStepGoalActiveTaskZetaPoints() {
        return stepGoalActiveTaskZetaPoints;
    }

    public WebElement getCaloriesActiveTaskIcon() {
        return caloriesActiveTaskIcon;
    }

    public WebElement getCaloriesActiveTaskPercentage() {
        return caloriesActiveTaskPercentage;
    }

    public WebElement getCaloriesActiveTaskZetaPoints() {
        return caloriesActiveTaskZetaPoints;
    }

    public WebElement getEditMyHealthOptionsBtn() {
        return editMyHealthOptionsBtn;
    }

    public WebElement getSleepHealthCard() {
        return sleepHealthCard;
    }

    public WebElement getAllHealthCards() {
        return allHealthCards;
    }

    public WebElement getFirstHealthCard() {
        return firstHealthCard;
    }

    public WebElement getSecondHealthCard() {
        return secondHealthCard;
    }

    public WebElement getThirdHealthCard() {
        return thirdHealthCard;
    }

    public WebElement getFourthHealthCard() {
        return fourthHealthCard;
    }

    public WebElement getFifthHealthCard() {
        return fifthHealthCard;
    }

    public WebElement getFullFirstHealthCard() {
        return fullFirstHealthCard;
    }

    public WebElement getFullSecondHealthCard() {
        return fullSecondHealthCard;
    }

    public WebElement getFullThirdHealthCard() {
        return fullThirdHealthCard;
    }

    public WebElement getFullFourthHealthCard() {
        return fullFourthHealthCard;
    }

    public WebElement getBloodOxygenHealthCard() {
        return bloodOxygenHealthCard;
    }

    public WebElement getHeartRateHealthCard() {
        return heartRateHealthCard;
    }

    public WebElement getHeartRateInBpm() {
        return heartRateInBpm;
    }

    public WebElement getHeartRateLastSyncedTime() {
        return heartRateLastSyncedTime;
    }

    public WebElement getMultiSportHealthCard() {
        return multiSportHealthCard;
    }

    public WebElement getMyCycleHealthCard() {
        return myCycleHealthCard;
    }

    public WebElement getRemainingDaysForNextPeriod() {
        return remainingDaysForNextPeriod;
    }

    public WebElement getCurrentDayOfPeriod() {
        return currentDayOfPeriod;
    }

    public WebElement getPeriodStage() {
        return periodStage;
    }

    public WebElement getBloodPressureHealthCard() {
        return bloodPressureHealthCard;
    }

    public WebElement getBloodPressureValueUnderMyHealthOption() {
        return bloodPressureValueUnderMyHealthOption;
    }

    public WebElement getViewAllSavedArticlesLink() {
        return viewAllSavedArticlesLink;
    }

    public WebElement getArticleImage() {
        return articleImage;
    }

    public WebElement getNewOrPopularIcon() {
        return newOrPopularIcon;
    }

    public WebElement getNewArticleText() {
        return newArticleText;
    }

    public WebElement getArticleReadTickIcon() {
        return articleReadTickIcon;
    }

    public WebElement getPopularArticleTag() {
        return popularArticleTag;
    }

    public WebElement getLikeArticleIcon() {
        return likeArticleIcon;
    }

    public WebElement getShareArticleIcon() {
        return shareArticleIcon;
    }

    public WebElement getSaveArticleIcon() {
        return saveArticleIcon;
    }

    public WebElement getArticleTitle() {
        return articleTitle;
    }

    public WebElement getPlayMusicBtn() {
        return playMusicBtn;
    }

    public WebElement getHomeBtnIcon() {
        return homeBtnIcon;
    }

    public WebElement getRewardsBtnIcon() {
        return rewardsBtnIcon;
    }

    public WebElement getCommunityBtnIcon() {
        return communityBtnIcon;
    }

    public WebElement getWatchFacesBtnIcon() {
        return watchFacesBtnIcon;
    }

    public WebElement getStepsProgressBar() {
        return stepsProgressBar;
    }

    public WebElement getSleepProgressBar() {
        return sleepProgressBar;
    }

    public WebElement getMultiSportProgressBar() {
        return multiSportProgressBar;
    }

    public WebElement getActiveTaskSection() {
        return activeTaskSection;
    }

    public WebElement getMyHealthSection() {
        return myHealthSection;
    }

    public WebElement getArticlesSection() {
        return articlesSection;
    }

    public WebElement getMusicSection() {
        return musicSection;
    }

    public WebElement getCloseArticlePopUp() {
        return closeArticlePopUp;
    }

    public void waitForWatchToPair(WebDriver driver){
        WebDriverUtility.waitForElementToBeVisible(driver, watchStatusPaired, 10);
    }

    public void unpairWatch(WebDriver driver){
        watchConnectionStatusIcon.click();
        DisconnectWatchPopUp disconnectWatchPopUp=new DisconnectWatchPopUp(driver);
        disconnectWatchPopUp.confirmWatchDisconnection();
    }

    public void clickOnSettingsTab(){
        settingsTab.click();
    }

    public void clickOnHealthTab(){
        healthTab.click();
    }

    public void clickOnMultiSportTab(){
        multiSportTab.click();
    }
    public void clickOnMyFitnessTab(){
        myFitnessTab.click();
    }

    public void clickOnSleepTab(){
        sleepTab.click();
    }

    public void checkIfWatchIsUnpaired(WebDriver driver){
        Assert.assertTrue(watchStatusUnpaired.isDisplayed());
    }

    public void checkIfUserLandsInDashboard(){
        Assert.assertTrue(logo.isDisplayed());
    }

    public void pairWatch(){
        watchConnectionStatusIcon.click();
    }

    public String returnWatchConnectionStatus(String OS) {
        String status = null;
        if (OS.equalsIgnoreCase("Android")) {
            status = watchConnectionStatusIcon.getAttribute("content-desc");
        } else if (OS.equalsIgnoreCase("IOS")) {
            status = watchConnectionStatusIcon.getAttribute("name");
        }
        return status;
    }

    public void clickOnMultiSportSummaryIcon(){
        multiSportIcon.click();
    }

    public void clickOnStepsSummaryIcon(){
        stepsIcon.click();
    }

    public void clickOnSleepSummaryIcon(){
        sleepIcon.click();
    }

    public void checkIfTitanLogoIsDisplayed(){
        Assert.assertTrue(logo.isDisplayed());
    }

    public void checkIfAllComponentsInDashboardAreDisplayed(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            webDriverUtility =new AndroidWebDriverUtility();
            Assert.assertTrue(watchConnectionStatusIcon.isDisplayed());
            Assert.assertTrue(sleepIcon.isDisplayed());
            Assert.assertTrue(stepsIcon.isDisplayed());
            Assert.assertTrue(multiSportIcon.isDisplayed());
            Assert.assertTrue(activeTaskSection.isDisplayed());
            Assert.assertTrue(totalZetaPointCount.isDisplayed());
            Assert.assertTrue(myHealthSection.isDisplayed());
            webDriverUtility.swipeScreen(driver, WebDriverUtility.Direction.UP);
            Assert.assertTrue(articlesSection.isDisplayed());
            webDriverUtility.swipeScreen(driver, WebDriverUtility.Direction.UP);
            Assert.assertTrue(musicSection.isDisplayed());
            Assert.assertTrue(homeBtnIcon.isDisplayed());
            Assert.assertTrue(rewardsBtnIcon.isDisplayed());
            Assert.assertTrue(communityBtnIcon.isDisplayed());
            Assert.assertTrue(watchFacesBtnIcon.isDisplayed());
            Assert.assertTrue(settingsTab.isDisplayed());
        } else if (OS.equalsIgnoreCase("IOS")) {
            webDriverUtility =new IOSWebDriverUtility();
            Assert.assertTrue(watchConnectionStatusIcon.isDisplayed());
            Assert.assertTrue(sleepIcon.isDisplayed());
            Assert.assertTrue(stepsIcon.isDisplayed());
            Assert.assertTrue(multiSportIcon.isDisplayed());
            Assert.assertTrue(activeTaskSection.isDisplayed());
//            Assert.assertTrue(totalZetaPointCount.isDisplayed());
            Assert.assertTrue(myHealthSection.isDisplayed());
            webDriverUtility.scrollToElement(driver, "down", "label", "Articles for you");
            Assert.assertTrue(articlesSection.isDisplayed());
            Assert.assertTrue(musicSection.isDisplayed());
            Assert.assertTrue(homeBtnIcon.isDisplayed());
            Assert.assertTrue(rewardsBtnIcon.isDisplayed());
            Assert.assertTrue(communityBtnIcon.isDisplayed());
            Assert.assertTrue(watchFacesBtnIcon.isDisplayed());
            Assert.assertTrue(settingsTab.isDisplayed());
        }
    }

    public void checkIfAllComponentsOfFitnessCardAreDisplayed(){
        Assert.assertTrue(sleepProgressBar.isDisplayed());
        Assert.assertTrue(sleepIcon.isDisplayed());
        Assert.assertTrue(sleepAchievedTxt.isDisplayed());
        Assert.assertTrue(sleepTargetTxt.isDisplayed());
        Assert.assertTrue(stepsProgressBar.isDisplayed());
        Assert.assertTrue(stepsIcon.isDisplayed());
        Assert.assertTrue(stepsAchievedTxt.isDisplayed());
        Assert.assertTrue(stepsTargetTxt.isDisplayed());
        Assert.assertTrue(multiSportProgressBar.isDisplayed());
        Assert.assertTrue(multiSportIcon.isDisplayed());
        Assert.assertTrue(multiSportAchievedTxt.isDisplayed());
        Assert.assertTrue(multiSportTargetTxt.isDisplayed());
    }

    public void checkIfConnectedDisconnectedIconIsDisplayed(){
        Assert.assertTrue(watchConnectionStatusIcon.isDisplayed());
    }

    public void clickOnEditInMyHealthSection(){
        editMyHealthOptionsBtn.click();
    }

    public void swipeToMyHealthSection(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            webDriverUtility=new AndroidWebDriverUtility();
        } else if (OS.equalsIgnoreCase("IOS")) {
            webDriverUtility=new IOSWebDriverUtility();
        }
        webDriverUtility.swipeByElements(driver, myHealthSection, stepsIcon, 2);
    }

    public void swipeToTheBottomOfTheDashboard(WebDriver driver){
        webDriverUtility =new AndroidWebDriverUtility();
        webDriverUtility.swipeByElements(driver, editMyHealthOptionsBtn, logo, 2);
        WebDriverUtility.waitForElementToBeVisible(driver, articleImage, 10);
        webDriverUtility.swipeByElements(driver, articlesSection, logo, 1);
    }

    public void clickOnHeartRateUnderMyHealth(){
        heartRateHealthCard.click();
    }

    public void clickOnSleepUnderMyHealth(){
        sleepHealthCard.click();
    }

    public void clickOnBloodOxygenUnderMyHealth(){
        bloodOxygenHealthCard.click();
    }

    public void clickOnMultiSportUnderMyHealth(){
        multiSportHealthCard.click();
    }

    public void clickOnMyCycleUnderMyHealth(){
        myCycleHealthCard.click();
    }

    public String getContentDescAttributeFromWatchConnectionIcon(){
        return watchConnectionStatusIcon.getAttribute("content-desc");
    }

    public void checkIfConnectedIconIsDisplayed(String OS){
        if (OS.equalsIgnoreCase("Android")){
            Assert.assertTrue(watchConnectionStatusIcon.getAttribute("content-desc").equals("CONNECTED"));
        } else if (OS.equalsIgnoreCase("IOS")) {
            Assert.assertTrue(watchConnectionStatusIcon.getAttribute("name").contains("paired"));
        }
    }

    public void checkIfDisconnectedIconIsDisplayed(){
        Assert.assertTrue(watchConnectionStatusIcon.getAttribute("content-desc").equals("DISCONNECTED"));
    }

    public void checkIfStepsAchievedIsDisplayed(){
        Assert.assertTrue(stepsAchievedTxt.isDisplayed());
    }

    public void checkIfSleepAchievedIsDisplayed(){
        Assert.assertTrue(sleepAchievedTxt.isDisplayed());
    }

    public void checkIfMultiSportAchievedIsDisplayed(){
        Assert.assertTrue(multiSportAchievedTxt.isDisplayed());
    }

    public void checkIfDataHasBeenSyncedFewSecondsAgo(){
        Assert.assertTrue(secondsAgoSyncTime.isDisplayed());
    }

    public String fetchStepTargetDataFromActivityCards(){
        return stepsTargetTxt.getText();
    }

    public String fetchSleepTargetDataFromActivityCards(){
        return sleepTargetTxt.getText();
    }

    public String fetchMultiSportTargetDataFromActivityCards(){
        return multiSportTargetTxt.getText();
    }

    public String fetchStepAchievedDataFromActivityCards(){
        return stepsAchievedTxt.getText();
    }

    public String fetchSleepAchievedDataFromActivityCards(){
        return sleepAchievedTxt.getText();
    }

    public String fetchMultiSportAchievedDataFromActivityCards(){
        return multiSportAchievedTxt.getText();
    }

    public void swipeToSecondActiveTaskFromFirstActiveTask(WebDriver driver){
        webDriverUtility =new AndroidWebDriverUtility();
        webDriverUtility.swipeByElements(driver, secondActiveTaskIcon, firstActiveTaskIcon, 1000);
    }

    public void checkIfFirstActiveTaskIsDisplayed(){
        Assert.assertTrue(firstActiveTaskIcon.isDisplayed());
    }

    public void checkIfSecondActiveTaskIsDisplayed(){
        Assert.assertTrue(secondActiveTaskIcon.isDisplayed());
    }

    public void checkIfProgressPercentageIsDisplayedUnderEachActiveTaskIcon(WebDriver driver){
        Assert.assertTrue(firstActiveTaskProgPer.isDisplayed());
        webDriverUtility =new AndroidWebDriverUtility();
        webDriverUtility.swipeByElements(driver, secondActiveTaskIcon, firstActiveTaskIcon, 1000);
        Assert.assertTrue(firstActiveTaskProgPer.isDisplayed());
    }

    public void checkIfZetaPointsAreDisplayedForAllActiveTasks(WebDriver driver){
        webDriverUtility =new AndroidWebDriverUtility();
        webDriverUtility.swipeByElements(driver, firstActiveTaskIcon, secondActiveTaskIcon, 1000);
        Assert.assertTrue(firstActiveTaskZetaPts.isDisplayed());
    }

    public void checkIfSleepFeatureIsDisplayedUnderMyHealthSection(){
        Assert.assertTrue(sleepHealthCard.isDisplayed());
    }

    public void checkIfBloodOxygenFeatureIsDisplayedUnderMyHealthSection(){
        Assert.assertTrue(bloodOxygenHealthCard.isDisplayed());
    }

    public void checkIfMultiSportFeatureIsDisplayedUnderMyHealthSection(){
        Assert.assertTrue(multiSportHealthCard.isDisplayed());
    }

    public void checkIfMyCycleFeatureIsDisplayedUnderMyHealthSection(){
        Assert.assertTrue(myCycleHealthCard.isDisplayed());
    }

    public void checkIfHeartRateFeatureIsDisplayedUnderMyHealthSection(){
        Assert.assertTrue(heartRateHealthCard.isDisplayed());
    }

    public void checkIfTemperatureFeatureIsDisplayedUnderMyHealthSection(){
        Assert.assertTrue(temperatureHealthCard.isDisplayed());
    }

    public void checkIfMyCycleCardUnderMyHealthDisplaysCurrentDayAndRemainingDaysOfPeriod(){
        Assert.assertTrue(currentDayOfPeriod.isDisplayed());
        Assert.assertTrue(remainingDaysForNextPeriod.isDisplayed());
    }

    public int returnRemainingDaysForNextPeriodFromMyCycleCard(){
        String remainingDays=remainingDaysForNextPeriod.getText();
        JavaUtility javaUtility=new JavaUtility();
        return javaUtility.getOnlyNumberFromString(remainingDays);
    }

    public int returnCurrentDayOfPeriodFromMyCycleCard(){
        String currentDay=currentDayOfPeriod.getText();
        JavaUtility javaUtility=new JavaUtility();
        return javaUtility.getOnlyNumberFromString(currentDay);
    }

    public void checkIfPeriodStageIsDisplayed(){
        Assert.assertTrue(periodStage.isDisplayed());
    }

    public void checkIfHeartRateInBpmAndLastSyncedTimeIsDisplayedInHeartRateCard(){
        Assert.assertTrue(heartRateInBpm.isDisplayed());
        Assert.assertTrue(heartRateLastSyncedTime.isDisplayed());
    }

    public void clickOnViewAllUnderArticlesSection(){
        viewAllSavedArticlesLink.click();
    }

    public void checkIfArticlesSectionIsDisplayed(){
        Assert.assertTrue(articlesSection.isDisplayed());
    }

    public void clickOnHomeBtn(){
        homeBtnIcon.click();
    }

    public void horizontalSwipeOnTheScreen(WebDriver driver){
        webDriverUtility =new AndroidWebDriverUtility();
        webDriverUtility.swipeScreen(driver, WebDriverUtility.Direction.LEFT);
    }

    public void checkIfAllIconsAreDisplayedOnTheArticleImage(){
        Assert.assertTrue(popularArticleTag.isDisplayed());
        Assert.assertTrue(likeArticleIcon.isDisplayed());
        Assert.assertTrue(shareArticleIcon.isDisplayed());
        Assert.assertTrue(saveArticleIcon.isDisplayed());
    }

    public void clickOnLikeArticleBtn(){
        likeArticleIcon.click();
    }

    public void clickOnShareArticleBtn(){
        shareArticleIcon.click();
    }

    public void clickOnSaveArticleBtn(){
        saveArticleIcon.click();
    }

    public void checkIfNewTextIsDisplayedOnArticleImage(){
        if (newOrPopularIcon.getText().equals("New")){
            System.out.println("New is visible");
        } else {
            System.out.println("New is not visible");
        }
    }

    public void checkIfReadTickIsDisplayedOnTheArticleImage(){
        Assert.assertTrue(articleReadTickIcon.isDisplayed());
    }

    public void checkIfMusicSectionIsDisplayed(){
        Assert.assertTrue(musicSection.isDisplayed());
    }

    public void clickOnPlayMusicBtn(){
        playMusicBtn.click();
    }

    public String fetchTheTitleOfFirstArticle(){
        return articleTitle.getText();
    }

    public void clickOnFirstArticle(){
        articleImage.click();
    }

    public String fetchTheDimensionsOfStepsProgressCircle(){
        return stepsProgressBar.getAttribute("bounds");
    }

    public String fetchTheDimensionsOfSleepProgressCircle(){
        return sleepProgressBar.getAttribute("bounds");
    }

    public String fetchTheDimensionsOfMultiSportProgressCircle(){
        return multiSportProgressBar.getAttribute("bounds");
    }

    public void fetchTheLocationOfTheStepsProgressCircle(){
        Point locStep = stepsProgressBar.getLocation();

        int leftX = stepsProgressBar.getLocation().getX();
        int rightX = leftX + stepsProgressBar.getSize().getWidth();
        int middleX = (rightX + leftX) / 2;
        int upperY = stepsProgressBar.getLocation().getY();
        int lowerY = upperY + stepsProgressBar.getSize().getHeight();
        int middleY = (upperY + lowerY) / 2;
        Dimension size=stepsProgressBar.getSize();
        System.out.println("("+middleX+", "+middleY+")");
        System.out.println(size);
    }

    public String fetchTheDimensionsOfProgressCircleGroup(){
        return progressCircleGroup.getAttribute("bounds");
    }

    public String fetchTheDimensionsOfFirstHealthCard(){
        return firstHealthCard.getAttribute("bounds");
    }

    public String fetchTheDimensionsOfSecondHealthCard(){
        return secondHealthCard.getAttribute("bounds");
    }

    public String fetchTheDimensionsOfThirdHealthCard(){
        return thirdHealthCard.getAttribute("bounds");
    }

    public String fetchTheDimensionsOfFourthHealthCard(){
        return fourthHealthCard.getAttribute("bounds");
    }

    public String fetchTheDimensionsOfFifthHealthCard(){
        return fifthHealthCard.getAttribute("bounds");
    }

    public String fetchTheDimensionsOfHealthCardGroup(){
        return allHealthCards.getAttribute("bounds");
    }

    public String fetchTheDimensionsOfActiveTasksGroup(){
        return activeTaskGroup.getAttribute("bounds");
    }

    public String fetchTheDimensionsOfFirstActiveTask(){
        return firstActiveTask.getAttribute("bounds");
    }

    public String fetchTheDimensionsOfSecondActiveTask(){
        return secondActiveTask.getAttribute("bounds");
    }

    public void clickOnWatchFacesTab(){
        watchFacesBtnIcon.click();
    }

    public String fetchTheDimensionsOfProgressCircleGroupIOS(){
        int startX = progressCircleGroup.getLocation().getX();
        int startY = progressCircleGroup.getLocation().getY();
        int endX = progressCircleGroup.getSize().getWidth()+startX;
        int endY = progressCircleGroup.getSize().getHeight()+startY;
        String all = startX + " " + startY + " " + endX + " " + endY;
        return all;
    }

    public String fetchTheDimensionsOfStepProgressCircleIOS(){
        int startX = stepsProgressBar.getLocation().getX();
        int startY = stepsProgressBar.getLocation().getY();
        int endX = stepsProgressBar.getSize().getWidth()+startX;
        int endY = stepsProgressBar.getSize().getHeight()+startY;
        String all = startX + " " + startY + " " + endX + " " + endY;
        return all;
    }

    public String fetchTheDimensionsOfSleepProgressCircleIOS(){
        int startX = sleepProgressBar.getLocation().getX();
        int startY = sleepProgressBar.getLocation().getY();
        int endX = sleepProgressBar.getSize().getWidth()+startX;
        int endY = sleepProgressBar.getSize().getHeight()+startY;
        String all = startX + " " + startY + " " + endX + " " + endY;
        return all;
    }

    public String fetchTheDimensionsOfMultiSportProgressCircleIOS(){
        int startX = multiSportProgressBar.getLocation().getX();
        int startY = multiSportProgressBar.getLocation().getY();
        int endX = multiSportProgressBar.getSize().getWidth()+startX;
        int endY = multiSportProgressBar.getSize().getHeight()+startY;
        String all = startX + " " + startY + " " + endX + " " + endY;
        return all;
    }

    public String fetchTheDimensionsOfActiveTaskGroupIOS(){
        int startX = activeTaskGroup.getLocation().getX();
        int startY = activeTaskGroup.getLocation().getY();
        int endX = activeTaskGroup.getSize().getWidth()+startX;
        int endY = activeTaskGroup.getSize().getHeight()+startY;
        String all = startX + " " + startY + " " + endX + " " + endY;
        return all;
    }

    public String fetchTheDimensionsOfFirstActiveTaskIOS(){
        int startX = firstActiveTask.getLocation().getX();
        int startY = firstActiveTask.getLocation().getY();
        int endX = firstActiveTask.getSize().getWidth()+startX;
        int endY = firstActiveTask.getSize().getHeight()+startY;
        String all = startX + " " + startY + " " + endX + " " + endY;
        return all;
    }

    public String fetchTheDimensionsOfSecondActiveTaskIOS(){
        int startX = secondActiveTask.getLocation().getX();
        int startY = secondActiveTask.getLocation().getY();
        int endX = secondActiveTask.getSize().getWidth()+startX;
        int endY = secondActiveTask.getSize().getHeight()+startY;
        String all = startX + " " + startY + " " + endX + " " + endY;
        return all;
    }

    public String fetchTheDimensionsOfHealthCardGroupIOS(){
        int startX = fullFirstHealthCard.getLocation().getX();
        int startY = fullFirstHealthCard.getLocation().getY();
        int endX = fullThirdHealthCard.getSize().getWidth()+fullFourthHealthCard.getSize().getWidth()+startX;
        int endY = fullSecondHealthCard.getSize().getHeight()+fullFourthHealthCard.getSize().getHeight()+startY;
        String all = startX + " " + startY + " " + endX + " " + endY;
        return all;
    }

    public String fetchTheDimensionsOfFirstHealthCardIOS(){
        int startX = firstHealthCard.getLocation().getX();
        int startY = firstHealthCard.getLocation().getY();
        int endX = firstHealthCard.getSize().getWidth()+startX;
        int endY = firstHealthCard.getSize().getHeight()+startY;
        String all = startX + " " + startY + " " + endX + " " + endY;
        return all;
    }

    public String fetchTheDimensionsOfSecondHealthCardIOS(){
        int startX = secondHealthCard.getLocation().getX();
        int startY = secondHealthCard.getLocation().getY();
        int endX = secondHealthCard.getSize().getWidth()+startX;
        int endY = secondHealthCard.getSize().getHeight()+startY;
        String all = startX + " " + startY + " " + endX + " " + endY;
        return all;
    }

    public String fetchTheDimensionsOfThirdHealthCardIOS(){
        int startX = thirdHealthCard.getLocation().getX();
        int startY = thirdHealthCard.getLocation().getY();
        int endX = thirdHealthCard.getSize().getWidth()+startX;
        int endY = thirdHealthCard.getSize().getHeight()+startY;
        String all = startX + " " + startY + " " + endX + " " + endY;
        return all;
    }

    public String fetchTheDimensionsOfFourthHealthCardIOS(){
        int startX = fourthHealthCard.getLocation().getX();
        int startY = fourthHealthCard.getLocation().getY();
        int endX = fourthHealthCard.getSize().getWidth()+startX;
        int endY = fourthHealthCard.getSize().getHeight()+startY;
        String all = startX + " " + startY + " " + endX + " " + endY;
        return all;
    }

    public void swipeToTheElementOnTheDashboard1(WebDriver driver, String direction, String an, String av){
        webDriverUtility=new IOSWebDriverUtility();
        webDriverUtility.scrollToElement(driver, direction, an, av);
    }

    public void swipeToMyHealthSection1(WebDriver driver){
        webDriverUtility=new IOSWebDriverUtility();
//        utility.swipe(driver, "up", 750 , myHealthSection);
        webDriverUtility.swipeByElements(driver, myHealthSection, sleepIcon, 2);
    }

    public void clickOnCloseArticleSharepopUp(){
        closeArticlePopUp.click();
    }

    public void refreshDashboardScreen(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")){
            webDriverUtility=new AndroidWebDriverUtility();
            webDriverUtility.swipeScreen(driver, WebDriverUtility.Direction.DOWN);
        } else if (OS.equalsIgnoreCase("IOS")) {
            webDriverUtility=new IOSWebDriverUtility();
            webDriverUtility.swipeByElements(driver, stepsIcon, myHealthSection, 3);
        }
    }

    public String fetchTheLatestValueOfBloodPressureFromHealthCard(String OS){
        String bpValue=null;
        if (OS.equalsIgnoreCase("Android")){
            bpValue=bloodPressureValueUnderMyHealthOption.getText();
        } else if (OS.equalsIgnoreCase("IOS")) {
            bpValue=bloodPressureValueUnderMyHealthOption.getAttribute("name");
        }
        return bpValue;
    }

    public void clickOnBloodPressureUnderMyHealth(){
        bloodPressureHealthCard.click();
    }

    public void checkIfTemperatureIconIsDisplayedUnderMyHealthSection(){
        Assert.assertTrue(temperatureIconInHealthCard.isDisplayed());
    }

    public void checkIfLastMeasuredDateOrTimeForTemperatureIsDisplayedUnderMyHealthSection(){
        Assert.assertTrue(temperatureLastMeasuredDateOrTimeInHealthCard.isDisplayed());
    }

    public void checkIfLastMeasuredTemperatureValeIsDisplayedInTemperatureHealthCard(){
        Assert.assertTrue(recentTemperatureInHealthCard.isDisplayed());
    }

    public void clickOnTemperatureHealthCard(){
        temperatureHealthCard.click();
    }

    public String fetchTheTemperatureValueFromTemperatureCard(){
        return recentTemperatureInHealthCard.getText();
    }
}