package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class SetAMultiSportGoalPage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'back'") private WebElement backBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Min']/preceding-sibling::XCUIElementTypeButton/XCUIElementTypeStaticText") private WebElement multiSportGoalDuration;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypePickerWheel") private WebElement allMultiSportDurationValues;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Save Changes'") private WebElement saveChangesBtn;

    public SetAMultiSportGoalPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getMultiSportGoalDuration() {
        return multiSportGoalDuration;
    }

    public WebElement getSaveChangesBtn() {
        return saveChangesBtn;
    }

    public void clickOnMultiSportDuration(){
        multiSportGoalDuration.click();
    }

    public void swipeToDesiredMultiSportGoal(String multiSportDuration){
        allMultiSportDurationValues.sendKeys(multiSportDuration);
    }

    public void clickOnSaveBtn(){
        saveChangesBtn.click();
    }

    public void clickOnBackBtn(){
        backBtn.click();
    }
}
