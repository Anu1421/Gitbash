package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class WhenIsYourBirthdayPage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'back'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Save Changes']/preceding-sibling::XCUIElementTypeOther[2]//XCUIElementTypeTextField[1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/date_input"),
            @FindBy(id = "com.titan.smartworld:id/date_input")
    }) private WebElement dateTextEdit;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Save Changes']/preceding-sibling::XCUIElementTypeOther[2]//XCUIElementTypeTextField[2]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/month_input"),
            @FindBy(id = "com.titan.smartworld:id/month_input")
    }) private WebElement monthTextEdit;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Save Changes']/preceding-sibling::XCUIElementTypeOther[2]//XCUIElementTypeTextField[3]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/year_input"),
            @FindBy(id = "com.titan.smartworld:id/year_input")
    }) private WebElement yearTextEdit;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Save Changes'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/continue_button"),
            @FindBy(id = "com.titan.smartworld:id/continue_button")
    }) private WebElement saveChangesBtn;

    public WhenIsYourBirthdayPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getDateTextEdit() {
        return dateTextEdit;
    }

    public WebElement getMonthTextEdit() {
        return monthTextEdit;
    }

    public WebElement getYearTextEdit() {
        return yearTextEdit;
    }

    public WebElement getSaveChangesBtn() {
        return saveChangesBtn;
    }
}