package objectrepository;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EditPeriodCalendarPage {
    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Button'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == '2023'")
    @FindBy(xpath = "//android.widget.TextView[@text='2023']") private WebElement year2023;

    @FindBy(xpath = "//android.widget.TextView[@text='2022']") private WebElement year2022;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'January'")
    @FindBy(xpath = "//android.widget.TextView[@text='January']") private WebElement monthJanuary;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Save'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/btn_save"),
            @FindBy(id = "com.titan.smartworld:id/btn_save")
    }) private WebElement saveBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Discard'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/btn_discard"),
            @FindBy(id = "com.titan.smartworld:id/btn_discard")
    }) private WebElement discardBtn;

    public EditPeriodCalendarPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getYear2023() {
        return year2023;
    }

    public WebElement getYear2022() {
        return year2022;
    }

    public WebElement getMonthJanuary() {
        return monthJanuary;
    }

    public WebElement getSaveBtn() {
        return saveBtn;
    }

    public WebElement getDiscardBtn() {
        return discardBtn;
    }

    public void clickOnBackBtn(){
        backBtn.click();
    }

    public void clickOnDiscardBtn(){
        discardBtn.click();
    }
}