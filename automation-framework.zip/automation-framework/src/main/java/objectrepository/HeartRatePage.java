package objectrepository;

import genericutility.JavaUtility;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class HeartRatePage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic back Img'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'ic_hr_select'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/icon"),
            @FindBy(id = "com.titan.smartworld:id/icon")
    }) private WebElement heartRateIcon;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Heart Rate'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title"),
            @FindBy(id = "com.titan.smartworld:id/title")
    }) private WebElement pageTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic calendercommon'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/calendar"),
            @FindBy(id = "com.titan.smartworld:id/calendar")
    }) private WebElement calendarIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic calendercommon']/preceding-sibling::XCUIElementTypeOther[1]/XCUIElementTypeOther[1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/previous_icon"),
            @FindBy(id = "com.titan.smartworld:id/previous_icon")
    }) private WebElement previousBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic calendercommon']/preceding-sibling::XCUIElementTypeOther[1]/XCUIElementTypeOther[4]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/next_icon"),
            @FindBy(id = "com.titan.smartworld:id/next_icon")
    }) private WebElement nextBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic calendercommon']/preceding-sibling::XCUIElementTypeOther[1]/XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/date_text"),
            @FindBy(id = "com.titan.smartworld:id/date_text")
    }) private WebElement currentDate;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Day'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/day"),
            @FindBy(id = "com.titan.smartworld:id/day")
    }) private WebElement dayBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Week'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/week"),
            @FindBy(id = "com.titan.smartworld:id/week")
    }) private WebElement weekBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Month'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/month"),
            @FindBy(id = "com.titan.smartworld:id/month")
    }) private WebElement monthBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Maximum']/preceding-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.widget.TextView[@text='Maximum']/preceding-sibling::android.widget.TextView") private WebElement maximumHeartRate;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Average']/preceding-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.widget.TextView[@text='Average']/preceding-sibling::android.widget.TextView") private WebElement averageHeartRate;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/type_text_view"),
            @FindBy(id = "com.titan.smartworld:id/type_text_view")
    }) private WebElement yAxisParameterInHRGraph;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='BPM']/following-sibling::XCUIElementTypeOther[1]/XCUIElementTypeSlider") private WebElement heartRateGraphSlider;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='BPM']/following-sibling::XCUIElementTypeOther[3]/XCUIElementTypeSlider") private WebElement heartRateHourSlider;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='bottom nav icon'])[1]") private WebElement heartRateTab;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='bottom nav icon'])[2]") private WebElement bloodOxygenTab;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='bottom nav icon'])[3]") private WebElement bloodPressureTab;


    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/normal_percent_layout"),
            @FindBy(id = "com.titan.smartworld:id/normal_percent_layout")
    }) private WebElement normalHeartRateZone;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/warm_up_percent_layout"),
            @FindBy(id = "com.titan.smartworld:id/warm_up_percent_layout")
    }) private WebElement warmUpHeartRateZone;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/fat_burning_percent_layout"),
            @FindBy(id = "com.titan.smartworld:id/fat_burning_percent_layout")
    }) private WebElement fatBurningHeartRateZone;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/aerobic_percent_layout"),
            @FindBy(id = "com.titan.smartworld:id/aerobic_percent_layout")
    }) private WebElement aerobicHeartRateZone;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/anerobic_percent_layout"),
            @FindBy(id = "com.titan.smartworld:id/anerobic_percent_layout")
    }) private WebElement anaerobicHeartRateZone;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/extreme_percent_layout"),
            @FindBy(id = "com.titan.smartworld:id/extreme_percent_layout")
    }) private WebElement extremeHeartRateZone;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/normal_value"),
            @FindBy(id = "com.titan.smartworld:id/normal_value")
    }) private WebElement normalHeartRatePercentage;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/warm_up_value"),
            @FindBy(id = "com.titan.smartworld:id/warm_up_value")
    }) private WebElement warmUpHeartRatePercentage;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/fat_burn_value"),
            @FindBy(id = "com.titan.smartworld:id/fat_burn_value")
    }) private WebElement fatBurningHeartRatePercentage;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/aerobic_value"),
            @FindBy(id = "com.titan.smartworld:id/aerobic_value")
    }) private WebElement aerobicHeartRatePercentage;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/anerobic_value"),
            @FindBy(id = "com.titan.smartworld:id/anerobic_value")
    }) private WebElement anaerobicHeartRatePercentage;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/extreme_value"),
            @FindBy(id = "com.titan.smartworld:id/extreme_value")
    }) private WebElement extremeHeartRatePercentage;

    public HeartRatePage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getHeartRateIcon() {
        return heartRateIcon;
    }

    public WebElement getPageTitle() {
        return pageTitle;
    }

    public WebElement getCalendarIcon() {
        return calendarIcon;
    }

    public WebElement getPreviousBtn() {
        return previousBtn;
    }

    public WebElement getNextBtn() {
        return nextBtn;
    }

    public WebElement getDayBtn() {
        return dayBtn;
    }

    public WebElement getWeekBtn() {
        return weekBtn;
    }

    public WebElement getMonthBtn() {
        return monthBtn;
    }

    public WebElement getMaximumHeartRate() {
        return maximumHeartRate;
    }

    public WebElement getAverageHeartRate() {
        return averageHeartRate;
    }

    public WebElement getHeartRateTab() {
        return heartRateTab;
    }

    public WebElement getBloodOxygenTab() {
        return bloodOxygenTab;
    }

    public WebElement getBloodPressureTab() {
        return bloodPressureTab;
    }

    public WebElement getCurrentDate() {
        return currentDate;
    }

    public WebElement getyAxisParameterInHRGraph() {
        return yAxisParameterInHRGraph;
    }

    public WebElement getHeartRateGraphSlider() {
        return heartRateGraphSlider;
    }

    public WebElement getHeartRateHourSlider() {
        return heartRateHourSlider;
    }

    public WebElement getNormalHeartRateZone() {
        return normalHeartRateZone;
    }

    public WebElement getWarmUpHeartRateZone() {
        return warmUpHeartRateZone;
    }

    public WebElement getFatBurningHeartRateZone() {
        return fatBurningHeartRateZone;
    }

    public WebElement getAerobicHeartRateZone() {
        return aerobicHeartRateZone;
    }

    public WebElement getAnaerobicHeartRateZone() {
        return anaerobicHeartRateZone;
    }

    public WebElement getExtremeHeartRateZone() {
        return extremeHeartRateZone;
    }

    public WebElement getNormalHeartRatePercentage() {
        return normalHeartRatePercentage;
    }

    public WebElement getWarmUpHeartRatePercentage() {
        return warmUpHeartRatePercentage;
    }

    public WebElement getFatBurningHeartRatePercentage() {
        return fatBurningHeartRatePercentage;
    }

    public WebElement getAerobicHeartRatePercentage() {
        return aerobicHeartRatePercentage;
    }

    public WebElement getAnaerobicHeartRatePercentage() {
        return anaerobicHeartRatePercentage;
    }

    public WebElement getExtremeHeartRatePercentage() {
        return extremeHeartRatePercentage;
    }

    public void clickOnHeartRateBloodOxygenAndBloodPressureAndCLickOnBackBtn(){
        heartRateTab.click();
        bloodOxygenTab.click();
        bloodPressureTab.click();
        backBtn.click();
    }

    public void clickOnDayTab(){
        dayBtn.click();
    }

    public void clickOnWeekTab(){
        weekBtn.click();
    }

    public void clickOnPreviousBtn(){
        previousBtn.click();
    }

    public void clickOnMonthTab(){
        monthBtn.click();
    }

    public void clickOnBackBtn(){
        backBtn.click();
    }

    public void clickOnCalendarIcon(){
        calendarIcon.click();
    }

    public void checkIfUserLandsInHeartRatePage(){
        Assert.assertEquals(pageTitle.getText(), "Heart Rate");
    }

    public void checkIfUserLandsInSelectedDateHRPage(String date){
        Assert.assertEquals(date, currentDate.getText());
    }

    public void checkIfAllHRZonesAreDisplayed(){
        Assert.assertTrue(normalHeartRateZone.isDisplayed());
        Assert.assertTrue(warmUpHeartRateZone.isDisplayed());
        Assert.assertTrue(fatBurningHeartRateZone.isDisplayed());
        Assert.assertTrue(aerobicHeartRateZone.isDisplayed());
        Assert.assertTrue(anaerobicHeartRateZone.isDisplayed());
        Assert.assertTrue(extremeHeartRateZone.isDisplayed());
    }

    public void checkIfTotalHRPercentageIsHundred(){
        JavaUtility javaUtility=new JavaUtility();
        int normalHRPer=javaUtility.getOnlyNumberFromString(normalHeartRatePercentage.getText());
        int warmUpHRPer=javaUtility.getOnlyNumberFromString(warmUpHeartRatePercentage.getText());
        int fatBurningHRPer=javaUtility.getOnlyNumberFromString(fatBurningHeartRatePercentage.getText());
        int aerobicHRPer=javaUtility.getOnlyNumberFromString(aerobicHeartRatePercentage.getText());
        int anaerobicHRPer=javaUtility.getOnlyNumberFromString(anaerobicHeartRatePercentage.getText());
        int extremeHRPer=javaUtility.getOnlyNumberFromString(extremeHeartRatePercentage.getText());
        int totalPer=normalHRPer+warmUpHRPer+fatBurningHRPer+aerobicHRPer+anaerobicHRPer+extremeHRPer;
        Assert.assertTrue(totalPer==100);
    }

    public void checkIfHeartRateTitleAndIconIsDisplayed(){
        Assert.assertTrue(heartRateIcon.isDisplayed());
        Assert.assertTrue(pageTitle.getText().equals("Heart Rate"));
    }

    public void checkIfBPMIsDisplayedOnTheYAxisOfHRGraph(){
        Assert.assertTrue(yAxisParameterInHRGraph.getText().equals("BPM"));
    }

    public void moveHRGraphSlider(){
        heartRateGraphSlider.sendKeys("1.0");
    }

    public void moveHRHourSlider(){
        heartRateHourSlider.sendKeys("0.1");
    }
}