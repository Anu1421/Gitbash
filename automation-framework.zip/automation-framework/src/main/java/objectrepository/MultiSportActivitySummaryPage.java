package objectrepository;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class MultiSportActivitySummaryPage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic back Img'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic back Img']/following-sibling::XCUIElementTypeOther[1]/XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tvActivityType"),
            @FindBy(id = "com.titan.smartworld:id/tvActivityType")
    }) private WebElement activityTitle;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='path_8080']/following-sibling::XCUIElementTypeButton")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/previous_icon"),
            @FindBy(id = "com.titan.smartworld:id/previous_icon")
    }) private WebElement scrollBackBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='path_8081']/preceding-sibling::XCUIElementTypeButton")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/next_icon"),
            @FindBy(id = "com.titan.smartworld:id/next_icon")
    }) private WebElement scrollForwardBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Day'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/day"),
            @FindBy(id = "com.titan.smartworld:id/day")
    }) private WebElement dayTab;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Week'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/week"),
            @FindBy(id = "com.titan.smartworld:id/week")
    }) private WebElement weekTab;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Month'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/month"),
            @FindBy(id = "com.titan.smartworld:id/month")
    }) private WebElement monthTab;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'ic_calendercommon'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/calendar"),
            @FindBy(id = "com.titan.smartworld:id/calendar")
    }) private WebElement calendarIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='BPM']/following-sibling::XCUIElementTypeStaticText[1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tvLastActivityName"),
            @FindBy(id = "com.titan.smartworld:id/tvLastActivityName")
    }) private WebElement activityName;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Distance']/preceding-sibling::XCUIElementTypeStaticText[@name='Steps']/preceding-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.widget.TextView[@text='Steps']/../android.widget.TextView[1]") private WebElement stepsCount;

    @iOSXCUITFindBy(iOSNsPredicate = "label ENDSWITH ' m'")
    @FindBy(xpath = "//android.widget.TextView[@text='Distance']/../android.widget.TextView[1]") private WebElement distanceCount;

    @iOSXCUITFindBy(iOSNsPredicate = "label ENDSWITH 'Cal'")
    @FindBy(xpath = "//android.widget.TextView[@text='Calories']/../android.widget.TextView[1]") private WebElement caloriesCount;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Avg. Heart Rate']/preceding-sibling::XCUIElementTypeStaticText[contains(@name, 'bpm')]")
    @FindBy(xpath = "//android.widget.TextView[@text='Avg. Heart Rate']/../android.widget.TextView[1]") private WebElement avgHeartRateDuringActivity;

    @iOSXCUITFindBy(iOSNsPredicate = "label ENDSWITH '\"'")
    @FindBy(xpath = "//android.widget.TextView[@text='Avg. Pace']/../android.widget.TextView[1]") private WebElement avgPaceDuringActivity;

    @iOSXCUITFindBy(iOSNsPredicate = "label ENDSWITH 'Sec'")
    @FindBy(xpath = "//android.widget.TextView[@text='Duration']/../android.widget.TextView[1]") private WebElement durationOfActivity;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Heart Rate'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/type_unit_text_view"),
            @FindBy(id = "com.titan.smartworld:id/type_unit_text_view")
    }) private WebElement graphTitle;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Duration']/following-sibling::XCUIElementTypeStaticText[contains(@name, 'bpm')]") private WebElement bpmInSpindle;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'BPM'")
    @FindBy(id = "com.titan.fastrack.reflex:id/type_text_view") private WebElement yAxisParameterInBPMGraph;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/normal_value"),
            @FindBy(id = "com.titan.smartworld:id/normal_value")
    }) private WebElement normalHeartRatePercentage;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/warm_up_value"),
            @FindBy(id = "com.titan.smartworld:id/warm_up_value")
    }) private WebElement warmUpHeartRatePercentage;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/fat_burn_value"),
            @FindBy(id = "com.titan.smartworld:id/fat_burn_value")
    }) private WebElement fatBurningHeartRatePercentage;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/aerobic_value"),
            @FindBy(id = "com.titan.smartworld:id/aerobic_value")
    }) private WebElement aerobicHeartRatePercentage;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/anerobic_value"),
            @FindBy(id = "com.titan.smartworld:id/anerobic_value")
    }) private WebElement anerobicHeartRatePercentage;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/extreme_value"),
            @FindBy(id = "com.titan.smartworld:id/extreme_value")
    }) private WebElement extremeHeartRatePercentage;

    public MultiSportActivitySummaryPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getActivityTitle() {
        return activityTitle;
    }

    public WebElement getScrollBackBtn() {
        return scrollBackBtn;
    }

    public WebElement getScrollForwardBtn() {
        return scrollForwardBtn;
    }

    public WebElement getDayTab() {
        return dayTab;
    }

    public WebElement getWeekTab() {
        return weekTab;
    }

    public WebElement getMonthTab() {
        return monthTab;
    }

    public WebElement getCalendarIcon() {
        return calendarIcon;
    }

    public WebElement getActivityName() {
        return activityName;
    }

    public WebElement getStepsCount() {
        return stepsCount;
    }

    public WebElement getDistanceCount() {
        return distanceCount;
    }

    public WebElement getCaloriesCount() {
        return caloriesCount;
    }

    public WebElement getAvgHeartRateDuringActivity() {
        return avgHeartRateDuringActivity;
    }

    public WebElement getAvgPaceDuringActivity() {
        return avgPaceDuringActivity;
    }

    public WebElement getDurationOfActivity() {
        return durationOfActivity;
    }

    public WebElement getGraphTitle() {
        return graphTitle;
    }

    public WebElement getBpmInSpindle() {
        return bpmInSpindle;
    }

    public WebElement getyAxisParameterInBPMGraph() {
        return yAxisParameterInBPMGraph;
    }

    public WebElement getNormalHeartRatePercentage() {
        return normalHeartRatePercentage;
    }

    public WebElement getWarmUpHeartRatePercentage() {
        return warmUpHeartRatePercentage;
    }

    public WebElement getFatBurningHeartRatePercentage() {
        return fatBurningHeartRatePercentage;
    }

    public WebElement getAerobicHeartRatePercentage() {
        return aerobicHeartRatePercentage;
    }

    public WebElement getAnerobicHeartRatePercentage() {
        return anerobicHeartRatePercentage;
    }

    public WebElement getExtremeHeartRatePercentage() {
        return extremeHeartRatePercentage;
    }

    public void clickOnBackBtn(){
        backBtn.click();
    }

    public void scrollBetweenDifferentActivities(){
        scrollForwardBtn.click();
        scrollBackBtn.click();
    }

    public void clickOnThisWeekTab(){
        weekTab.click();
    }

    public void clickOnThisMonthTab(){
        monthTab.click();
    }

    public void checkIfAllRunningOrWalkingOrHikingParametersAreDisplayed(){
        Assert.assertTrue(stepsCount.isDisplayed());
        Assert.assertTrue(distanceCount.isDisplayed());
        Assert.assertTrue(caloriesCount.isDisplayed());
        Assert.assertTrue(avgHeartRateDuringActivity.isDisplayed());
        Assert.assertTrue(avgPaceDuringActivity.isDisplayed());
        Assert.assertTrue(durationOfActivity.isDisplayed());
    }

    public void checkIfAllOtherMultiSportParametersAreDisplayed(){
        Assert.assertTrue(caloriesCount.isDisplayed());
        Assert.assertTrue(avgHeartRateDuringActivity.isDisplayed());
        Assert.assertTrue(durationOfActivity.isDisplayed());
    }

    public void checkIfAllFootballOrCricketOrRugbyParametersAreDisplayed(){
        Assert.assertTrue(stepsCount.isDisplayed());
        Assert.assertTrue(caloriesCount.isDisplayed());
        Assert.assertTrue(avgHeartRateDuringActivity.isDisplayed());
        Assert.assertTrue(durationOfActivity.isDisplayed());
    }

    public void checkIfBPMIsDisplayedAsYAxisParameterForActivityGraph(String OS){
        if (OS.equalsIgnoreCase("Android")) {
            Assert.assertEquals(yAxisParameterInBPMGraph.getText(), "BPM");
        } else if (OS.equalsIgnoreCase("IOS")){
            Assert.assertEquals(yAxisParameterInBPMGraph.getAttribute("name"), "BPM");
        }
    }
}