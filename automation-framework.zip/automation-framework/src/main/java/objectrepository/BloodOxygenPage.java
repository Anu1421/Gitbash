package objectrepository;

import io.appium.java_client.pagefactory.iOSXCUITBy;
import io.appium.java_client.pagefactory.iOSXCUITFindAll;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class BloodOxygenPage {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic back Img'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'ic_spo2Common'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/icon"),
            @FindBy(id = "com.titan.smartworld:id/icon")
    }) private WebElement bloodOxygenIcon;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == 'Blood oxygen'`][1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title"),
            @FindBy(id = "com.titan.smartworld:id/title")
    }) private WebElement pageTitle;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Blood oxygen']/following-sibling::XCUIElementTypeOther//XCUIElementTypeStaticText)[1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/date_text"),
            @FindBy(id = "com.titan.smartworld:id/date_text")
    }) private WebElement currentDate;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic calendercommon'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/calendar"),
            @FindBy(id = "com.titan.smartworld:id/calendar")
    }) private WebElement calendarIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Blood oxygen']/following-sibling::XCUIElementTypeOther/XCUIElementTypeOther[1]//XCUIElementTypeButton")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/previous_icon"),
            @FindBy(id = "com.titan.smartworld:id/previous_icon")
    }) private WebElement previousBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Blood oxygen']/following-sibling::XCUIElementTypeOther/XCUIElementTypeOther[4]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/next_icon"),
            @FindBy(id = "com.titan.smartworld:id/next_icon")
    }) private WebElement nextBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Day'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/day"),
            @FindBy(id = "com.titan.smartworld:id/day")
    }) private WebElement dayBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Week'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/week"),
            @FindBy(id = "com.titan.smartworld:id/week")
    }) private WebElement weekBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Month'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/month"),
            @FindBy(id = "com.titan.smartworld:id/month")
    }) private WebElement monthBtn;

    @iOSXCUITFindAll({
            @iOSXCUITBy(xpath = "//XCUIElementTypeStaticText[@name='Latest']/preceding-sibling::XCUIElementTypeStaticText"),
            @iOSXCUITBy(xpath = "//XCUIElementTypeStaticText[@name='Average']/preceding-sibling::XCUIElementTypeStaticText")
    })
    @FindAll({
            @FindBy(xpath = "//android.widget.TextView[@text='Latest']/preceding-sibling::android.widget.TextView[1]"),
            @FindBy(xpath = "//android.widget.TextView[@text='Average']/preceding-sibling::android.widget.TextView[1]")
    }) private WebElement latestOrAverageBloodOxygenLevel;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Maximum']/preceding-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.widget.TextView[@text='Maximum']/preceding-sibling::android.widget.TextView[1]") private WebElement maximumBloodOxygenLevel;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Minimum']/preceding-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.widget.TextView[@text='Minimum']/preceding-sibling::android.widget.TextView[1]") private WebElement minimumBloodOxygenLevel;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='bottom nav icon'])[1]") private WebElement heartRateTab;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='bottom nav icon'])[2]") private WebElement bloodOxygenTab;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='bottom nav icon'])[3]") private WebElement bloodPressureTab;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Blood oxygen'])[2]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title_fat_burns"),
            @FindBy(id = "com.titan.smartworld:id/title_fat_burns")
    }) private WebElement bloodOxygenTile;

    public BloodOxygenPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getBloodOxygenIcon() {
        return bloodOxygenIcon;
    }

    public WebElement getPageTitle() {
        return pageTitle;
    }

    public WebElement getCurrentDate() {
        return currentDate;
    }

    public WebElement getCalendarIcon() {
        return calendarIcon;
    }

    public WebElement getPreviousBtn() {
        return previousBtn;
    }

    public WebElement getNextBtn() {
        return nextBtn;
    }

    public WebElement getDayBtn() {
        return dayBtn;
    }

    public WebElement getWeekBtn() {
        return weekBtn;
    }

    public WebElement getMonthBtn() {
        return monthBtn;
    }

    public WebElement getLatestOrAverageBloodOxygenLevel() {
        return latestOrAverageBloodOxygenLevel;
    }

    public WebElement getMaximumBloodOxygenLevel() {
        return maximumBloodOxygenLevel;
    }

    public WebElement getMinimumBloodOxygenLevel() {
        return minimumBloodOxygenLevel;
    }

    public WebElement getHeartRateTab() {
        return heartRateTab;
    }

    public WebElement getBloodOxygenTab() {
        return bloodOxygenTab;
    }

    public WebElement getBloodPressureTab() {
        return bloodPressureTab;
    }

    public WebElement getBloodOxygenTile() {
        return bloodOxygenTile;
    }

    public void checkIfUserLandsInBloodOxygenScreen(String OS){
        String pgTitle=null;
        if (OS.equalsIgnoreCase("Android")){
            pgTitle=pageTitle.getText();
        } else if (OS.equalsIgnoreCase("IOS")) {
            pgTitle=pageTitle.getAttribute("name");
        }
        Assert.assertTrue(pgTitle.equalsIgnoreCase("Blood Oxygen"));
    }

    public void checkIfMaxMinAndLatestBloodOxygenPercentagesAreDisplayed(){
        Assert.assertTrue(latestOrAverageBloodOxygenLevel.isDisplayed());
        Assert.assertTrue(maximumBloodOxygenLevel.isDisplayed());
        Assert.assertTrue(minimumBloodOxygenLevel.isDisplayed());
    }

    public void clickOnPreviousBtn(){
        previousBtn.click();
    }

    public void checkIfUserLandsInPreviousDay(String OS){
        String day=null;
        if (OS.equalsIgnoreCase("Android")){
            day=currentDate.getText();
        } else if (OS.equalsIgnoreCase("IOS")) {
            day=currentDate.getAttribute("name");
        }
        Assert.assertTrue(day.equals("Yesterday"));
    }

    public void clickOnWeekTab(){
        weekBtn.click();
    }

    public void clickOnMonthTab(){
        monthBtn.click();
    }

    public void checkIfUserLandsInSelectedDateSleepPage(String date, String OS){
        String curDate=null;
        if (OS.equalsIgnoreCase("Android")){
            curDate=currentDate.getText();
        } else if (OS.equalsIgnoreCase("IOS")) {
            curDate=currentDate.getAttribute("name");
        }
        Assert.assertTrue(curDate.equals(date));
    }

    public void checkIfMaxMinAndAvgBloodOxygenPercentagesAreDisplayed(){
        Assert.assertTrue(latestOrAverageBloodOxygenLevel.isDisplayed());
        Assert.assertTrue(maximumBloodOxygenLevel.isDisplayed());
        Assert.assertTrue(minimumBloodOxygenLevel.isDisplayed());
    }

    public void clickOnCalendarIcon(){
        calendarIcon.click();
    }

    public void checkIfBloodOxygenTileIsDisplayed(){
        Assert.assertTrue(bloodOxygenTile.isDisplayed());
    }

    public void clickOnBackBtn(){
        backBtn.click();
    }
}