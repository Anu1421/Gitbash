package objectrepository;

import genericutility.AndroidWebDriverUtility;
import genericutility.WebDriverUtility;
import genericutility.IOSWebDriverUtility;
import io.appium.java_client.pagefactory.iOSXCUITBy;
import io.appium.java_client.pagefactory.iOSXCUITFindAll;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class WatchFacesPage {

    WebDriverUtility webdriverUtility;

    @FindBy(xpath = "//android.widget.ImageView[@content-desc='back button']") private WebElement backBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Watch faces']/preceding-sibling::XCUIElementTypeImage")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/icon"),
            @FindBy(id = "com.titan.smartworld:id/icon")
    })
    private WebElement watchFacesPageIcon;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Watch faces'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title"),
            @FindBy(id = "com.titan.smartworld:id/title")
    }) private WebElement pageTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Explore'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/explore"),
            @FindBy(id = "com.titan.smartworld:id/explore")
    }) private WebElement exploreWatchFacesBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'My Watch faces'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/my_watchfaces"),
            @FindBy(id = "com.titan.smartworld:id/my_watchfaces")
    }) private WebElement myWatchFacesBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Custom'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/custom"),
            @FindBy(id = "com.titan.smartworld:id/custom")
    }) private WebElement customWatchFacesBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "value BEGINSWITH 'Search'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_search"),
            @FindBy(id = "com.titan.smartworld:id/tv_search")
    }) private WebElement searchWatchFacesTxtEdit;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='Watch faces'])[1]") private WebElement watchFace1;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='Watch faces'])[2]") private WebElement watchFace2;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='Watch faces'])[3]") private WebElement watchFace3;

    @FindBy(xpath = "(//android.widget.ImageView[@content-desc='Watch faces'])[4]") private WebElement watchFace4;

    @iOSXCUITFindBy(iOSNsPredicate = "name BEGINSWITH 'Vibes' AND type == 'XCUIElementTypeOther'")
    @FindBy(xpath = "//android.widget.TextView[contains(@text,'Vibes')]") private WebElement watchFaceCategoryVibes;

    @iOSXCUITFindAll({
            @iOSXCUITBy(xpath = "//XCUIElementTypeOther[contains(@name,'Vibes')]//XCUIElementTypeButton[@name='View all']"),
            @iOSXCUITBy(xpath = "//XCUIElementTypeOther[contains(@name,'Vibes')]//XCUIElementTypeStaticText[@name='View all']")
    }) private WebElement viewAllVibesCategory;

    @iOSXCUITFindBy(iOSNsPredicate = "name BEGINSWITH 'Progression' AND type == 'XCUIElementTypeOther'")
    @FindBy(xpath = "//android.widget.TextView[contains(@text,'Progression')]") private WebElement watchFaceCategoryProgression;

    @iOSXCUITFindAll({
            @iOSXCUITBy(xpath = "//XCUIElementTypeOther[contains(@name,'Progression')]/XCUIElementTypeButton[@name='View all']"),
            @iOSXCUITBy(xpath = "//XCUIElementTypeOther[contains(@name,'Progression')]//XCUIElementTypeStaticText[@name='View all']"),
            @iOSXCUITBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Progression')]/following-sibling::XCUIElementTypeButton[1]")
    }) private WebElement viewAllProgressionCategory;

    @iOSXCUITFindBy(iOSNsPredicate = "name BEGINSWITH 'Sporty' AND type == 'XCUIElementTypeOther'")
    @FindBy(xpath = "//android.widget.TextView[contains(@text,'Sporty')]") private WebElement watchFaceCategorySporty;

    @iOSXCUITFindAll({
            @iOSXCUITBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Sporty')]/following-sibling::XCUIElementTypeButton[@name='View all']"),
            @iOSXCUITBy(xpath = "//XCUIElementTypeOther[contains(@name,'Sporty')]//XCUIElementTypeStaticText[@name='View all']")
    }) private WebElement viewAllSportyCategory;

    @iOSXCUITFindBy(iOSNsPredicate = "name BEGINSWITH 'Analog' AND type == 'XCUIElementTypeOther'")
    @FindBy(xpath = "//android.widget.TextView[contains(@text,'Analog')]") private WebElement watchFaceCategoryAnalog;

    @iOSXCUITFindAll({
            @iOSXCUITBy(xpath = "//XCUIElementTypeOther[contains(@name,'Analog')]/following-sibling::XCUIElementTypeButton[@name='View all'][1]"),
            @iOSXCUITBy(xpath = "//XCUIElementTypeOther[contains(@name,'Analog')]//XCUIElementTypeStaticText[@name='View all']")
    }) private WebElement viewAllAnalogCategory;

    @iOSXCUITFindBy(iOSNsPredicate = "name BEGINSWITH 'Casual' AND type == 'XCUIElementTypeOther'")
    @FindBy(xpath = "//android.widget.TextView[contains(@text,'Casual')]") private WebElement watchFaceCategoryCasual;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Casual')]/following-sibling::XCUIElementTypeButton[@name='View all'][1]") private WebElement viewAllCasualCategory;

    @iOSXCUITFindBy(iOSNsPredicate = "name BEGINSWITH 'Animated' AND type == 'XCUIElementTypeOther'")
    @FindBy(xpath = "//android.widget.TextView[contains(@text,'Animated')]") private WebElement watchFaceCategoryAnimated;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Animated')]/following-sibling::XCUIElementTypeButton[@name='View all']") private WebElement viewAllAnimatedCategory;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='Progression (9)']/preceding-sibling::XCUIElementTypeCell/XCUIElementTypeButton[1]") private WebElement saveWatchFaceBtn1;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[contains(@name,'Casual')]/following-sibling::XCUIElementTypeCell[1]/XCUIElementTypeButton[1]") private WebElement saveWatchFaceBtn2;

    @FindBy(xpath = "//android.widget.Toast") private WebElement toastMessage;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Watch faces']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeOther[1]//XCUIElementTypeCell[1]")
    @FindBy(xpath = "//android.widget.FrameLayout[@content-desc='Home']") private WebElement dashboardBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Watch faces']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeOther[1]//XCUIElementTypeCell[2]")
    @FindBy(xpath = "//android.widget.FrameLayout[@content-desc='Rewards']") private WebElement rewardsBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Watch faces']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeOther[1]//XCUIElementTypeCell[3]")
    @FindBy(xpath = "//android.widget.FrameLayout[@content-desc='Community']") private WebElement communityBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Watch faces']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeOther[1]//XCUIElementTypeCell[4]")
    @FindBy(xpath = "//android.widget.FrameLayout[@content-desc='Watch faces']") private WebElement watchFacesBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Watch faces']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeOther[1]//XCUIElementTypeCell[5]")
    @FindBy(xpath = "//android.widget.FrameLayout[@content-desc='Settings']") private WebElement settingsBtn;

    public WatchFacesPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getExploreWatchFacesBtn() {
        return exploreWatchFacesBtn;
    }

    public WebElement getMyWatchFacesBtn() {
        return myWatchFacesBtn;
    }

    public WebElement getCustomWatchFacesBtn() {
        return customWatchFacesBtn;
    }

    public WebElement getSearchWatchFacesTxtEdit() {
        return searchWatchFacesTxtEdit;
    }

    public WebElement getWatchFace1() {
        return watchFace1;
    }

    public WebElement getWatchFace2() {
        return watchFace2;
    }

    public WebElement getWatchFace3() {
        return watchFace3;
    }

    public WebElement getWatchFace4() {
        return watchFace4;
    }

    public WebElement getWatchFaceCategoryVibes() {
        return watchFaceCategoryVibes;
    }

    public WebElement getWatchFaceCategoryProgression() {
        return watchFaceCategoryProgression;
    }

    public WebElement getWatchFaceCategorySporty() {
        return watchFaceCategorySporty;
    }

    public WebElement getWatchFaceCategoryAnalog() {
        return watchFaceCategoryAnalog;
    }

    public WebElement getWatchFaceCategoryCasual() {
        return watchFaceCategoryCasual;
    }

    public WebElement getWatchFaceCategoryAnimated() {
        return watchFaceCategoryAnimated;
    }

    public WebElement getWatchFacesPageIcon() {
        return watchFacesPageIcon;
    }

    public WebElement getPageTitle() {
        return pageTitle;
    }

    public WebElement getViewAllVibesCategory() {
        return viewAllVibesCategory;
    }

    public WebElement getViewAllProgressionCategory() {
        return viewAllProgressionCategory;
    }

    public WebElement getViewAllSportyCategory() {
        return viewAllSportyCategory;
    }

    public WebElement getViewAllAnalogCategory() {
        return viewAllAnalogCategory;
    }

    public WebElement getViewAllCasualCategory() {
        return viewAllCasualCategory;
    }

    public WebElement getViewAllAnimatedCategory() {
        return viewAllAnimatedCategory;
    }

    public WebElement getSaveWatchFaceBtn1() {
        return saveWatchFaceBtn1;
    }

    public WebElement getSaveWatchFaceBtn2() {
        return saveWatchFaceBtn2;
    }

    public WebElement getToastMessage() {
        return toastMessage;
    }

    public WebElement getDashboardBtn() {
        return dashboardBtn;
    }

    public WebElement getRewardsBtn() {
        return rewardsBtn;
    }

    public WebElement getCommunityBtn() {
        return communityBtn;
    }

    public WebElement getWatchFacesBtn() {
        return watchFacesBtn;
    }

    public WebElement getSettingsBtn() {
        return settingsBtn;
    }

    public void scrollVerticallyThroughWatchFaceCategories(AndroidDriver driver){
        webdriverUtility=new AndroidWebDriverUtility();
        WebDriverUtility.waitForElementToBeVisible(driver, watchFaceCategoryVibes, 10);
        webdriverUtility.swipeScreen(driver, WebDriverUtility.Direction.UP);
    }

    public void scrollHorizontallyThroughWatchFaces(WebDriver driver, String OS, int num){
        if (OS.equalsIgnoreCase("Android")) {
//        webdriverUtility.swipeScreen(driver, WebdriverUtility.Direction.LEFT);
            for (int i = 0; i <= 5; i++) {
                webdriverUtility = new AndroidWebDriverUtility();
                webdriverUtility.swipeByElements(driver, watchFace2, watchFace1, 2);
            }
        } else if (OS.equalsIgnoreCase("IOS")){
            if (num==0) {
                webdriverUtility = new IOSWebDriverUtility();
                webdriverUtility.swipe(driver, "left", 750, saveWatchFaceBtn1);
            } else if(num==1){
                webdriverUtility.swipe(driver, "left", 750, saveWatchFaceBtn2);
            }
        }
    }

    public void checkIfAllCategoriesAreDisplayed(WebDriver driver, String watchType, String OS){
        if (OS.equalsIgnoreCase("Android")) {
            webdriverUtility = new AndroidWebDriverUtility();
            if (watchType.equals("play") || watchType.equals("playPlus")) {
                Assert.assertTrue(watchFaceCategoryVibes.getText().contains("Vibes"));
                Assert.assertTrue(watchFaceCategoryProgression.getText().contains("Progression"));
                webdriverUtility.swipeByElements(driver, watchFaceCategoryProgression, watchFacesPageIcon, 2);
                Assert.assertTrue(watchFaceCategorySporty.getText().contains("Sporty"));
                Assert.assertTrue(watchFaceCategoryAnalog.getText().contains("Analog"));
                webdriverUtility.swipeByElements(driver, watchFaceCategoryAnalog, watchFacesPageIcon, 2);
                Assert.assertTrue(watchFaceCategoryCasual.getText().contains("Casual"));
                Assert.assertTrue(watchFaceCategoryAnimated.getText().contains("Animated"));
            } else if (watchType.equals("smartTalk")) {
                Assert.assertTrue(watchFaceCategoryVibes.getText().contains("Vibes"));
                Assert.assertTrue(watchFaceCategoryProgression.getText().contains("Progression"));
                webdriverUtility.swipeByElements(driver, watchFaceCategoryProgression, exploreWatchFacesBtn, 2);
                Assert.assertTrue(watchFaceCategoryAnalog.getText().contains("Analog"));
                Assert.assertTrue(watchFaceCategoryAnimated.getText().contains("Animated"));
                webdriverUtility.swipeByElements(driver, watchFaceCategoryAnimated, exploreWatchFacesBtn, 2);
                Assert.assertTrue(watchFaceCategoryCasual.getText().contains("Casual"));
                Assert.assertTrue(watchFaceCategorySporty.getText().contains("Sporty"));
            }
        } else if (OS.equalsIgnoreCase("IOS")) {
            webdriverUtility = new IOSWebDriverUtility();
            if (watchType.equals("play") || watchType.equals("playPlus")) {
                Assert.assertTrue(watchFaceCategoryVibes.getAttribute("name").contains("Vibes"));
                Assert.assertTrue(watchFaceCategoryProgression.getAttribute("name").contains("Progression"));
                webdriverUtility.swipeByElements(driver, watchFaceCategoryProgression, exploreWatchFacesBtn, 2);
                Assert.assertTrue(watchFaceCategorySporty.getAttribute("name").contains("Sporty"));
                Assert.assertTrue(watchFaceCategoryAnalog.getAttribute("name").contains("Analog"));
                webdriverUtility.swipeByElements(driver, watchFaceCategoryAnalog, exploreWatchFacesBtn, 2);
                Assert.assertTrue(watchFaceCategoryCasual.getAttribute("name").contains("Casual"));
                Assert.assertTrue(watchFaceCategoryAnimated.getAttribute("name").contains("Animated"));
            } else if (watchType.equals("smartTalk")) {
                Assert.assertTrue(watchFaceCategoryVibes.getAttribute("name").contains("Vibes"));
                Assert.assertTrue(watchFaceCategoryProgression.getAttribute("name").contains("Progression"));
                webdriverUtility.swipeByElements(driver, watchFaceCategoryProgression, exploreWatchFacesBtn, 2);
                Assert.assertTrue(watchFaceCategoryAnalog.getAttribute("name").contains("Analog"));
                Assert.assertTrue(watchFaceCategoryAnimated.getAttribute("name").contains("Animated"));
                webdriverUtility.swipeByElements(driver, watchFaceCategoryAnimated, exploreWatchFacesBtn, 2);
                Assert.assertTrue(watchFaceCategoryCasual.getAttribute("name").contains("Casual"));
                Assert.assertTrue(watchFaceCategorySporty.getAttribute("name").contains("Sporty"));
            }
        }
    }

    public void clickOnBackButton(){
        backBtn.click();
    }

    public void clickOnFirstWatchFace(){
        watchFace1.click();
    }

    public void checkIfProperToastMessageIsDisplayedWhenWatchIsNotConnected(WebDriver driver, String watchType){
        if (watchType.equals("play")||watchType.equals("playPlus")) {
            Assert.assertEquals(toastMessage.getText(), "Watch is not connected");
        } else if (watchType.equals("smartTalk")){
            WatchFacePreviewPage watchFacePreviewPage=new WatchFacePreviewPage(driver);
            watchFacePreviewPage.clickOnInstallOnWatchBtn();
            InstallOnWatchPopUp installOnWatchPopUp=new InstallOnWatchPopUp(driver);
            installOnWatchPopUp.clickOnInstallOnWatchBtn();
            installOnWatchPopUp.checkIfProperToastMessageIsDisplayedWhenWatchIsNotConnected();
            //Close the popup
            installOnWatchPopUp.clickOnClosePopUpBtn();
        }
    }

    public void clickOnDashboardTab(){
        dashboardBtn.click();
    }
}