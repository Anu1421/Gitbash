package objectrepository;

import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class BluetoothCallingPopUp {
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic close']/preceding-sibling::XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title_view"),
            @FindBy(id = "com.titan.smartworld:id/title_view")
    }) private WebElement popUpTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic close'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closeBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Enable' AND type == 'XCUIElementTypeButton'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/okay_button"),
            @FindBy(id = "com.titan.smartworld:id/okay_button")
    }) private WebElement enableBtn;

    public BluetoothCallingPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getPopUpTitle() {
        return popUpTitle;
    }

    public WebElement getCloseBtn() {
        return closeBtn;
    }

    public WebElement getEnableBtn() {
        return enableBtn;
    }

    public void clickOnEnableBtn(){
        enableBtn.click();
    }

    public void checkIfBluetoothCallingPopUpIsDisplayed(String OS){
        if (OS.equalsIgnoreCase("Android")) {
            Assert.assertTrue(popUpTitle.getText().equals("Bluetooth Calling"));
        } else if (OS.equalsIgnoreCase("IOS")) {
            Assert.assertTrue(popUpTitle.getAttribute("name").equals("Bluetooth Calling"));
        }
    }
}