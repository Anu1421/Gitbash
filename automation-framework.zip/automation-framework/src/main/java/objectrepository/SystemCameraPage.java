package objectrepository;

import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SystemCameraPage {
    @FindBy(id = "com.sec.android.app.camera:id/normal_center_button") private WebElement cameraShutterBtn;

    @FindBy(id = "com.sec.android.app.camera:id/switch_camera_button") private WebElement switchCameraBtn;

    @FindBy(id = "com.sec.android.app.camera:id/okay") private WebElement okBtn;

    @FindBy(id = "com.sec.android.app.camera:id/retry") private WebElement retryBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/btn_next"),
            @FindBy(id = "com.titan.smartworld:id/btn_next")
    }) private WebElement nextBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/btn_cancel"),
            @FindBy(id = "com.titan.smartworld:id/btn_cancel")
    }) private WebElement cancelBtn;

    public SystemCameraPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getCameraShutterBtn() {
        return cameraShutterBtn;
    }

    public WebElement getSwitchCameraBtn() {
        return switchCameraBtn;
    }

    public WebElement getOkBtn() {
        return okBtn;
    }

    public WebElement getRetryBtn() {
        return retryBtn;
    }

    public WebElement getNextBtn() {
        return nextBtn;
    }

    public WebElement getCancelBtn() {
        return cancelBtn;
    }

    public void captureImageAndSetAsProfilePic(){
        cameraShutterBtn.click();
        okBtn.click();
        nextBtn.click();
    }
}