package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class FindYourWatchPopUp {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic close'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closePopUpBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic close']/preceding-sibling::XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/title_view"),
            @FindBy(id = "com.titan.smartworld:id/title_view")
    }) private WebElement popUpTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Start Searching'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/okay_button"),
            @FindBy(id = "com.titan.smartworld:id/okay_button")
    }) private WebElement startSearchingBtn;

    public FindYourWatchPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getPopUpTitle() {
        return popUpTitle;
    }

    public WebElement getStartSearchingBtn() {
        return startSearchingBtn;
    }

    public void searchForYourWatch(){
        startSearchingBtn.click();
    }

    public void checkIfFindYourWatchPopUpIsDisplayed(){
        Assert.assertEquals(popUpTitle.getText(), "Find your Watch");
    }
}