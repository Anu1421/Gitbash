package objectrepository;

import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CameraAccessSystemPopUp {
    @FindBy(id = "com.android.permissioncontroller:id/permission_allow_foreground_only_button") private WebElement whileUsingTheAppOption;

    @FindBy(id = "com.android.permissioncontroller:id/permission_allow_one_time_button") private WebElement onlyThisTimeOption;

    @FindBy(id = "com.android.permissioncontroller:id/permission_deny_and_dont_ask_again_button") private WebElement denyOption;

    public CameraAccessSystemPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getWhileUsingTheAppOption() {
        return whileUsingTheAppOption;
    }

    public WebElement getOnlyThisTimeOption() {
        return onlyThisTimeOption;
    }

    public WebElement getDenyOption() {
        return denyOption;
    }

    public void clickOnAllowOnlyThisTimeOption(){
        onlyThisTimeOption.click();
    }
}