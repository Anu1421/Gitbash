package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

public class EnterYourEmailPage {

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'back'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/email_input"),
            @FindBy(id = "com.titan.smartworld:id/email_input")
    }) private WebElement emailIdTxtEdit;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Save Changes'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/continue_button"),
            @FindBy(id = "com.titan.smartworld:id/continue_button")
    }) private WebElement saveChangesBtn;

    public EnterYourEmailPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getEmailIdTxtEdit() {
        return emailIdTxtEdit;
    }

    public WebElement getSaveChangesBtn() {
        return saveChangesBtn;
    }
}