package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HighHRAlertPopUp {
    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic close'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closePopUpBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='High HR Alert']/following-sibling::XCUIElementTypeButton")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/tv_hr"),
            @FindBy(id = "com.titan.smartworld:id/tv_hr")
    }) private WebElement setHighHRLimit;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Turn Off'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/turn_off_button"),
            @FindBy(id = "com.titan.smartworld:id/turn_off_button")
    }) private WebElement turnOffHighHRAlert;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Update'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/update_button"),
            @FindBy(id = "com.titan.smartworld:id/update_button")
    }) private WebElement updateHighHRLimit;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Turn On'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/turn_on_button"),
            @FindBy(id = "com.titan.smartworld:id/turn_on_button")
    }) private WebElement turnOnHighHRAlert;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='High HR Alert']/following-sibling::XCUIElementTypeOther//XCUIElementTypeButton[1]") private WebElement turnOnOrOffHighHRAlert;

    public HighHRAlertPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getSetHighHRLimit() {
        return setHighHRLimit;
    }

    public WebElement getTurnOffHighHRAlert() {
        return turnOffHighHRAlert;
    }

    public WebElement getUpdateHighHRLimit() {
        return updateHighHRLimit;
    }

    public WebElement getTurnOnHighHRAlert() {
        return turnOnHighHRAlert;
    }

    public WebElement getTurnOnOrOffHighHRAlert() {
        return turnOnOrOffHighHRAlert;
    }

    public void clickOnSetHighHRLimit(){
        setHighHRLimit.click();
    }
}