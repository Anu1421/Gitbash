package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PermissionsPage {
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/checkbox"),
            @FindBy(id = "com.titan.smartworld:id/checkbox")
    }) private WebElement tAndCCheckbox;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/acceptBtn"),
            @FindBy(id = "com.titan.smartworld:id/acceptBtn")
    }) private WebElement acceptBtn;

    public PermissionsPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getTAndCCheckbox() {
        return tAndCCheckbox;
    }

    public WebElement getAcceptBtn() { return acceptBtn; }

    public void acceptPermissions(){
        tAndCCheckbox.click();
        acceptBtn.click();
    }
}
