package objectrepository;

import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GallerySelectItemPage {
    @FindBy(xpath = "(//android.widget.FrameLayout[@content-desc='Button'])[1]/android.widget.FrameLayout[2]") private WebElement imageSelection;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/btn_next"),
            @FindBy(id = "com.titan.smartworld:id/btn_next")
    }) private WebElement nextBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/btn_cancel"),
            @FindBy(id = "com.titan.smartworld:id/btn_cancel")
    }) private WebElement cancelBtn;

    public GallerySelectItemPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getImageSelection() {
        return imageSelection;
    }

    public WebElement getNextBtn() {
        return nextBtn;
    }

    public WebElement getCancelBtn() {
        return cancelBtn;
    }

    public void selectImageAndClickOnNext(){
        imageSelection.click();
        nextBtn.click();
    }
}