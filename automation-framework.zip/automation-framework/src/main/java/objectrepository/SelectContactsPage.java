package objectrepository;

import genericutility.AndroidWebDriverUtility;
import genericutility.WebDriverUtility;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class SelectContactsPage {

    WebDriverUtility webdriverUtility;
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/et_search"),
            @FindBy(id = "com.titan.smartworld:id/et_search")
    }) private WebElement searchContactTextEdit;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/textView3"),
            @FindBy(id = "com.titan.smartworld:id/textView3")
    }) private WebElement pageTitle;

    @FindBy(xpath = "//android.widget.TextView[@text='Anil Babai']/../android.widget.LinearLayout/android.view.ViewGroup[1]") private WebElement anilBabaiMobileNumber;

    @FindBy(xpath = "//android.widget.TextView[@text='Harivardan']/../android.widget.LinearLayout/android.view.ViewGroup[1]") private WebElement harivardanMobileNumber;

    @FindBy(xpath = "//android.widget.TextView[@text='Fazal']/../android.widget.LinearLayout/android.view.ViewGroup[1]") private WebElement fazalMobileNumber;

    @FindBy(xpath = "//android.widget.TextView[@text='Lavanya']/../android.widget.LinearLayout/android.view.ViewGroup[1]") private WebElement lavanyaMobileNumber;

    @FindBy(xpath = "//android.widget.TextView[@text='Pravin Bhai']/../android.widget.LinearLayout/android.view.ViewGroup[1]") private WebElement pravinBhaiMobileNumber;

    @FindBy(xpath = "//android.widget.TextView[@text='Sagar']/../android.widget.LinearLayout/android.view.ViewGroup[1]") private WebElement sagarMobileNumber;

    @FindBy(xpath = "//android.widget.TextView[@text='Sandy']/../android.widget.LinearLayout/android.view.ViewGroup[1]") private WebElement sandyMobileNumber;

    @FindBy(xpath = "//android.widget.TextView[@text='Satish Auto']/../android.widget.LinearLayout/android.view.ViewGroup[1]") private WebElement satishAutoMobileNumber;

    @FindBy(xpath = "//android.widget.TextView[@text='Suhail']/../android.widget.LinearLayout/android.view.ViewGroup[1]") private WebElement suhailMobileNumber;

    @FindBy(xpath = "//android.widget.TextView[@text='Vaishnavi']/../android.widget.LinearLayout/android.view.ViewGroup[1]") private WebElement vaishnaviMobileNumber;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/btn_save"),
            @FindBy(id = "com.titan.smartworld:id/btn_save")
    }) private WebElement saveBtn;

    @FindBy(xpath = "//android.widget.Toast") private WebElement toastMessage;

    public SelectContactsPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getSearchContactTextEdit() {
        return searchContactTextEdit;
    }

    public WebElement getPageTitle() {
        return pageTitle;
    }

    public WebElement getAnilBabaiMobileNumber() {
        return anilBabaiMobileNumber;
    }

    public WebElement getHarivardanMobileNumber() {
        return harivardanMobileNumber;
    }

    public WebElement getFazalMobileNumber() {
        return fazalMobileNumber;
    }

    public WebElement getLavanyaMobileNumber() {
        return lavanyaMobileNumber;
    }

    public WebElement getPravinBhaiMobileNumber() {
        return pravinBhaiMobileNumber;
    }

    public WebElement getSagarMobileNumber() {
        return sagarMobileNumber;
    }

    public WebElement getSandyMobileNumber() {
        return sandyMobileNumber;
    }

    public WebElement getSatishAutoMobileNumber() {
        return satishAutoMobileNumber;
    }

    public WebElement getSuhailMobileNumber() {
        return suhailMobileNumber;
    }

    public WebElement getVaishnaviMobileNumber() {
        return vaishnaviMobileNumber;
    }

    public WebElement getSaveBtn() {
        return saveBtn;
    }

    public WebElement getToastMessage() {
        return toastMessage;
    }

    public void checkIfUserLandsInSelectContactPage() {
        Assert.assertEquals(pageTitle.getText(), "Select Contacts");
    }

    public void addHarivardanMobileNumberToFavouritesAndClickOnSave(){
        harivardanMobileNumber.click();
        saveBtn.click();
    }

    public void addMoreContactsAndClickOnSave(){
        anilBabaiMobileNumber.click();
        fazalMobileNumber.click();
        lavanyaMobileNumber.click();
        pravinBhaiMobileNumber.click();
        saveBtn.click();
    }

    public void selectMaxContactsAndClickOnSave(WebDriver driver){
        webdriverUtility=new AndroidWebDriverUtility();
        webdriverUtility.swipeByElements(driver, pravinBhaiMobileNumber, anilBabaiMobileNumber, 2000);
        sagarMobileNumber.click();
        sandyMobileNumber.click();
        satishAutoMobileNumber.click();
        suhailMobileNumber.click();
        Assert.assertEquals(toastMessage.getText(), "Maximum contacts selection reached");
        WebDriverUtility.waitForElementToBeInvisible(driver, toastMessage, 50);
        saveBtn.click();
    }
}