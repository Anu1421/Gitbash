package objectrepository;

import genericutility.WebDriverUtility;
import genericutility.IOSWebDriverUtility;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.PointOption.point;
import static java.time.Duration.ofMillis;

public class EditPageForMyHealthOptions {
    WebDriverUtility webDriverUtility;
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'ic_back'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Edit'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/edit"),
            @FindBy(id = "com.titan.smartworld:id/edit")
    }) private WebElement editPageTitle;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Sleep']/following-sibling::XCUIElementTypeButton")
    @FindBy(xpath = "//android.widget.TextView[@text='Sleep']/../android.widget.CheckBox") private WebElement sleepCheckbox;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Sleep'")
    @FindBy(xpath = "//android.widget.TextView[@text='Sleep']") private WebElement sleepFeature;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Sleep']/preceding-sibling::XCUIElementTypeButton")
    @FindBy(xpath = "//android.widget.TextView[@text='Sleep']/../android.widget.ImageView") private WebElement sleepSwapIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Blood Oxygen']/following-sibling::XCUIElementTypeButton")
    @FindBy(xpath = "//android.widget.TextView[@text='Blood Oxygen']/../android.widget.CheckBox") private WebElement bloodOxygenCheckbox;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Blood Oxygen'")
    @FindBy(xpath = "//android.widget.TextView[@text='Blood Oxygen']") private WebElement bloodOxygenFeature;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Blood Oxygen']/preceding-sibling::XCUIElementTypeButton")
    @FindBy(xpath = "//android.widget.TextView[@text='Blood Oxygen']/../android.widget.ImageView") private WebElement bloodOxygenSwapIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Heart Rate']/following-sibling::XCUIElementTypeButton")
    @FindBy(xpath = "//android.widget.TextView[@text='Heart rate']/../android.widget.CheckBox") private WebElement heartRateCheckbox;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Heart Rate'")
    @FindBy(xpath = "//android.widget.TextView[@text='Heart rate']") private WebElement heartRateFeature;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Heart Rate']/preceding-sibling::XCUIElementTypeButton")
    @FindBy(xpath = "//android.widget.TextView[@text='Heart rate']/../android.widget.ImageView") private WebElement heartRateSwapIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='MultiSport']/following-sibling::XCUIElementTypeButton")
    @FindBy(xpath = "//android.widget.TextView[@text='Multi Sport']/../android.widget.CheckBox") private WebElement multiSportCheckbox;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'MultiSport'")
    @FindBy(xpath = "//android.widget.TextView[@text='Multi Sport']") private WebElement multiSportFeature;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='MultiSport']/preceding-sibling::XCUIElementTypeButton")
    @FindBy(xpath = "//android.widget.TextView[@text='Multi Sport']/../android.widget.ImageView") private WebElement multiSportSwapIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='My Cycle']/following-sibling::XCUIElementTypeButton")
    @FindBy(xpath = "//android.widget.TextView[@text='My Cycle']/../android.widget.CheckBox") private WebElement myCycleCheckbox;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'My Cycle'")
    @FindBy(xpath = "//android.widget.TextView[@text='My Cycle']") private WebElement myCycleFeature;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='My Cycle']/preceding-sibling::XCUIElementTypeButton")
    @FindBy(xpath = "//android.widget.TextView[@text='My Cycle']/../android.widget.ImageView") private WebElement myCycleSwapIcon;

    @iOSXCUITFindBy(iOSNsPredicate = "name == 'Save' AND value == 'Save'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/save"),
            @FindBy(id = "com.titan.smartworld:id/save")
    }) private WebElement saveBtn;

    public EditPageForMyHealthOptions(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getEditPageTitle() {
        return editPageTitle;
    }

    public WebElement getSleepCheckbox() {
        return sleepCheckbox;
    }

    public WebElement getSleepFeature() {
        return sleepFeature;
    }

    public WebElement getSleepSwapIcon() {
        return sleepSwapIcon;
    }

    public WebElement getBloodOxygenCheckbox() {
        return bloodOxygenCheckbox;
    }

    public WebElement getBloodOxygenFeature() {
        return bloodOxygenFeature;
    }

    public WebElement getBloodOxygenSwapIcon() {
        return bloodOxygenSwapIcon;
    }

    public WebElement getHeartRateCheckbox() {
        return heartRateCheckbox;
    }

    public WebElement getHeartRateFeature() {
        return heartRateFeature;
    }

    public WebElement getHeartRateSwapIcon() {
        return heartRateSwapIcon;
    }

    public WebElement getMultiSportCheckbox() {
        return multiSportCheckbox;
    }

    public WebElement getMultiSportFeature() {
        return multiSportFeature;
    }

    public WebElement getMultiSportSwapIcon() {
        return multiSportSwapIcon;
    }

    public WebElement getMyCycleCheckbox() {
        return myCycleCheckbox;
    }

    public WebElement getMyCycleFeature() {
        return myCycleFeature;
    }

    public WebElement getMyCycleSwapIcon() {
        return myCycleSwapIcon;
    }

    public WebElement getSaveBtn() {
        return saveBtn;
    }

    public void checkIfUserLandsInEditMyHealthSectionPage(){
        Assert.assertTrue(editPageTitle.getText().equals("Edit"));
    }

    public void clickOnBackBtn(){
        backBtn.click();
    }

    public void checkIfAllFeaturesAreDisplayed(String gender){
        if (gender.equals("FEMALE")) {
            Assert.assertTrue(sleepFeature.isDisplayed());
            Assert.assertTrue(bloodOxygenFeature.isDisplayed());
            Assert.assertTrue(heartRateFeature.isDisplayed());
            Assert.assertTrue(multiSportFeature.isDisplayed());
            Assert.assertTrue(myCycleFeature.isDisplayed());
        }
        else {
            Assert.assertTrue(sleepFeature.isDisplayed());
            Assert.assertTrue(bloodOxygenFeature.isDisplayed());
            Assert.assertTrue(heartRateFeature.isDisplayed());
            Assert.assertTrue(multiSportFeature.isDisplayed());
        }
    }

    public void changePositionsOfFeatures(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("Android")) {
            int startX = bloodOxygenSwapIcon.getLocation().getX() + (bloodOxygenSwapIcon.getSize().getWidth() / 2);
            int startY = bloodOxygenSwapIcon.getLocation().getY() + (bloodOxygenSwapIcon.getSize().getHeight() / 2);
            int endX = heartRateSwapIcon.getLocation().getX() + (heartRateSwapIcon.getSize().getWidth() / 2);
            int endY = heartRateSwapIcon.getLocation().getY() + (heartRateSwapIcon.getSize().getHeight() / 2);
            new TouchAction((AndroidDriver) driver)
                    .press(point(startX, startY))
                    .waitAction(waitOptions(ofMillis(2000)))
                    .moveTo(point(endX, endY))
                    .waitAction(waitOptions(ofMillis(2000)))
                    .release().perform();
        } else if (OS.equalsIgnoreCase("IOS")) {
            webDriverUtility = new IOSWebDriverUtility();
            webDriverUtility.dragAndDrop(driver, bloodOxygenSwapIcon, heartRateSwapIcon);
            saveBtn.click();
        }
    }

    public void clickOnSaveBtn(){
        saveBtn.click();
    }

    public void moveSleepToTheLast(WebDriver driver, String OS){
        if (OS.equalsIgnoreCase("iOS")) {
            WebDriverUtility webDriverUtility = new IOSWebDriverUtility();
            webDriverUtility.dragAndDrop(driver, sleepSwapIcon, saveBtn);
            saveBtn.click();
        } else if (OS.equalsIgnoreCase("Android")) {
            System.out.println("hello");
        }
    }
}