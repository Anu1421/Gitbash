package objectrepository;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class EditProfilePage {
    @iOSXCUITFindBy(iOSNsPredicate = "name == 'ic_back'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeImage[@name='ic_back']/following-sibling::XCUIElementTypeImage)[1]")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/profile_picture"),
            @FindBy(id = "com.titan.smartworld:id/profile_picture")
    }) private WebElement profilePictureImg;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeImage[@name='ic_back']/following-sibling::XCUIElementTypeButton") private WebElement userName;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Save Changes'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/save_changes_button"),
            @FindBy(id = "com.titan.smartworld:id/save_changes_button")
    }) private WebElement saveBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Save Changes']/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeStaticText")
    @FindBy(xpath = "//android.widget.Toast") private WebElement toastMessage;

    public EditProfilePage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getProfilePictureImg() {
        return profilePictureImg;
    }

    public WebElement getUserName() {
        return userName;
    }

    public WebElement getSaveBtn() {
        return saveBtn;
    }

    public WebElement getToastMessage() {
        return toastMessage;
    }

    public void clickOnUserProfileImage(){
        profilePictureImg.click();
    }

    public void clickOnSaveChangesBtn(){
        saveBtn.click();
    }

    public void checkForToastMessage(){
        Assert.assertEquals(toastMessage.getText(), "Changes Saved!");
    }
}