package objectrepository;

import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HowMuchDoYouWeighPage {

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'back'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/back_button"),
            @FindBy(id = "com.titan.smartworld:id/back_button")
    }) private WebElement backBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/weight_input"),
            @FindBy(id = "com.titan.smartworld:id/weight_input")
    }) private WebElement weightTextEdit;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField/parent::XCUIElementTypeOther/following-sibling::XCUIElementTypeOther[2]/XCUIElementTypeStaticText")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/system_type"),
            @FindBy(id = "com.titan.smartworld:id/system_type")
    }) private WebElement weightUnitSelection;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'KG'")
    @FindBy(xpath = "//android.widget.TextView[@text='KG']") private WebElement weightInKg;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'POUND'")
    @FindBy(xpath = "//android.widget.TextView[@text='POUND']") private WebElement weightInPound;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Save Changes'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/continue_button"),
            @FindBy(id = "com.titan.smartworld:id/continue_button")
    }) private WebElement saveChangesBtn;

    public HowMuchDoYouWeighPage(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getBackBtn() {
        return backBtn;
    }

    public WebElement getWeightTextEdit() {
        return weightTextEdit;
    }

    public WebElement getWeightUnitSelection() {
        return weightUnitSelection;
    }

    public WebElement getWeightInKg() {
        return weightInKg;
    }

    public WebElement getWeightInPound() {
        return weightInPound;
    }

    public WebElement getSaveChangesBtn() {
        return saveChangesBtn;
    }
}