package objectrepository;

import org.openqa.selenium.WebElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BatteryOptimizationPopUp {
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closePopUpBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/save_button"),
            @FindBy(id = "com.titan.smartworld:id/save_button")
    }) private WebElement disabledBtn;

    @FindBy(xpath = "//android.widget.Toast") private WebElement toastMessage;

    public BatteryOptimizationPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getDisabledBtn() {
        return disabledBtn;
    }

    public WebElement getToastMessage() {
        return toastMessage;
    }

    public void clickOnDisableBatteryOptimizationBtn(){
        disabledBtn.click();
    }
}