package objectrepository;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITBy;
import io.appium.java_client.pagefactory.iOSXCUITFindAll;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class UnitSystemPopUp {
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='ic close']/preceding-sibling::XCUIElementTypeStaticText") private WebElement popUpTitle;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'ic close'")
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/closeBtn"),
            @FindBy(id = "com.titan.smartworld:id/closeBtn")
    }) private WebElement closePopUpBtn;

    @iOSXCUITFindAll({
            @iOSXCUITBy(iOSNsPredicate = "value == 'Change to Imperial'"),
            @iOSXCUITBy(iOSNsPredicate = "value == 'Change to Metric'")
    })
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/okay_button"),
            @FindBy(id = "com.titan.smartworld:id/okay_button")
    }) private WebElement changeUnitBtn;

    public UnitSystemPopUp(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getClosePopUpBtn() {
        return closePopUpBtn;
    }

    public WebElement getChangeUnitBtn() {
        return changeUnitBtn;
    }

    public void changeUnitToImperialOrMetric(){
        changeUnitBtn.click();
    }

    public void checkIfUserIsAbleToChangeUnitSystem(){
        Assert.assertTrue(changeUnitBtn.isEnabled());
    }
}