package objectrepository;

import genericutility.AndroidWebDriverUtility;
import genericutility.WebDriverUtility;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OnboardingPages {
    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/name_input"),
            @FindBy(id = "com.titan.smartworld:id/name_input")
    }) private WebElement nameTextEdit;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/continue_button"),
            @FindBy(id = "com.titan.smartworld:id/continue_button")
    }) private WebElement continueBtn;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/icon1"),
            @FindBy(id = "com.titan.smartworld:id/icon1")
    }) private WebElement genderSelection;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/gender_title"),
            @FindBy(id = "com.titan.smartworld:id/gender_title")
    }) private WebElement genderTitle;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/date_input"),
            @FindBy(id = "com.titan.smartworld:id/date_input")
    }) private WebElement dateTextEdit;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/month_input"),
            @FindBy(id = "com.titan.smartworld:id/month_input")
    }) private WebElement monthTextEdit;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/year_input"),
            @FindBy(id = "com.titan.smartworld:id/year_input")
    }) private WebElement yearTextEdit;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/year_input"),
            @FindBy(id = "com.titan.smartworld:id/year_input")
    }) private WebElement heightTextEdit;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/system_type"),
            @FindBy(id = "com.titan.smartworld:id/system_type")
    }) private WebElement heightUnitSelection;

    @FindBy(xpath = "//android.widget.TextView[@text='FEET']") private WebElement heightInFeet;

    @FindBy(xpath = "//android.widget.TextView[@text='CM']") private WebElement heightInCm;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/weight_input"),
            @FindBy(id = "com.titan.smartworld:id/weight_input")
    }) private WebElement weightTextEdit;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/system_type"),
            @FindBy(id = "com.titan.smartworld:id/system_type")
    }) private WebElement weightUnitSelection;

    @FindBy(xpath = "//android.widget.TextView[@text='KG']") private WebElement weightInKg;

    @FindBy(xpath = "//android.widget.TextView[@text='POUND']") private WebElement weightInPound;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/input"),
            @FindBy(id = "com.titan.smartworld:id/input")
    }) private WebElement sleepGoalSelection;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/input"),
            @FindBy(id = "com.titan.smartworld:id/input")
    }) private WebElement multisportGoalSelection;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/input"),
            @FindBy(id = "com.titan.smartworld:id/input")
    }) private WebElement stepGoalSelection;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/skip_button"),
            @FindBy(id = "com.titan.smartworld:id/skip_button")
    }) private WebElement googleFitConnectSkip;

    @FindAll({
            @FindBy(id = "com.titan.fastrack.reflex:id/sign_in_button"),
            @FindBy(id = "com.titan.smartworld:id/sign_in_button")
    }) private WebElement googleFitConnectSignupLink;

    public OnboardingPages(WebDriver driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    public WebElement getNameTextEdit() {
        return nameTextEdit;
    }

    public WebElement getContinueBtn() {
        return continueBtn;
    }

    public WebElement getGenderSelection() {
        return genderSelection;
    }

    public WebElement getGenderTitle() {
        return genderTitle;
    }

    public WebElement getDateTextEdit() {
        return dateTextEdit;
    }

    public WebElement getMonthTextEdit() {
        return monthTextEdit;
    }

    public WebElement getYearTextEdit() {
        return yearTextEdit;
    }

    public WebElement getHeightTextEdit() {
        return heightTextEdit;
    }

    public WebElement getHeightUnitSelection() {
        return heightUnitSelection;
    }

    public WebElement getHeightInFeet() {
        return heightInFeet;
    }

    public WebElement getHeightInCm() {
        return heightInCm;
    }

    public WebElement getWeightTextEdit() {
        return weightTextEdit;
    }

    public WebElement getWeightUnitSelection() {
        return weightUnitSelection;
    }

    public WebElement getWeightInKg() {
        return weightInKg;
    }

    public WebElement getWeightInPound() {
        return weightInPound;
    }

    public WebElement getSleepGoalSelection() {
        return sleepGoalSelection;
    }

    public WebElement getMultisportGoalSelection() {
        return multisportGoalSelection;
    }

    public WebElement getStepGoalSelection() {
        return stepGoalSelection;
    }

    public WebElement getGoogleFitConnectSkip() {
        return googleFitConnectSkip;
    }

    public WebElement getGoogleFitConnectSignupLink() {
        return googleFitConnectSignupLink;
    }

    public void enterNameGenderDoBInOnboardingScreen(String name, String dateOfBirth, String monthOfBirth,
                                                     String yearOfBirth){
        WebDriverUtility.sendKeys(nameTextEdit, name);
        continueBtn.click();
        genderSelection.click();
        dateTextEdit.sendKeys(dateOfBirth);
        monthTextEdit.sendKeys(monthOfBirth);
        yearTextEdit.sendKeys(yearOfBirth);
    }
}