package genericutility;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.appium.java_client.InteractsWithApps;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import io.appium.java_client.ios.options.wda.XcodeCertificate;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import objectrepository.DashboardPage;
import objectrepository.NotificationAndControlCentre;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * BaseClass consists of code for launching the application and closing the application
 */
public class BaseClass {
    public static ArrayList features;
    public WebDriver driver;
    public AppiumDriverLocalService service;
    public String OSName;

    /**
     * Before Suite will fetch all the features of the watch and store it in an arraylist
     * @param productId
     */
    @Parameters({"product","os"})
    @BeforeSuite
    public void getFeaturesByProduct(String productId, String OS){
        try {
            String content=null;
            if (OS.equalsIgnoreCase("Android")){
                content = FileUtils.readFileToString(new File(IPathConstants.jsonPathForProductFeaturesAndroid), StandardCharsets.UTF_8);
            } else if (OS.equalsIgnoreCase("IOS")) {
                content = FileUtils.readFileToString(new File(IPathConstants.jsonPathForProductFeaturesIOS), StandardCharsets.UTF_8);
            }
            ObjectMapper mapper = new ObjectMapper();
            HashMap<String, ArrayList> data = mapper.readValue(content, new TypeReference<HashMap<String, ArrayList>>() {
            });
            features = data.get(productId);
        } catch (JsonMappingException e) {
            throw new RuntimeException(e);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Before Test will start the server and provide desired capabilities of the device and application
     * @param deviceName
     * @throws Throwable
     */
    @Parameters({"deviceName","os"})
    @BeforeTest
    public void startServerAndProvideCapabilities(String deviceName, String OS) throws Throwable {
        String ip= (String) JSONUtility.fetchDataFromJson(deviceName,"ipAddress");
        String port= (String) JSONUtility.fetchDataFromJson(deviceName,"portNumber");
        String nodePath= (String) JSONUtility.fetchDataFromJson(deviceName,"nodePath");

        service=new AppiumServiceBuilder().withAppiumJS(new File(nodePath))
                .usingDriverExecutable(new File("C:/Program Files/nodejs/node.exe"))
                .withIPAddress(ip).usingPort(Integer.parseInt(port)).build();
        service.start();


        if (OS.equalsIgnoreCase("Android")){
            DesiredCapabilities dc=new DesiredCapabilities();
            dc.setCapability(MobileCapabilityType.PLATFORM_NAME, JSONUtility.fetchDataFromJson(deviceName,"PlatformName"));
            dc.setCapability(MobileCapabilityType.PLATFORM_VERSION, JSONUtility.fetchDataFromJson(deviceName,"PlatformVersion"));
            dc.setCapability(MobileCapabilityType.DEVICE_NAME, JSONUtility.fetchDataFromJson(deviceName,"DeviceName"));
            dc.setCapability(MobileCapabilityType.UDID, JSONUtility.fetchDataFromJson(deviceName,"DeviceID"));
            dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, JSONUtility.fetchDataFromJson(deviceName,"automationName"));
            dc.setCapability("appPackage", JSONUtility.fetchDataFromJson(deviceName,"AppPackage"));
            dc.setCapability("appActivity", JSONUtility.fetchDataFromJson(deviceName,"AppActivity"));
            dc.setCapability(MobileCapabilityType.NO_RESET, "true");
            dc.setCapability("newCommandTimeout", 60000);

            driver = new AndroidDriver(new URL("http://"+ip+":"+port), dc);

        } else if (OS.equalsIgnoreCase("IOS")) {
            service=new AppiumServiceBuilder().withAppiumJS(new File(nodePath))
                    .usingDriverExecutable(new File("/usr/local/bin/node"))
                    .withIPAddress(ip).usingPort(Integer.parseInt(port)).build();
            service.start();

            XCUITestOptions options = new XCUITestOptions();
            options.setDeviceName((String) JSONUtility.fetchDataFromJson(deviceName, "DeviceName"));
            options.setPlatformVersion((String) JSONUtility.fetchDataFromJson(deviceName, "PlatformVersion"));
            options.setUdid((String) JSONUtility.fetchDataFromJson(deviceName, "DeviceID"));
            options.setPlatformName((String) JSONUtility.fetchDataFromJson(deviceName, "PlatformName"));
            options.setBundleId((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
            options.setXcodeCertificate(new XcodeCertificate((String) JSONUtility.fetchDataFromJson(deviceName,"xcodeOrgId")));
            options.setCapability("xcodeSigningId", JSONUtility.fetchDataFromJson(deviceName,"xcodeSigningId"));
            options.setAutomationName((String) JSONUtility.fetchDataFromJson(deviceName,"automationName"));
            options.setNoReset(true);

            driver=new IOSDriver(new URL("http://"+ip+":"+port), options);
        }
        //Implicit wait
        WebDriverUtility.waitForPageToLoad(driver, 10);
    }

    @Parameters("os")
    @BeforeClass
    public void specifyTheOS(String OS){
        OSName=OS;
    }

    /**
     * Before Method will launch the app and check if the watch is paired and also check if Wi-Fi is connected
     */
    @Parameters({"deviceName","os"})
    @BeforeMethod
    public void launchTheAppAndCheckIfWatchIsPaired(String deviceName, String OS){
        //launch the app
        ((InteractsWithApps)driver).activateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
        //If watch is unpaired, pair the watch
        DashboardPage dashboardPage=new DashboardPage(driver);
        if (dashboardPage.returnWatchConnectionStatus(OS).contains("unpaired") || dashboardPage.returnWatchConnectionStatus(OS).contains("DISCONNECTED") || dashboardPage.returnWatchConnectionStatus(OS).contains("connection status")) {
            dashboardPage.pairWatch();
        }
        //Check if Wi-Fi is on, if Wi-Fi is off, turn it on
        NotificationAndControlCentre notificationAndControlCentre=new NotificationAndControlCentre(driver);
        notificationAndControlCentre.checkIfWifiIsOff(driver, OS);
        //wait for watch to pair
        dashboardPage.waitForWatchToPair(driver);
    }

    /**
     * After method will close the app
     */
    @Parameters({"deviceName","os"})
    @AfterMethod
    public void closeApp(String deviceName, String OS) {
        //Close the app
        try {
            ((InteractsWithApps)driver).terminateApp((String) JSONUtility.fetchDataFromJson(deviceName, "AppPackage"));
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * It will quit the driver instance and stop the server
     */
    @AfterTest
    public void stopServer(){
        //Quit the driver instance
        driver.quit();
        //Stop the server
        service.stop();
    }

    /**
     * This method is used to swipe down from the top-right corner and reveal the control center for an iOS device
     * @param driver
     */
    public static void swipeDownToRevealControlCenter(WebDriver driver){
        Dimension size = driver.manage().window().getSize();
        int startX = size.getWidth()-5;
        int startY = 5;
        int endX = size.getWidth()-5;
        int endY = 150;
        Map<String, Object> params= new HashMap<>();
        params.put("duration", 2);
        params.put("fromX", startX);
        params.put("fromY", startY);
        params.put("toX", endX);
        params.put("toY", endY);
        ((IOSDriver)driver).executeScript("mobile:dragFromToForDuration", params);
    }

    /**
     * This method will swipe up from the bottom-center of the screen for an iOS device
     * @param driver
     */
    public static void swipeUpToHomeScreen(WebDriver driver){
        Dimension size = driver.manage().window().getSize();
        int startX = size.getWidth()/2;
        int startY = size.getHeight()-5;
        int endX = size.getWidth()/2;
        int endY = 150;
        Map<String, Object> params= new HashMap<>();
        params.put("duration", 2);
        params.put("fromX", startX);
        params.put("fromY", startY);
        params.put("toX", endX);
        params.put("toY", endY);
        ((IOSDriver)driver).executeScript("mobile:dragFromToForDuration", params);
    }
}