package genericutility;

public interface IPathConstants {
    String excelPath="./src/test/resources/TestData.xlsx";

    String jsonPathForMobileAndAppConfig="./src/test/configurationfiles/mobile_and_app_configurations.json";

    String jsonPathForProductFeaturesAndroid ="./src/test/configurationfiles/product_featuresAndroid.json";

    String jsonPathForProductFeaturesIOS ="./src/test/configurationfiles/product_featuresiOS.json";
}