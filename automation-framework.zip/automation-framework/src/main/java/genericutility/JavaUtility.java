package genericutility;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.Date;
import java.util.Random;

/**
 * Java Utility is used to write java programs
 */
public class JavaUtility {
    /**
     * It is used to generate a random number
     * @return
     */
    public int getRandomNumber() {
        Random random=new Random();
        int randNum = random.nextInt(1000);
        return randNum;
    }
    /**
     * It is used to get systemDateAndTime in IST Format
     * @return
     */
    public String getSystemDateAndTimeInISTFormat() {
        Date date=new Date();
        return date.toString();
    }

    /**
     * It is used to get systemDate only
     * @return
     */
    public String getSystemDate(){
        Date date=new Date();
        String fullDate = date.toString();
        String DD = fullDate.split(" ") [2];
        return DD;
    }

    /**
     * It is used to fetch only numbers from a string
     * @param str
     * @return
     */
    public int getOnlyNumberFromString(String str){
        str = str.replaceAll("[^0-9]", "");
        int num = Integer.parseInt(str);
        return num;
    }

    /**
     * It is used to fetch only value of Temperature and remove the units
     * @param str
     * @return
     */
    public float getOnlyNumberFromTemperature(String str){
        str = str.replaceAll("[^0-9, ^.]", "");
        float num = Float.parseFloat(str);
        return num;
    }

    /**
     * It is used to fetch only the alphabets from the String
     * @param str
     * @return
     */
    public String getOnlyAlphabetsFromString(String str){
        str = str.replaceAll("[^A-Z, ^a-z]", "");
        return str;
    }

    /**
     * It is used to return the present month in mmm format
     * @return
     */
    public String fetchOnlyMonthInMonFormat(){
        Date date=new Date();
        String fullDate = date.toString();
        String mon = fullDate.split(" ") [1];
        return mon;
    }

    /**
     * It is used to return the dates for the present week from Monday to Sunday
     * @return
     */
    public String getDatesFromMonToSunForPresentWeek() {
        LocalDate today = LocalDate.now(); //YYYY-MM-DD
        //today=today.minusDays(7);
        System.out.println(today);
        DayOfWeek dayOfWeek = today.getDayOfWeek();
        int dayInNumber = dayOfWeek.getValue();
        int daysToAdd = 7-dayInNumber;
        LocalDate weekEnd = today.plusDays(daysToAdd);
        LocalDate weekStart = today.minusDays(dayInNumber-1);
        //System.out.println(weekEnd+" "+weekStart);
        Month weekEndMonth = weekEnd.getMonth();
        Month weekStartMonth = weekStart.getMonth();
        String dateString;
        String endMonthText = weekEndMonth.toString().substring(1, 3).toLowerCase();
        if(weekStartMonth == weekEndMonth)
        {
            String startdate=weekStart.toString().substring(8);
            System.out.println(startdate);
            if(startdate.charAt(0)=='0') {
                startdate=startdate.substring(1);
            }
            dateString = startdate+" - "+weekEnd.toString().substring(8)+" "+weekEndMonth.toString().substring(0,1)+ endMonthText;
        }
        else
        {
            dateString = weekStart.toString().substring(8)+" "+weekStartMonth.toString().substring(0,1)+ weekStartMonth.toString().substring(1,3).toLowerCase()+" - "+weekEnd.toString().substring(8)+" "+weekEndMonth.toString().substring(0,1)+ endMonthText;
        }
        return dateString;
    }
    private static LocalDate findPrevDay(LocalDate localdate, int noOfDays)
    {
        return localdate.minusDays(noOfDays);
    }

    private static LocalDate findNextDay(LocalDate localdate, int noOfDays)
    {
        return localdate.plusDays(noOfDays);
    }

    /**
     * It is used to return only the numbers from a String
     * @param bounds
     * @return
     */
    public String fetchXAndYCoOrdinatesFromBounds(String bounds){
        return bounds.replaceAll("\\[|\\]|\\,", " ");
    }

    /**
     * It is used to return the date in dd<space>mmm format
     * @return
     */
    public String getDateInDDSpaceMonFormat(){
        Date date=new Date();
        String fullDate = date.toString();
        String ddMon = fullDate.split(" ") [2]+" "+fullDate.split(" ") [1];
        return ddMon;
    }

    /**
     * It is used to fetch the previous date from today's date with the parameter as a reference
     * @param noOfDays
     * @return
     */
    public String getPreviousDate(int noOfDays){
        Date date=new Date();
        String fullDate = date.toString();
        LocalDate localDate = null;
        String previousDay = localDate.now().minusDays(noOfDays).toString();
        String pre = previousDay.split("-")[2]+" "+fullDate.split(" ") [1];
        return pre;
    }

    public float changeTempFromFahrenheitToCelsius(String temperatureInF) {
        float temperatureInFahrenheit = getOnlyNumberFromTemperature(temperatureInF);
        System.out.println(temperatureInFahrenheit);
        float temperatureInCelsius = (temperatureInFahrenheit - 32) * 5 / 9;
        return temperatureInCelsius;
    }

    public float changeTempFromCelsiusToFahrenheit(String temperatureInC){
        float temperatureInCelsius = getOnlyNumberFromTemperature(temperatureInC);
        System.out.println(temperatureInCelsius);
        float temperatureInFahrenheit=(temperatureInCelsius*5/9)+32;
        return temperatureInFahrenheit;
    }
}