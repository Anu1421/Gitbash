package genericutility;

import io.appium.java_client.android.AndroidDriver;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.time.Duration;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public interface WebDriverUtility {

    /**
     * Implicit wait-It will wait for the defined seconds till the page is loaded
     *
     * @param driver
     * @param seconds
     */
    public static void waitForPageToLoad(WebDriver driver, long seconds) {
        driver.manage().timeouts().implicitlyWait(seconds, TimeUnit.SECONDS);
    }

    /**
     * Explicit wait-It will wait for the defined time in seconds till the element is visible
     * @param driver
     * @param element
     * @param seconds
     */
    public static void waitForElementToBeVisible(WebDriver driver, WebElement element, long seconds){
        WebDriverWait webDriverWait=new WebDriverWait(driver, Duration.ofSeconds(seconds));
        webDriverWait.until(ExpectedConditions.visibilityOf(element));
    }

    /**
     * Explicit wait-It will wait for the defined time in seconds till the element is invisible
     * @param driver
     * @param element
     * @param seconds
     */
    public static void waitForElementToBeInvisible(WebDriver driver,WebElement element, long seconds){
        WebDriverWait webDriverWait=new WebDriverWait(driver, Duration.ofSeconds(seconds));
        webDriverWait.until(ExpectedConditions.invisibilityOf(element));
    }

    /**
     * Explicit wait-It will wait for the defined time in seconds till the element is clickable
     * @param driver
     * @param element
     * @param seconds
     */
    public static void waitForElementToBeClickable(WebDriver driver, WebElement element, long seconds){
        WebDriverWait webDriverWait=new WebDriverWait(driver, Duration.ofSeconds(seconds));
        webDriverWait.until(ExpectedConditions.elementToBeClickable(element));
    }

    /**
     * Explicit wait-It will wait with custom polling time till element is clickable
     * @param driver
     * @param element
     * @param pollingTime
     */
    public static void waitForElementToBeClickable(WebDriver driver,WebElement element, int pollingTime){
        FluentWait wait =new FluentWait(driver);
        wait.pollingEvery(Duration.ofSeconds(pollingTime));
        wait.ignoring(Exception.class);
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    /**
     * It will take screenshot of the page and return the path of the screenshot
     * @param driver
     * @param testCaseName
     * @return
     * @throws Throwable
     */
    public static String getScreenshotPath(WebDriver driver, String testCaseName) throws Throwable{
        File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        String dstFile = System.getProperty("user.dir") + "/screenshot/" + testCaseName + ".png";
        FileUtils.copyFile(src, new File(dstFile));
        return dstFile;
    }

    /**
     * Scroll to the element using its attributeName, attributeValue and direction
     * @param driver
     * @param direction
     * @param an
     * @param av
     */
    public void scrollToElement(WebDriver driver, String direction, String an, String av);

    /**
     * Swipe by using start element and end element reference for the defined swipe time
     * @param driver
     * @param startElement
     * @param endElement
     * @param swipeTime
     */
    public void swipeByElements(WebDriver driver, WebElement startElement, WebElement endElement, int swipeTime);

    /**
     * Swipe action using direction, velocity and element reference
     * @param driver
     * @param direction
     * @param velocity
     * @param element
     */
    public void swipe(WebDriver driver, String direction, int velocity, WebElement element);

    /**
     * Performs swipe from the center of screen using direction as input
     * @param driver
     * @param dir
     **/
    public void swipeScreen(WebDriver driver, Direction dir);

    public enum Direction {
        UP,
        DOWN,
        LEFT,
        RIGHT;
    }

    /**
     * It is used to drag and drop an element from one location to another by taking element reference
     * @param driver
     * @param element1
     * @param element2
     */
    public void dragAndDrop(WebDriver driver, WebElement element1, WebElement element2);

    /**
     * It is used to fetch OTP from excel and load it in an arraylist
     * @return OTP
     */
    public static ArrayList getOtpDigitByDigit() throws Throwable{
        ExcelUtility excelUtility = new ExcelUtility();
        String otp = excelUtility.fetchDataFromExcel("Onboarding", 1, 3);
        ArrayList arrayList=new ArrayList();
        for (int i=0; i<=otp.length()-1; i++) {
            arrayList.add(otp.charAt(i));
        }
        return arrayList;
    }

    /**
     * It is used to clear already existing data in the textBox/textField and send new data
     * @param element
     * @param keys
     */
    public static void sendKeys(WebElement element, String keys){
        element.clear();
        element.sendKeys(keys);
    }
}