package genericutility;

import org.apache.poi.ss.usermodel.*;

import java.io.FileInputStream;

/**
 * ExcelUtility is used to fetch the data from the Excel file
 */
public class ExcelUtility {
    /**
     * It is used to fetch the data from the Excel file
     * @param sheet
     * @param row
     * @param cell
     * @return
     * @throws Throwable
     */
    public String fetchDataFromExcel(String sheet, Integer row, Integer cell) throws Throwable {
        FileInputStream fileInputStream=new FileInputStream(IPathConstants.excelPath);
        Workbook workbook =WorkbookFactory.create(fileInputStream);
        Cell cellValue = workbook.getSheet(sheet).getRow(row).getCell(cell);

        DataFormatter dataFormatter=new DataFormatter();
        String data = dataFormatter.formatCellValue(cellValue);
        return data;
    }
}