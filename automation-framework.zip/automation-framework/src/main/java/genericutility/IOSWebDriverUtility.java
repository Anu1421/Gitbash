package genericutility;

import io.appium.java_client.ios.IOSDriver;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class IOSWebDriverUtility implements WebDriverUtility {
    IOSDriver driver;

    /**
     * Scroll to the element using its attributeName, attributeValue and direction
     * @param driver
     * @param direction
     * @param an
     * @param av
     */
    public void scrollToElement(WebDriver driver,String direction, String an, String av) {
        Map<String,Object> params = new HashMap<>();
        params.put("direction", direction);
        params.put(an, av);
        ((IOSDriver)driver).executeScript("mobile:scroll", params);
    }

    /**
     * Swipe by using start element and end element reference for the defined swipe time
     * @param driver
     * @param startElement
     * @param endElement
     * @param swipeTime
     */
    public void swipeByElements(WebDriver driver, WebElement startElement, WebElement endElement, int swipeTime) {
        int startX = startElement.getLocation().getX() + (startElement.getSize().getWidth() / 2);
        int startY = startElement.getLocation().getY() + (startElement.getSize().getHeight() / 2);
        int endX = endElement.getLocation().getX() + (endElement.getSize().getWidth() / 2);
        int endY = endElement.getLocation().getY() + (endElement.getSize().getHeight() / 2);
        Map<String, Object> params= new HashMap<>();
        params.put("duration", swipeTime);
        params.put("fromX", startX);
        params.put("fromY", startY);
        params.put("toX", endX);
        params.put("toY", endY);
        ((IOSDriver)driver).executeScript("mobile:dragFromToForDuration", params);
    }

    /**
     * Swipe action using direction, velocity and element reference
     * @param driver
     * @param direction
     * @param velocity
     * @param element
     */
    public void swipe(WebDriver driver, String direction, int velocity, WebElement element) {
        Map<String, Object> params= new HashMap<>();
        params.put("direction", direction);
        params.put("velocity", velocity);
        params.put("element", ((RemoteWebElement) element).getId());
        ((IOSDriver)driver).executeScript("mobile:swipe", params);
    }

    /**
     * Performs swipe from the center of screen using direction as input
     * @param driver
     * @param dir the direction of swipe
     */
    public void swipeScreen(WebDriver driver, WebDriverUtility.Direction dir) {
        final int ANIMATION_TIME = 200; // ms
        final HashMap<String, String> scrollObject = new HashMap();

        switch (dir) {
            case DOWN: // from up to down (! differs from mobile:scroll)
                scrollObject.put("direction", "down");
                break;
            case UP: // from down to up  (! differs from mobile:scroll)
                scrollObject.put("direction", "up");
                break;
            case LEFT: // from right to left  (! differs from mobile:scroll)
                scrollObject.put("direction", "left");
                break;
            case RIGHT: // from left to right  (! differs from mobile:scroll)
                scrollObject.put("direction", "right");
                break;
            default:
                throw new IllegalArgumentException("mobileSwipeScreenIOS(): dir: '" + dir + "' NOT supported");
        }
        try {
            ((IOSDriver)driver).executeScript("mobile:swipe", scrollObject);
            Thread.sleep(ANIMATION_TIME); // always allow swipe action to complete
        } catch (Exception e) {
            System.err.println("mobileSwipeScreenIOS(): FAILED\n" + e.getMessage());
            return;
        }
    }

    /**
     * It is used to drag and drop an element from one location to another by taking element reference
     * @param driver
     * @param element1
     * @param element2
     */
    public void dragAndDrop(WebDriver driver, WebElement element1, WebElement element2){
        int startX = element1.getLocation().getX() + (element1.getSize().getWidth() / 2);
        int startY = element1.getLocation().getY() + (element1.getSize().getHeight() / 2);
        int endX = element2.getLocation().getX() + (element2.getSize().getWidth() / 2);
        int endY = element2.getLocation().getY() + (element2.getSize().getHeight() / 2);
        Map<String, Object> params= new HashMap<>();
        params.put("duration", 5);
        params.put("fromX", startX);
        params.put("fromY", startY);
        params.put("toX", endX);
        params.put("toY", endY);
        ((IOSDriver)driver).executeScript("mobile:dragFromToForDuration", params);
    }
}