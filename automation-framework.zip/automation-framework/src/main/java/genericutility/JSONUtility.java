package genericutility;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * JSONUtility is used to fetch data from a JSON file
 */
public class JSONUtility {
    public static Object fetchDataFromJson(String deviceName, String capabilityKey) {
        final DesiredCapabilities capabilities = new DesiredCapabilities();
        try (final FileInputStream fileInputStream = new FileInputStream(IPathConstants.jsonPathForMobileAndAppConfig))
        {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readValue(fileInputStream, JsonNode.class);
            JsonNode phoneCaps = jsonNode.get(deviceName);
            phoneCaps.fields().forEachRemaining(caps->{
                final String commonCapsFieldName = caps.getKey ();
                final String commonCapsFieldValue = caps.getValue ()
                        .asText ();
                capabilities.setCapability(commonCapsFieldName, commonCapsFieldValue);
            });

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return capabilities.getCapability(capabilityKey);
    }
}