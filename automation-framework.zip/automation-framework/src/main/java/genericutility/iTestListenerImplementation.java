package genericutility;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class iTestListenerImplementation implements ITestListener {
    public static ExtentTest test;
    ExtentReports report= ExtentReporterNG.getReporterObject();
    WebDriver driver;

    public void onTestStart(ITestResult result) {
        test=report.createTest(result.getMethod().getMethodName());
    }

    public void onTestSuccess(ITestResult result) {
        test.log(Status.PASS, result.getMethod().getMethodName());
        test.log(Status.PASS, result.getThrowable());
    }

    public void onTestFailure(ITestResult result) {
        test.log(Status.FAIL, result.getMethod().getMethodName());
        test.log(Status.FAIL, result.getThrowable());
        try {
            driver= (WebDriver) result.getTestClass().getRealClass().getField("driver")
                    .get(result.getInstance());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        try {
            test.addScreenCaptureFromPath(WebDriverUtility.getScreenshotPath(driver, result.getMethod().getMethodName()));
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    public void onTestSkipped(ITestResult result) {
        test.log(Status.SKIP, result.getMethod().getMethodName());
        test.log(Status.SKIP, result.getThrowable());
    }

    public void onFinish(ITestContext context) {
        report.flush();
    }
}
