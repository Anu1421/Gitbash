package genericutility;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReporterNG {
    public static ExtentReports extentReports;

    public static ExtentReports getReporterObject(){
        String reportPath = System.getProperty("user.dir") + "/extentreports/report.html";
        ExtentSparkReporter extentSparkReporter=new ExtentSparkReporter(reportPath);
        extentSparkReporter.config().setReportName("Report");
        extentSparkReporter.config().setDocumentTitle("Extent Report");

        extentReports=new ExtentReports();
        extentReports.attachReporter(extentSparkReporter);
        extentReports.setSystemInfo("Created by", "Suhail");
        return extentReports;
    }
}
